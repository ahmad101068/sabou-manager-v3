package ir.sabou.inventory.domain.sales

import ir.sabou.inventory.core.MoneyRial
import ir.sabou.inventory.core.QuantityMicros
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class SalesCalculatorTest {
    @Test
    fun allocatesInvoiceAdjustmentsWithoutLosingOneRial() {
        val draft = SalesInvoiceDraft(
            businessEpochDay = 20_000,
            lines = listOf(
                SalesLineDraft(1, QuantityMicros.of(1_000_000), MoneyRial.of(100_000), MoneyRial.of(10_000)),
                SalesLineDraft(2, QuantityMicros.of(2_000_000), MoneyRial.of(50_000)),
            ),
            orderDiscount = MoneyRial.of(20_001),
            service = MoneyRial.of(5_003),
            tax = MoneyRial.of(15_007),
            payments = listOf(SalesPaymentDraft(SalesPaymentMethod.CASH, MoneyRial.of(190_009))),
        )

        val prepared = SalesCalculator.prepare(draft)

        assertEquals(200_000L, prepared.grossRial)
        assertEquals(30_001L, prepared.discountRial)
        assertEquals(190_009L, prepared.netRial)
        assertEquals(prepared.discountRial, prepared.lines.sumOf { it.discountRial })
        assertEquals(prepared.serviceRial, prepared.lines.sumOf { it.serviceRial })
        assertEquals(prepared.taxRial, prepared.lines.sumOf { it.taxRial })
        assertEquals(prepared.netRial, prepared.lines.sumOf { it.netRial })
    }

    @Test
    fun rejectsPaymentMismatchInsteadOfSilentlyBalancingIt() {
        val draft = SalesInvoiceDraft(
            businessEpochDay = 20_000,
            lines = listOf(SalesLineDraft(1, QuantityMicros.of(1_000_000), MoneyRial.of(100_000))),
            payments = listOf(SalesPaymentDraft(SalesPaymentMethod.CARD, MoneyRial.of(99_999))),
        )

        assertThrows(IllegalArgumentException::class.java) { SalesCalculator.prepare(draft) }
    }

    @Test
    fun creditSaleRequiresCustomerAndDueDate() {
        val draft = SalesInvoiceDraft(
            businessEpochDay = 20_000,
            lines = listOf(SalesLineDraft(1, QuantityMicros.of(1_000_000), MoneyRial.of(100_000))),
            payments = listOf(SalesPaymentDraft(SalesPaymentMethod.CREDIT, MoneyRial.of(100_000))),
        )

        assertThrows(IllegalArgumentException::class.java) { SalesCalculator.prepare(draft) }
    }

    @Test
    fun holdRejectsDuplicateMenuRowsAndExcessDiscount() {
        val duplicate = SalesHoldDraft(
            lines = listOf(
                SalesLineDraft(1, QuantityMicros.of(1_000_000), MoneyRial.of(10_000)),
                SalesLineDraft(1, QuantityMicros.of(1_000_000), MoneyRial.of(10_000)),
            ),
        )
        assertThrows(IllegalArgumentException::class.java) { duplicate.validated() }

        val excessive = SalesHoldDraft(
            orderDiscount = MoneyRial.of(10_001),
            lines = listOf(SalesLineDraft(1, QuantityMicros.of(1_000_000), MoneyRial.of(10_000))),
        )
        assertThrows(IllegalArgumentException::class.java) { excessive.validated() }
    }
}
