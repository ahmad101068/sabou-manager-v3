package ir.sabou.inventory.core

import java.math.BigDecimal
import java.math.BigInteger

private val LONG_MIN_BIG_INTEGER: BigInteger = BigInteger.valueOf(Long.MIN_VALUE)
private val LONG_MAX_BIG_INTEGER: BigInteger = BigInteger.valueOf(Long.MAX_VALUE)

/**
 * API-23 compatible equivalent of BigInteger.toLongExactCompat(), which is only
 * available to Android apps from API 31. Preserves exact-conversion semantics
 * by throwing when the value is outside Long's representable range.
 */
fun BigInteger.toLongExactCompat(): Long {
    if (this < LONG_MIN_BIG_INTEGER || this > LONG_MAX_BIG_INTEGER) {
        throw ArithmeticException("BigInteger value is outside Long range: $this")
    }
    return toLong()
}

fun BigDecimal.toLongExactCompat(): Long = toBigIntegerExact().toLongExactCompat()
