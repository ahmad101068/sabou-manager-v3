package ir.sabou.inventory.ui

import ir.sabou.inventory.R
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Assessment
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MoreHoriz
import androidx.compose.material.icons.outlined.NotificationsNone
import androidx.compose.material.icons.outlined.PersonOutline
import androidx.compose.material.icons.outlined.PointOfSale
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ir.sabou.inventory.data.repository.DashboardPeriod
import ir.sabou.inventory.data.repository.DashboardSnapshot

@Composable
internal fun DashboardScreen(
    state: DashboardSnapshot,
    home: DashboardUiState,
    onSearch: () -> Unit,
    onSettings: () -> Unit,
    onToday: () -> Unit,
    onWeek: () -> Unit,
    onMonth: () -> Unit,
    onCustomRange: (Long, Long) -> Unit,
    onBranch: (String?) -> Unit,
    onWarehouse: (Long?) -> Unit,
    onOpen: (AppScreen) -> Unit,
) {
    var showCustomRange by remember { mutableStateOf(false) }
    if (showCustomRange) {
        var from by remember(state.fromEpochDay) { mutableStateOf(state.fromEpochDay.coerceAtLeast(1L)) }
        var to by remember(state.toEpochDay) { mutableStateOf(state.toEpochDay.coerceAtLeast(from)) }
        AlertDialog(
            onDismissRequest = { showCustomRange = false },
            title = { Text(stringResource(R.string.ux2_text_b72814f2ab)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    PersianDateField("از تاریخ", from) { from = it; if (to < from) to = from }
                    PersianDateField("تا تاریخ", to) { to = it }
                }
            },
            confirmButton = { Button(onClick = { onCustomRange(from, to); showCustomRange = false }) { Text(stringResource(R.string.ux2_text_72513b9f3f)) } },
            dismissButton = { TextButton(onClick = { showCustomRange = false }) { Text(stringResource(R.string.ux2_text_106dfb4e0f)) } },
        )
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            HomeBottomNavigation(
                onHome = {},
                onOperations = { onOpen(AppScreen.OPERATIONS_HUB) },
                onReports = { onOpen(AppScreen.REPORTS) },
                onMore = { onOpen(AppScreen.MORE) },
            )
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).testTag("home_dashboard"),
            contentPadding = PaddingValues(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            // Section 1/4: Header + context filters. Audit and module lists are intentionally forbidden here.
            item {
                HomeHeader(
                    home = home,
                    state = state,
                    onSearch = onSearch,
                    onSettings = onSettings,
                    onAlerts = { onOpen(AppScreen.ALERTS) },
                    onToday = onToday,
                    onWeek = onWeek,
                    onMonth = onMonth,
                    onCustom = { showCustomRange = true },
                    onBranch = onBranch,
                    onWarehouse = onWarehouse,
                )
            }
            // Section 2/4: Role-aware KPI summary, maximum four.
            item { HomeKpiSummary(home.kpis, home.loading, onOpen) }
            // Section 3/4: Permission-aware quick actions, maximum six.
            item { HomeQuickActions(home.quickActions, onOpen) }
            // Section 4/4: Only actionable attention items.
            item { HomeAttentionCenter(home.alerts, home.partialErrors, onOpen) }
        }
    }
}

@Composable
private fun HomeHeader(
    home: DashboardUiState,
    state: DashboardSnapshot,
    onSearch: () -> Unit,
    onSettings: () -> Unit,
    onAlerts: () -> Unit,
    onToday: () -> Unit,
    onWeek: () -> Unit,
    onMonth: () -> Unit,
    onCustom: () -> Unit,
    onBranch: (String?) -> Unit,
    onWarehouse: (Long?) -> Unit,
) {
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp).testTag("home_header"),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    home.header.organizationName.ifBlank { "مدیریت کافه رستوران" },
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Black,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    "${home.header.userName.ifBlank { "کاربر" }} · ${home.header.roleTitle}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                )
            }
            IconButton(
                onClick = onSearch,
                modifier = Modifier.size(48.dp).testTag("home_search").semantics { contentDescription = stringResource(R.string.ux2_text_24b9f8bed8) },
            ) { Icon(Icons.Outlined.Search, contentDescription = null) }
            Box {
                IconButton(
                    onClick = onAlerts,
                    modifier = Modifier.size(48.dp).testTag("home_notifications").semantics { contentDescription = stringResource(R.string.ux2_text_d35ea47c92) },
                ) { Icon(Icons.Outlined.NotificationsNone, contentDescription = null) }
                if (home.header.unreadAttentionCount > 0) {
                    Surface(
                        modifier = Modifier.align(Alignment.TopEnd),
                        shape = RoundedCornerShape(20.dp),
                        color = MaterialTheme.colorScheme.error,
                    ) {
                        Text(
                            home.header.unreadAttentionCount.coerceAtMost(99).toString(),
                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp),
                            color = MaterialTheme.colorScheme.onError,
                            style = MaterialTheme.typography.labelSmall,
                        )
                    }
                }
            }
            IconButton(
                onClick = onSettings,
                modifier = Modifier.size(48.dp).testTag("home_profile").semantics { contentDescription = stringResource(R.string.ux2_text_a992392ce1) },
            ) { Icon(Icons.Outlined.PersonOutline, contentDescription = null) }
        }

        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            item { FilterChip(state.period == DashboardPeriod.TODAY, onToday, { Text(stringResource(R.string.ux2_text_3b4a262c54)) }, modifier = Modifier.testTag("home_period_today")) }
            item { FilterChip(state.period == DashboardPeriod.WEEK, onWeek, { Text(stringResource(R.string.ux2_text_400cd4c1c1)) }) }
            item { FilterChip(state.period == DashboardPeriod.MONTH, onMonth, { Text(stringResource(R.string.ux2_text_f2e5afacb4)) }) }
            item { FilterChip(state.period == DashboardPeriod.CUSTOM, onCustom, { Text(stringResource(R.string.ux2_text_16b5730825)) }) }
        }
        if (state.availableBranches.size > 1) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                item { FilterChip(state.selectedBranchName == null, { onBranch(null) }, { Text(stringResource(R.string.ux2_text_ca7206e5f1)) }) }
                items(state.availableBranches, key = { it }) { branch ->
                    FilterChip(state.selectedBranchName == branch, { onBranch(branch) }, { Text(branch) })
                }
            }
        }
        if (state.availableWarehouses.size > 1) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                item { FilterChip(state.selectedWarehouseLocationId == null, { onWarehouse(null) }, { Text(stringResource(R.string.ux2_text_0a7f24b094)) }) }
                items(state.availableWarehouses, key = { it.id }) { warehouse ->
                    FilterChip(state.selectedWarehouseLocationId == warehouse.id, { onWarehouse(warehouse.id) }, { Text(warehouse.name) })
                }
            }
        }
    }
}

@Composable
private fun HomeKpiSummary(kpis: List<DashboardKpiUi>, loading: Boolean, onOpen: (AppScreen) -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 18.dp).testTag("home_kpi_summary"),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        HomeSectionHeading("خلاصه وضعیت", "حداکثر چهار شاخص متناسب با دسترسی شما")
        if (loading) {
            Text("در حال دریافت شاخص‌ها…", color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else if (kpis.isEmpty()) {
            EmptyHomePanel("شاخصی برای نقش فعلی تعریف نشده است.")
        } else {
            kpis.chunked(2).forEach { rowItems ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    rowItems.forEach { kpi ->
                        Card(
                            modifier = Modifier.weight(1f).height(96.dp)
                                .testTag("home_kpi_${kpi.id}")
                                .clickable(enabled = kpi.destination != null) { kpi.destination?.let(onOpen) },
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        ) {
                            Column(Modifier.fillMaxSize().padding(13.dp), verticalArrangement = Arrangement.SpaceBetween) {
                                Text(kpi.title, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    if (kpi.kind == DashboardKpiKind.MONEY) formatMoney(kpi.value) else kpi.value.toString(),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Black,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                        }
                    }
                    if (rowItems.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun HomeQuickActions(actions: List<DashboardQuickActionUi>, onOpen: (AppScreen) -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 18.dp).testTag("home_quick_actions"),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        HomeSectionHeading("کارهای سریع", "مسیرهای پرتکرار و مجاز")
        if (actions.isEmpty()) {
            EmptyHomePanel("عملیات سریعی برای نقش فعلی در دسترس نیست.")
        } else {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                items(actions.take(6), key = { it.id }) { action ->
                    Card(
                        modifier = Modifier.width(132.dp).height(92.dp)
                            .testTag("home_action_${action.id}")
                            .clickable { onOpen(action.destination) },
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
                    ) {
                        Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.Center) {
                            Text(action.title, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                            Spacer(Modifier.height(3.dp))
                            Text(action.subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeAttentionCenter(alerts: List<DashboardAttentionUi>, partialErrors: List<String>, onOpen: (AppScreen) -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 18.dp).testTag("home_attention_center"),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        HomeSectionHeading("نیازمند توجه", "فقط موارد قابل اقدام")
        partialErrors.forEach { error ->
            Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.errorContainer) {
                Text(error, Modifier.fillMaxWidth().padding(12.dp), color = MaterialTheme.colorScheme.onErrorContainer)
            }
        }
        if (alerts.isEmpty()) {
            EmptyHomePanel("مورد فوری برای اقدام وجود ندارد.")
        } else {
            alerts.take(6).forEach { alert ->
                Surface(
                    modifier = Modifier.fillMaxWidth().testTag("home_alert_${alert.id}").clickable { onOpen(alert.destination) },
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                ) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            alert.count.toString(),
                            modifier = Modifier.width(34.dp),
                            color = when (alert.severity) {
                                DashboardAttentionSeverity.CRITICAL -> MaterialTheme.colorScheme.error
                                DashboardAttentionSeverity.WARNING -> MaterialTheme.colorScheme.tertiary
                                DashboardAttentionSeverity.NOTICE -> MaterialTheme.colorScheme.primary
                            },
                            fontWeight = FontWeight.Black,
                        )
                        Column(Modifier.weight(1f)) {
                            Text(alert.title, fontWeight = FontWeight.Bold)
                            Text(alert.explanation, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text("باز کردن", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeSectionHeading(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
        Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun EmptyHomePanel(message: String) {
    Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceContainerLow) {
        Text(message, Modifier.fillMaxWidth().padding(14.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun HomeBottomNavigation(
    onHome: () -> Unit,
    onOperations: () -> Unit,
    onReports: () -> Unit,
    onMore: () -> Unit,
) {
    NavigationBar(modifier = Modifier.testTag("main_bottom_navigation")) {
        NavigationBarItem(true, onHome, { Icon(Icons.Outlined.Home, contentDescription = stringResource(R.string.ux2_text_1e0e4ac2e8)) }, modifier = Modifier.testTag("nav_home"), label = { Text(stringResource(R.string.dashboard_tab_home)) })
        NavigationBarItem(false, onOperations, { Icon(Icons.Outlined.PointOfSale, contentDescription = stringResource(R.string.ux2_text_8d1cc546f4)) }, modifier = Modifier.testTag("nav_operations"), label = { Text(stringResource(R.string.dashboard_tab_operations)) })
        NavigationBarItem(false, onReports, { Icon(Icons.Outlined.Assessment, contentDescription = stringResource(R.string.ux2_text_20ecfa9f52)) }, modifier = Modifier.testTag("nav_reports"), label = { Text(stringResource(R.string.dashboard_tab_reports)) })
        NavigationBarItem(false, onMore, { Icon(Icons.Outlined.MoreHoriz, contentDescription = stringResource(R.string.ux2_text_46dd186fe2)) }, modifier = Modifier.testTag("nav_more"), label = { Text(stringResource(R.string.dashboard_tab_more)) })
    }
}
