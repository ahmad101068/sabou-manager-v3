package ir.sabou.inventory.ui

import ir.sabou.inventory.domain.security.Permission

import ir.sabou.inventory.domain.operations.AppUserRecord

internal fun canOpenScreen(user: AppUserRecord?, screen: AppScreen): Boolean {
    if (screen == AppScreen.SECURITY) return true
    if (user == null) return false
    return when (screen) {
        AppScreen.DASHBOARD,
        AppScreen.OPERATIONS_HUB,
        AppScreen.MORE,
        AppScreen.GLOBAL_SEARCH,
        AppScreen.SETTINGS -> true
        AppScreen.PURCHASES, AppScreen.NEW_PURCHASE -> user.role.allows(Permission.PURCHASES)
        AppScreen.SUPPLIERS -> user.role.allows(Permission.SUPPLIERS)
        AppScreen.INVENTORY, AppScreen.STOCK_MOVEMENTS -> user.role.allows(Permission.INVENTORY)
        AppScreen.SALES, AppScreen.SALES_DAILY_CONTROL -> user.role.allows(Permission.SALES)
        AppScreen.RESTAURANT -> user.role.allows(Permission.RESTAURANT_POS)
        AppScreen.RECIPES -> user.role.allows(Permission.RECIPES)
        AppScreen.ACCOUNTING, AppScreen.NEW_JOURNAL -> user.role.allows(Permission.ACCOUNTING)
        AppScreen.TREASURY -> user.role.allows(Permission.TREASURY)
        AppScreen.CRM -> user.role.allows(Permission.SALES) || user.role.allows(Permission.ACCOUNTING)
        AppScreen.PERSONNEL -> user.role.allows(Permission.PERSONNEL)
        AppScreen.ASSETS -> user.role.allows(Permission.ASSETS)
        AppScreen.ALERTS -> user.role.allows(Permission.ACCOUNTING)
        AppScreen.REPORTS -> user.role.allows(Permission.REPORTS)
        AppScreen.AUDIT_LOG -> user.role.allows(Permission.AUDIT_VIEW) || user.role.allows(Permission.AUDIT)
        AppScreen.MANAGEMENT_CONTROL -> listOf(
            Permission.PURCHASES,
            Permission.INVENTORY,
            Permission.ACCOUNTING,
            Permission.PERSONNEL,
        )
            .any(user.role::allows)
        AppScreen.SECURITY -> true
    }
}
