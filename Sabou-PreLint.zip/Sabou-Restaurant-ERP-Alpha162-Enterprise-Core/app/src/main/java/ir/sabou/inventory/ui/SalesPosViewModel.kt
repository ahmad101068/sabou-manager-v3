package ir.sabou.inventory.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import ir.sabou.inventory.application.sales.SalesUseCases
import ir.sabou.inventory.domain.recipe.MenuItem
import ir.sabou.inventory.domain.sales.CustomerDraft
import ir.sabou.inventory.domain.sales.CustomerRecord
import ir.sabou.inventory.domain.sales.ProfessionalSalesDayClosureRecord
import ir.sabou.inventory.domain.sales.SalesHoldDraft
import ir.sabou.inventory.domain.sales.SalesHoldRecord
import ir.sabou.inventory.domain.sales.SalesInvoiceDetails
import ir.sabou.inventory.domain.sales.SalesInvoiceDraft
import ir.sabou.inventory.domain.sales.SalesInvoiceRecord
import ir.sabou.inventory.domain.sales.SalesReturnDraft
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class SalesPosUiState(
    val invoices: List<SalesInvoiceRecord> = emptyList(),
    val customers: List<CustomerRecord> = emptyList(),
    val holds: List<SalesHoldRecord> = emptyList(),
    val menuItems: List<MenuItem> = emptyList(),
    val dayClosures: List<ProfessionalSalesDayClosureRecord> = emptyList(),
    val selectedInvoiceId: Long? = null,
    val selectedInvoice: SalesInvoiceDetails? = null,
    val resumeDraft: SalesHoldDraft? = null,
    val busy: Boolean = false,
    val message: String? = null,
)

@OptIn(ExperimentalCoroutinesApi::class)
class SalesPosViewModel(
    private val useCases: SalesUseCases,
) : ViewModel() {
    private val query = MutableStateFlow("")
    private val selectedInvoiceId = MutableStateFlow<Long?>(null)
    private val resumeDraft = MutableStateFlow<SalesHoldDraft?>(null)
    private val busy = MutableStateFlow(false)
    private val message = MutableStateFlow<String?>(null)

    private val invoices: Flow<List<SalesInvoiceRecord>> = query.debounce(200).flatMapLatest(useCases::invoices)
    private val selectedInvoice = selectedInvoiceId.flatMapLatest { id ->
        if (id == null) flowOf(null) else useCases.invoiceDetails(id)
    }

    private data class Catalogs(
        val customers: List<CustomerRecord>,
        val holds: List<SalesHoldRecord>,
        val menuItems: List<MenuItem>,
        val dayClosures: List<ProfessionalSalesDayClosureRecord>,
    )

    private data class Selection(
        val selectedInvoiceId: Long?,
        val selectedInvoice: SalesInvoiceDetails?,
        val resumeDraft: SalesHoldDraft?,
    )

    private data class Base(
        val invoices: List<SalesInvoiceRecord>,
        val catalogs: Catalogs,
        val selection: Selection,
    )

    private val catalogs = combine(
        useCases.customers,
        useCases.holds,
        useCases.menuItems,
        useCases.dayClosures,
    ) { customers, holds, menuItems, dayClosures ->
        Catalogs(customers, holds, menuItems, dayClosures)
    }

    private val selection = combine(selectedInvoiceId, selectedInvoice, resumeDraft) { id, invoice, resume ->
        Selection(id, invoice, resume)
    }

    private val base = combine(invoices, catalogs, selection) { invoiceRows, catalogsState, selectionState ->
        Base(invoiceRows, catalogsState, selectionState)
    }

    val state: StateFlow<SalesPosUiState> = combine(base, busy, message) { b, isBusy, msg ->
        SalesPosUiState(
            invoices = b.invoices,
            customers = b.catalogs.customers,
            holds = b.catalogs.holds,
            menuItems = b.catalogs.menuItems,
            dayClosures = b.catalogs.dayClosures,
            selectedInvoiceId = b.selection.selectedInvoiceId,
            selectedInvoice = b.selection.selectedInvoice,
            resumeDraft = b.selection.resumeDraft,
            busy = isBusy,
            message = msg,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SalesPosUiState())

    fun search(value: String) { query.value = value }
    fun selectInvoice(id: Long?) { selectedInvoiceId.value = id }
    fun clearMessage() { message.value = null }
    fun consumeResumeDraft() { resumeDraft.value = null }

    fun post(draft: SalesInvoiceDraft, done: () -> Unit = {}) = launchCommand("فاکتور فروش ثبت شد.", done) {
        useCases.postSale(draft)
    }

    fun returnSale(draft: SalesReturnDraft, done: () -> Unit = {}) = launchCommand("مرجوعی فروش ثبت شد.", done) {
        useCases.returnSale(draft)
    }

    fun voidSale(invoiceId: Long, epochDay: Long, reason: String, done: () -> Unit = {}) =
        launchCommand("فاکتور با سند معکوس ابطال شد.", done) { useCases.voidSale(invoiceId, epochDay, reason) }

    fun printInvoice(invoiceId: Long, done: () -> Unit = {}) =
        launchCommand("فاکتور برای چاپ آماده شد.", done) { useCases.auditInvoicePrint(invoiceId) }

    fun closeDay(businessEpochDay: Long, note: String, done: () -> Unit = {}) =
        launchCommand("روز POS بسته شد و مبالغ صندوق snapshot شدند.", done) { useCases.closeDay(businessEpochDay, note) }

    fun reopenDay(businessEpochDay: Long, reason: String, done: () -> Unit = {}) =
        launchCommand("روز POS با ثبت Audit بازگشایی شد.", done) { useCases.reopenDay(businessEpochDay, reason) }

    fun saveCustomer(id: Long?, draft: CustomerDraft, done: () -> Unit = {}) = launchCommand("اطلاعات مشتری ذخیره شد.", done) {
        useCases.saveCustomer(id, draft)
    }

    fun deactivateCustomer(id: Long) = launchCommand("مشتری غیرفعال شد.") { useCases.deactivateCustomer(id) }

    fun hold(draft: SalesHoldDraft, done: () -> Unit = {}) = launchCommand("سفارش نگه‌داشته شد.", done) {
        useCases.holdSale(draft)
    }

    fun retrieveHold(id: Long, done: () -> Unit = {}) {
        if (busy.value) return
        viewModelScope.launch {
            busy.value = true
            message.value = null
            try {
                resumeDraft.value = useCases.loadHold(id)
                message.value = "سفارش برای ادامه فروش بازیابی شد."
                done()
            } catch (error: Exception) {
                message.value = UiErrorHandler.message("SalesPosViewModel.retrieveHold", error)
            } finally {
                busy.value = false
            }
        }
    }

    fun deleteHold(id: Long) = launchCommand("سفارش نگه‌داشته‌شده حذف شد.") { useCases.deleteHold(id) }

    private fun launchCommand(success: String, done: () -> Unit = {}, block: suspend () -> Any?): Unit {
        if (busy.value) return
        viewModelScope.launch {
            busy.value = true
            message.value = null
            try {
                block()
                message.value = success
                done()
            } catch (error: Exception) {
                message.value = UiErrorHandler.message("SalesPosViewModel.command", error)
            } finally {
                busy.value = false
            }
        }
    }

    companion object {
        fun factory(useCases: SalesUseCases): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T = SalesPosViewModel(useCases) as T
        }
    }
}
