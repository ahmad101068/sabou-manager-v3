package ir.sabou.inventory.ui

import androidx.compose.runtime.Composable

@Composable
internal fun OperationsRoutes(
    screen: AppScreen,
    operationsState: OperationsUiState,
    operations: OperationsViewModel,
    inventoryState: InventoryWorkspaceUiState,
    inventory: InventoryWorkspaceViewModel,
    salesState: DailySalesUiState,
    sales: DailySalesViewModel,
    salesPosState: SalesPosUiState,
    salesPos: SalesPosViewModel,
    recipeState: RecipeUiState,
    recipes: RecipeViewModel,
    restaurantState: RestaurantUiState,
    restaurant: RestaurantViewModel,
    accounting: AccountingViewModel,
    navigate: (AppScreen) -> Unit,
    navigateBack: () -> Unit,
) {
    when (screen) {
        AppScreen.PURCHASES -> PurchasesScreen(
            state = operationsState,
            onSearch = operations::searchPurchases,
            onSelect = operations::selectPurchase,
            onSettle = operations::settlePurchase,
            onReverseSettlement = operations::reversePurchaseSettlement,
            onReverse = operations::reversePurchase,
            onSubmitRequisition = operations::submitRequisition,
            onReviewRequisition = operations::reviewRequisition,
            onCreateOrder = operations::createPurchaseOrder,
            onCreateSplitOrders = operations::createSplitPurchaseOrders,
            onMarkOrderSent = operations::markPurchaseOrderSent,
            onAcknowledgeOrder = operations::acknowledgePurchaseOrder,
            onReceiveGoods = operations::postGoodsReceipt,
            onReturnGoods = operations::postPurchaseReturn,
            onSaveReplenishmentPolicy = operations::saveReplenishmentPolicy,
            onSaveSupplierOffer = operations::saveSupplierOffer,
            onSubmitSuggestedRequisition = operations::submitSuggestedRequisition,
            onMatchInvoice = operations::postMatchedInvoice,
            onAdd = { navigate(AppScreen.NEW_PURCHASE) },
            onBack = {
                operations.selectPurchase(null)
                navigateBack()
            },
        )

        AppScreen.NEW_PURCHASE -> PurchaseEntryScreen(
            state = operationsState,
            onPost = operations::postPurchase,
            onBack = navigateBack,
        )

        AppScreen.SUPPLIERS -> SuppliersScreen(
            state = operationsState,
            onSave = operations::saveSupplier,
            onDeactivate = operations::deactivateSupplier,
            onBack = navigateBack,
        )

        AppScreen.INVENTORY, AppScreen.STOCK_MOVEMENTS -> InventoryRoutes(
            screen = screen,
            state = inventoryState,
            inventory = inventory,
            operationsState = operationsState,
            operations = operations,
            navigateBack = navigateBack,
        )

        AppScreen.SALES -> ProfessionalSalesScreen(
            state = salesPosState,
            onSearch = salesPos::search,
            onSelectInvoice = salesPos::selectInvoice,
            onPost = salesPos::post,
            onReturn = salesPos::returnSale,
            onVoid = salesPos::voidSale,
            onPrint = salesPos::printInvoice,
            onSaveCustomer = salesPos::saveCustomer,
            onDeactivateCustomer = salesPos::deactivateCustomer,
            onHold = salesPos::hold,
            onRetrieveHold = salesPos::retrieveHold,
            onDeleteHold = salesPos::deleteHold,
            onResumeConsumed = salesPos::consumeResumeDraft,
            onCloseDay = salesPos::closeDay,
            onReopenDay = salesPos::reopenDay,
            onOpenDailyControl = { navigate(AppScreen.SALES_DAILY_CONTROL) },
            onBack = navigateBack,
        )

        AppScreen.SALES_DAILY_CONTROL -> DailySalesScreen(
            state = salesState,
            onSearch = sales::search,
            onPost = sales::post,
            onReverse = sales::reverse,
            onCloseDay = sales::closeDay,
            onReopenDay = sales::reopenDay,
            onSetReportRange = { from, to ->
                sales.setReportRange(from, to)
                accounting.setProfitLossRange(from, to)
            },
            onBack = navigateBack,
        )

        AppScreen.RECIPES -> RecipeScreen(
            state = recipeState,
            onSelect = recipes::select,
            onSave = recipes::save,
            onCreateDraft = recipes::createDraftFrom,
            onCopyVersion = recipes::copyVersion,
            onLoadDraft = recipes::loadDraft,
            onEditDraft = recipes::editDraft,
            onCloseDraftEditor = recipes::closeDraftEditor,
            onActivate = recipes::activate,
            onRetire = recipes::retire,
            onSubstitution = recipes::approveSubstitution,
            onBack = {
                recipes.select(null)
                navigateBack()
            },
        )

        AppScreen.RESTAURANT -> RestaurantScreen(
            state = restaurantState,
            onSelectOrder = restaurant::selectOrder,
            onCreateHall = restaurant::createHall,
            onCreateTable = restaurant::createTable,
            onReserve = restaurant::reserve,
            onReservationStatus = restaurant::reservationStatus,
            onOpenTable = restaurant::openTable,
            onAddItem = restaurant::addItem,
            onChangeQuantity = restaurant::changeQuantity,
            onTransfer = restaurant::transfer,
            onMerge = restaurant::merge,
            onKitchen = restaurant::kitchen,
            onClose = restaurant::close,
            onBack = navigateBack,
        )

        else -> error("operations_route_group_mismatch:${screen.name}")
    }
}
