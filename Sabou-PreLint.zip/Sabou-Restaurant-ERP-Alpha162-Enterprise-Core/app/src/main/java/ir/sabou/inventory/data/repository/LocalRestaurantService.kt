package ir.sabou.inventory.data.repository

import androidx.room.withTransaction
import ir.sabou.inventory.core.MoneyRial
import ir.sabou.inventory.core.QuantityMicros
import ir.sabou.inventory.core.currentLocalEpochDay
import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.db.KitchenTicketEntity
import ir.sabou.inventory.data.db.KitchenTicketEventEntity
import ir.sabou.inventory.data.db.RestaurantBillSplitEntity
import ir.sabou.inventory.data.db.RestaurantHallEntity
import ir.sabou.inventory.data.db.RestaurantOrderEntity
import ir.sabou.inventory.data.db.RestaurantOrderLineEntity
import ir.sabou.inventory.data.db.RestaurantReservationEntity
import ir.sabou.inventory.data.db.RestaurantTableEntity
import ir.sabou.inventory.domain.restaurant.KitchenTicketRecord
import ir.sabou.inventory.domain.restaurant.KitchenTicketStatus
import ir.sabou.inventory.domain.restaurant.OpenTableCommand
import ir.sabou.inventory.domain.restaurant.RestaurantOrderLineDraft
import ir.sabou.inventory.domain.restaurant.RestaurantHallRecord
import ir.sabou.inventory.domain.restaurant.RestaurantOrderLineRecord
import ir.sabou.inventory.domain.restaurant.RestaurantCourse
import ir.sabou.inventory.domain.restaurant.RestaurantOrderRecord
import ir.sabou.inventory.domain.restaurant.RestaurantReservationRecord
import ir.sabou.inventory.domain.restaurant.RestaurantReservationStatus
import ir.sabou.inventory.domain.restaurant.RestaurantOrderStatus
import ir.sabou.inventory.domain.restaurant.RestaurantPaymentSplit
import ir.sabou.inventory.domain.restaurant.RestaurantService
import ir.sabou.inventory.domain.restaurant.RestaurantTableRecord
import ir.sabou.inventory.domain.restaurant.RestaurantTableStatus
import ir.sabou.inventory.domain.restaurant.TableReservationDraft
import ir.sabou.inventory.domain.sales.ProfessionalSalesRepository
import ir.sabou.inventory.domain.sales.SalesInvoiceDraft
import ir.sabou.inventory.domain.sales.SalesLineDraft
import ir.sabou.inventory.domain.sales.SalesPaymentDraft
import ir.sabou.inventory.domain.sales.SalesPaymentMethod
import ir.sabou.inventory.domain.security.AuthorizationService
import ir.sabou.inventory.domain.security.Permission
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/** Transactional restaurant table/KDS coordinator backed by Room and professional POS. */
class LocalRestaurantService(
    private val database: AppDatabase,
    private val sales: ProfessionalSalesRepository,
    private val authorizer: AuthorizationService,
    private val clock: () -> Long = System::currentTimeMillis,
    private val epochDay: () -> Long = ::currentLocalEpochDay,
) : RestaurantService {
    private val audit = LocalAuditEventWriter(database)

    override val halls: Flow<List<RestaurantHallRecord>> = database.restaurantDao().observeHalls().map { rows ->
        rows.map { RestaurantHallRecord(it.id, it.name, it.sortOrder) }
    }

    override val tables: Flow<List<RestaurantTableRecord>> = database.restaurantDao().observeTables().map { rows ->
        rows.map { row ->
            RestaurantTableRecord(
                id = row.id,
                hallId = row.hallId,
                tableNo = row.tableNo,
                capacity = row.capacity,
                status = RestaurantTableStatus.valueOf(row.status),
                currentOrderId = row.currentOrderId,
            )
        }
    }

    override val reservations: Flow<List<RestaurantReservationRecord>> = database.restaurantDao().observeActiveReservations().map { rows ->
        rows.map { row ->
            RestaurantReservationRecord(
                id = row.id,
                customerId = row.customerId,
                guestName = row.guestName,
                guestPhone = row.guestPhone,
                reservationEpochDay = row.reservationEpochDay,
                startMinuteOfDay = row.startMinuteOfDay,
                guestCount = row.guestCount,
                tableId = row.tableId,
                status = RestaurantReservationStatus.valueOf(row.status),
                note = row.note,
            )
        }
    }

    override val openOrders: Flow<List<RestaurantOrderRecord>> = database.restaurantDao().observeOpenOrders().map { rows ->
        rows.map { row ->
            RestaurantOrderRecord(
                id = row.id,
                tableId = row.tableId,
                waiterUserId = row.waiterUserId,
                shiftReference = row.shiftReference,
                customerId = row.customerId,
                guestCount = row.guestCount,
                status = RestaurantOrderStatus.valueOf(row.status),
                openedEpochDay = row.openedEpochDay,
            )
        }
    }

    override val kitchenTickets: Flow<List<KitchenTicketRecord>> = database.restaurantDao().observeActiveKitchenTickets().map { rows ->
        rows.map { row -> KitchenTicketRecord(row.id, row.orderLineId, KitchenTicketStatus.valueOf(row.status), row.updatedAtEpochMillis) }
    }

    override fun observeOrderLines(orderId: Long): Flow<List<RestaurantOrderLineRecord>> {
        require(orderId > 0)
        return database.restaurantDao().observeOrderLines(orderId).map { rows ->
            rows.filter { it.status == "ACTIVE" }.map { row ->
                RestaurantOrderLineRecord(
                    id = row.id, orderId = row.orderId, menuItemId = row.menuItemId, name = row.menuItemNameSnapshot,
                    course = RestaurantCourse.valueOf(row.course), quantity = QuantityMicros.of(row.quantityMicros),
                    unitPrice = MoneyRial.of(row.unitPriceRial), note = row.note,
                )
            }
        }
    }

    override suspend fun createHall(name: String): Long {
        authorizer.require(Permission.RESTAURANT_POS)
        val normalized = name.trim()
        require(normalized.length in 2..80) { "نام سالن باید بین ۲ تا ۸۰ نویسه باشد." }
        return database.withTransaction {
            val now = clock()
            val sortOrder = Math.addExact(database.restaurantDao().maxHallSortOrder(), 10)
            val id = database.restaurantDao().insertHall(
                RestaurantHallEntity(name = normalized, sortOrder = sortOrder, createdAtEpochMillis = now),
            )
            audit.appendAuthorized(
                authorizer, "CREATE", "RESTAURANT_HALL", id,
                "ایجاد سالن $normalized", now, epochDay(), "تعریف سالن رستوران",
                afterSnapshot = "name=$normalized;sortOrder=$sortOrder",
                correlationId = "restaurant:hall:$id",
            )
            id
        }
    }

    override suspend fun createTable(hallId: Long, tableNo: String, capacity: Int): Long {
        authorizer.require(Permission.RESTAURANT_POS)
        val normalized = tableNo.trim()
        require(hallId > 0 && normalized.isNotBlank() && normalized.length <= 30)
        require(capacity in 1..50)
        return database.withTransaction {
            val now = clock()
            val id = database.restaurantDao().insertTable(
                RestaurantTableEntity(hallId = hallId, tableNo = normalized, capacity = capacity, updatedAtEpochMillis = now),
            )
            audit.appendAuthorized(
                authorizer, "CREATE", "RESTAURANT_TABLE", id,
                "ایجاد میز $normalized با ظرفیت $capacity", now, epochDay(), "ایجاد میز سالن",
                afterSnapshot = "hall=$hallId;table=$normalized;capacity=$capacity",
                correlationId = "restaurant:table:$id",
            )
            id
        }
    }

    override suspend fun reserve(draft: TableReservationDraft): Long {
        authorizer.require(Permission.RESTAURANT_POS)
        val valid = draft.validated()
        return database.withTransaction {
            val table = database.restaurantDao().tableById(valid.tableId) ?: error("میز پیدا نشد.")
            require(valid.guestCount <= table.capacity) { "تعداد مهمان از ظرفیت میز بیشتر است." }
            valid.customerId?.let { require(database.salesDao().activeCustomerById(it) != null) { "مشتری فعال رزرو پیدا نشد." } }
            val now = clock()
            val actor = authorizer.actorIdentity()
            val id = database.restaurantDao().insertReservation(
                RestaurantReservationEntity(
                    customerId = valid.customerId,
                    guestName = valid.guestName,
                    guestPhone = valid.guestPhone,
                    reservationEpochDay = valid.reservationEpochDay,
                    startMinuteOfDay = valid.startMinuteOfDay,
                    guestCount = valid.guestCount,
                    tableId = valid.tableId,
                    note = valid.note,
                    createdByActorId = actor.id,
                    createdAtEpochMillis = now,
                    updatedAtEpochMillis = now,
                ),
            )
            if (valid.reservationEpochDay == epochDay() && table.status == RestaurantTableStatus.AVAILABLE.name) {
                check(database.restaurantDao().updateTable(table.copy(status = RestaurantTableStatus.RESERVED.name, updatedAtEpochMillis = now)) == 1) { "وضعیت میز برای رزرو به‌روزرسانی نشد." }
            }
            audit.appendAuthorized(
                authorizer, "CREATE", "RESTAURANT_RESERVATION", id,
                "رزرو میز ${table.tableNo} برای ${valid.guestName}", now, valid.reservationEpochDay, "ثبت رزرو میز",
                afterSnapshot = "table=${valid.tableId};guestCount=${valid.guestCount};minute=${valid.startMinuteOfDay}",
                correlationId = "restaurant:reservation:$id",
            )
            id
        }
    }

    override suspend fun transitionReservation(reservationId: Long, to: RestaurantReservationStatus, reason: String) {
        authorizer.require(Permission.RESTAURANT_POS)
        require(reservationId > 0) { "رزرو معتبر نیست." }
        database.withTransaction {
            val current = database.restaurantDao().reservationById(reservationId) ?: error("رزرو پیدا نشد.")
            val from = RestaurantReservationStatus.valueOf(current.status)
            require(to in allowedReservationTransitions.getValue(from)) { "تغییر وضعیت رزرو مجاز نیست: $from → $to" }
            val normalizedReason = reason.trim()
            if (to == RestaurantReservationStatus.CANCELLED || to == RestaurantReservationStatus.NO_SHOW) {
                require(normalizedReason.length in 3..300) { "دلیل لغو/عدم مراجعه رزرو الزامی است." }
            } else {
                require(normalizedReason.length <= 300) { "توضیح تغییر وضعیت رزرو طولانی است." }
            }
            val now = clock()
            check(database.restaurantDao().updateReservation(current.copy(status = to.name, updatedAtEpochMillis = now)) == 1) { "وضعیت رزرو به‌روزرسانی نشد." }
            val table = database.restaurantDao().tableById(current.tableId) ?: error("میز رزرو پیدا نشد.")
            if (current.reservationEpochDay == epochDay()) {
                when (to) {
                    RestaurantReservationStatus.BOOKED,
                    RestaurantReservationStatus.CONFIRMED,
                    -> if (table.status == RestaurantTableStatus.AVAILABLE.name) {
                        check(database.restaurantDao().updateTable(table.copy(status = RestaurantTableStatus.RESERVED.name, updatedAtEpochMillis = now)) == 1)
                    }
                    RestaurantReservationStatus.CANCELLED,
                    RestaurantReservationStatus.NO_SHOW,
                    RestaurantReservationStatus.COMPLETED,
                    -> if (table.status == RestaurantTableStatus.RESERVED.name && database.restaurantDao().activeReservationCountForTable(table.id, current.reservationEpochDay, current.id) == 0) {
                        check(database.restaurantDao().updateTable(table.copy(status = RestaurantTableStatus.AVAILABLE.name, updatedAtEpochMillis = now)) == 1)
                    }
                    RestaurantReservationStatus.SEATED -> Unit
                }
            }
            audit.appendAuthorized(
                authorizer, "STATE_CHANGE", "RESTAURANT_RESERVATION", current.id,
                "$from → $to", now, current.reservationEpochDay,
                normalizedReason.ifBlank { "تغییر وضعیت رزرو" }, beforeSnapshot = "status=$from", afterSnapshot = "status=$to",
                correlationId = "restaurant:reservation:${current.id}",
            )
        }
    }

    override suspend fun openTable(command: OpenTableCommand): Long {
        authorizer.require(Permission.RESTAURANT_POS)
        require(command.tableId > 0 && command.guestCount in 1..100)
        require(command.shiftReference.trim().length <= 80) { "مرجع شیفت طولانی است." }
        require(command.note.trim().length <= 500) { "یادداشت سفارش طولانی است." }
        val commandId = ir.sabou.inventory.core.GlobalId.parse(command.commandId).value
        return database.withTransaction {
            database.restaurantDao().orderByCommandId(commandId)?.let { return@withTransaction it.id }
            val table = database.restaurantDao().tableById(command.tableId) ?: error("میز پیدا نشد.")
            require(table.status != RestaurantTableStatus.OCCUPIED.name && table.currentOrderId == null) { "میز در حال استفاده است." }
            require(command.guestCount <= table.capacity) { "تعداد مهمان از ظرفیت میز بیشتر است." }
            val now = clock()
            val actor = authorizer.actorIdentity()
            val waiter = command.waiterUserId ?: actor.id
            val waiterUser = database.securityDao().byId(waiter) ?: error("کاربر گارسون پیدا نشد.")
            require(waiterUser.isActive) { "کاربر گارسون غیرفعال است." }
            command.customerId?.let { require(database.salesDao().activeCustomerById(it) != null) { "مشتری فعال سفارش پیدا نشد." } }
            val orderId = database.restaurantDao().insertOrder(
                RestaurantOrderEntity(
                    commandId = commandId,
                    tableId = table.id,
                    waiterUserId = waiter,
                    shiftReference = command.shiftReference.trim(),
                    customerId = command.customerId,
                    guestCount = command.guestCount,
                    openedEpochDay = epochDay(),
                    openedAtEpochMillis = now,
                    note = command.note.trim(),
                ),
            )
            require(
                database.restaurantDao().updateTable(
                    table.copy(status = RestaurantTableStatus.OCCUPIED.name, currentOrderId = orderId, updatedAtEpochMillis = now),
                ) == 1,
            )
            audit.appendAuthorized(
                authorizer, "OPEN", "RESTAURANT_ORDER", orderId,
                "بازکردن میز ${table.tableNo}", now, epochDay(), "شروع سرویس میز",
                afterSnapshot = "table=${table.id};guestCount=${command.guestCount};waiter=$waiter;shift=${command.shiftReference.trim()}",
                correlationId = "restaurant:order:$orderId",
            )
            orderId
        }
    }

    override suspend fun addItem(draft: RestaurantOrderLineDraft): Long {
        authorizer.require(Permission.RESTAURANT_POS)
        require(draft.orderId > 0 && draft.menuItemId > 0 && draft.quantity > QuantityMicros.ZERO)
        require(draft.note.trim().length <= 300)
        return database.withTransaction {
            val order = database.restaurantDao().orderById(draft.orderId) ?: error("سفارش میز پیدا نشد.")
            require(order.status == RestaurantOrderStatus.OPEN.name) { "سفارش میز بسته شده است." }
            val menu = database.recipeDao().activeMenuItem(draft.menuItemId) ?: error("آیتم فعال منو پیدا نشد.")
            require(menu.salePriceRial > 0) { "قیمت فروش آیتم منو معتبر نیست." }
            val now = clock()
            val actor = authorizer.actorIdentity()
            val lineId = database.restaurantDao().insertOrderLine(
                RestaurantOrderLineEntity(
                    orderId = order.id,
                    menuItemId = menu.id,
                    menuItemNameSnapshot = menu.name,
                    course = draft.course.name,
                    quantityMicros = draft.quantity.value,
                    unitPriceRial = menu.salePriceRial,
                    note = draft.note.trim(),
                    createdAtEpochMillis = now,
                    updatedAtEpochMillis = now,
                ),
            )
            val ticketId = database.restaurantDao().insertKitchenTicket(
                KitchenTicketEntity(orderLineId = lineId, updatedByActorId = actor.id, updatedAtEpochMillis = now),
            )
            database.restaurantDao().insertKitchenEvent(
                KitchenTicketEventEntity(ticketId = ticketId, fromStatus = "", toStatus = KitchenTicketStatus.NEW.name, actorId = actor.id, createdAtEpochMillis = now),
            )
            audit.appendAuthorized(
                authorizer, "ADD_ITEM", "RESTAURANT_ORDER", order.id,
                "${menu.name} × ${draft.quantity.value}", now, order.openedEpochDay, "افزودن آیتم به سفارش میز",
                afterSnapshot = "line=$lineId;menu=${menu.id};quantity=${draft.quantity.value};course=${draft.course.name};ticket=$ticketId",
                correlationId = "restaurant:order:${order.id}",
            )
            lineId
        }
    }

    override suspend fun changeQuantity(lineId: Long, quantity: QuantityMicros) {
        authorizer.require(Permission.RESTAURANT_POS)
        require(quantity > QuantityMicros.ZERO)
        database.withTransaction {
            val line = database.restaurantDao().orderLineById(lineId) ?: error("ردیف سفارش پیدا نشد.")
            val order = database.restaurantDao().orderById(line.orderId) ?: error("سفارش پیدا نشد.")
            require(order.status == RestaurantOrderStatus.OPEN.name)
            val ticket = database.restaurantDao().kitchenTicketByOrderLine(line.id)
            require(ticket == null || ticket.status in setOf(KitchenTicketStatus.NEW.name, KitchenTicketStatus.ACCEPTED.name)) {
                "بعد از شروع آماده‌سازی، مقدار ردیف باید با لغو کنترل‌شده و ردیف جدید اصلاح شود."
            }
            val now = clock()
            require(database.restaurantDao().updateOrderLine(line.copy(quantityMicros = quantity.value, updatedAtEpochMillis = now)) == 1)
            audit.appendAuthorized(
                authorizer, "UPDATE_QUANTITY", "RESTAURANT_ORDER_LINE", line.id,
                "اصلاح مقدار ${line.menuItemNameSnapshot}", now, order.openedEpochDay, "اصلاح مقدار قبل از آماده‌سازی",
                beforeSnapshot = "quantity=${line.quantityMicros}", afterSnapshot = "quantity=${quantity.value}",
                correlationId = "restaurant:order:${order.id}",
            )
        }
    }

    override suspend fun transferTable(orderId: Long, targetTableId: Long, reason: String) {
        authorizer.require(Permission.RESTAURANT_POS)
        require(reason.trim().length in 3..300)
        database.withTransaction {
            val order = database.restaurantDao().orderById(orderId) ?: error("سفارش پیدا نشد.")
            require(order.status == RestaurantOrderStatus.OPEN.name)
            val source = database.restaurantDao().tableById(order.tableId) ?: error("میز مبدأ پیدا نشد.")
            val target = database.restaurantDao().tableById(targetTableId) ?: error("میز مقصد پیدا نشد.")
            require(target.id != source.id && target.currentOrderId == null && target.status != RestaurantTableStatus.OCCUPIED.name) { "میز مقصد آزاد نیست." }
            val now = clock()
            require(database.restaurantDao().updateOrder(order.copy(tableId = target.id)) == 1)
            require(database.restaurantDao().updateTable(source.copy(status = RestaurantTableStatus.AVAILABLE.name, currentOrderId = null, updatedAtEpochMillis = now)) == 1)
            require(database.restaurantDao().updateTable(target.copy(status = RestaurantTableStatus.OCCUPIED.name, currentOrderId = order.id, updatedAtEpochMillis = now)) == 1)
            audit.appendAuthorized(
                authorizer, "TRANSFER", "RESTAURANT_ORDER", order.id,
                "انتقال میز ${source.tableNo} به ${target.tableNo}", now, order.openedEpochDay, reason.trim(),
                beforeSnapshot = "table=${source.id}", afterSnapshot = "table=${target.id}",
                correlationId = "restaurant:order:${order.id}",
            )
        }
    }

    override suspend fun mergeTables(sourceOrderId: Long, targetOrderId: Long, reason: String) {
        authorizer.require(Permission.RESTAURANT_MERGE)
        require(sourceOrderId > 0 && targetOrderId > 0 && sourceOrderId != targetOrderId)
        require(reason.trim().length in 3..300)
        database.withTransaction {
            val sourceOrder = database.restaurantDao().orderById(sourceOrderId) ?: error("سفارش مبدأ پیدا نشد.")
            val targetOrder = database.restaurantDao().orderById(targetOrderId) ?: error("سفارش مقصد پیدا نشد.")
            require(sourceOrder.status == RestaurantOrderStatus.OPEN.name && targetOrder.status == RestaurantOrderStatus.OPEN.name)
            val sourceTable = database.restaurantDao().tableById(sourceOrder.tableId) ?: error("میز مبدأ پیدا نشد.")
            val now = clock()
            database.restaurantDao().moveActiveLines(sourceOrder.id, targetOrder.id, now)
            require(database.restaurantDao().updateOrder(sourceOrder.copy(status = RestaurantOrderStatus.MERGED.name, closedAtEpochMillis = now, note = reason.trim())) == 1)
            require(database.restaurantDao().updateTable(sourceTable.copy(status = RestaurantTableStatus.AVAILABLE.name, currentOrderId = null, updatedAtEpochMillis = now)) == 1)
            audit.appendAuthorized(
                authorizer, "MERGE", "RESTAURANT_ORDER", sourceOrder.id,
                "ادغام سفارش میز در سفارش $targetOrderId", now, sourceOrder.openedEpochDay, reason.trim(),
                beforeSnapshot = "source=$sourceOrderId;target=$targetOrderId", afterSnapshot = "sourceStatus=MERGED;linesMoved=true",
                correlationId = "restaurant:merge:$sourceOrderId:$targetOrderId",
            )
        }
    }

    override suspend fun transitionKitchen(ticketId: Long, to: KitchenTicketStatus, reason: String) {
        authorizer.require(Permission.KITCHEN)
        database.withTransaction {
            val ticket = database.restaurantDao().kitchenTicketById(ticketId) ?: error("تیکت آشپزخانه پیدا نشد.")
            val from = KitchenTicketStatus.valueOf(ticket.status)
            require(to in allowedKitchenTransitions.getValue(from)) { "تغییر وضعیت KDS مجاز نیست: $from → $to" }
            val normalizedReason = reason.trim()
            if (to == KitchenTicketStatus.CANCELLED) require(normalizedReason.length in 3..300) { "دلیل لغو الزامی است." }
            val actor = authorizer.actorIdentity()
            val now = clock()
            val updated = when (to) {
                KitchenTicketStatus.NEW -> ticket
                KitchenTicketStatus.ACCEPTED -> ticket.copy(status = to.name, acceptedAtEpochMillis = now, updatedByActorId = actor.id, updatedAtEpochMillis = now)
                KitchenTicketStatus.PREPARING -> ticket.copy(status = to.name, preparingAtEpochMillis = now, updatedByActorId = actor.id, updatedAtEpochMillis = now)
                KitchenTicketStatus.READY -> ticket.copy(status = to.name, readyAtEpochMillis = now, updatedByActorId = actor.id, updatedAtEpochMillis = now)
                KitchenTicketStatus.SERVED -> ticket.copy(status = to.name, servedAtEpochMillis = now, updatedByActorId = actor.id, updatedAtEpochMillis = now)
                KitchenTicketStatus.CANCELLED -> ticket.copy(status = to.name, cancelledAtEpochMillis = now, cancelReason = normalizedReason, updatedByActorId = actor.id, updatedAtEpochMillis = now)
            }
            require(database.restaurantDao().updateKitchenTicket(updated) == 1)
            database.restaurantDao().insertKitchenEvent(
                KitchenTicketEventEntity(ticketId = ticket.id, fromStatus = from.name, toStatus = to.name, reason = normalizedReason, actorId = actor.id, createdAtEpochMillis = now),
            )
            audit.appendAuthorized(
                authorizer, "STATE_CHANGE", "KITCHEN_TICKET", ticket.id,
                "$from → $to", now, epochDay(), normalizedReason.ifBlank { "تغییر وضعیت تیکت آشپزخانه" },
                beforeSnapshot = "status=$from", afterSnapshot = "status=$to",
                correlationId = "kds:ticket:${ticket.id}",
            )
        }
    }

    override suspend fun closeTable(orderId: Long, payments: List<RestaurantPaymentSplit>, dueEpochDay: Long?): ir.sabou.inventory.domain.sales.PostedSalesInvoice {
        authorizer.require(Permission.RESTAURANT_POS)
        val validPayments = payments.map(RestaurantPaymentSplit::validated)
        require(validPayments.isNotEmpty())
        return database.withTransaction {
            val order = database.restaurantDao().orderById(orderId) ?: error("سفارش میز پیدا نشد.")
            require(order.status == RestaurantOrderStatus.OPEN.name)
            val table = database.restaurantDao().tableById(order.tableId) ?: error("میز پیدا نشد.")
            val lines = database.restaurantDao().activeOrderLines(order.id)
            require(lines.isNotEmpty()) { "سفارش میز ردیف فعال ندارد." }
            val grouped = lines.groupBy { it.menuItemId }.map { (menuId, sameMenu) ->
                val prices = sameMenu.map { it.unitPriceRial }.distinct()
                require(prices.size == 1) { "یک آیتم با قیمت‌های متفاوت در سفارش وجود دارد؛ قبل از بستن میز اصلاح شود." }
                SalesLineDraft(
                    menuItemId = menuId,
                    quantity = QuantityMicros.positive(sameMenu.sumOf { it.quantityMicros }),
                    unitPrice = MoneyRial.of(prices.single()),
                )
            }
            val expected = grouped.fold(MoneyRial.ZERO) { total, line -> total + line.unitPrice.times(line.quantity) }
            val paid = MoneyRial.sum(validPayments.map { it.amount })
            require(paid == expected) { "جمع پرداخت‌های تفکیکی باید دقیقاً برابر صورتحساب باشد." }
            val itemSplitMode = validPayments.any { it.orderLineId != null }
            require(!itemSplitMode || validPayments.all { it.orderLineId != null }) { "تقسیم صورتحساب باید یا کاملاً بر اساس آیتم باشد یا کاملاً بر اساس مبلغ." }
            if (itemSplitMode) {
                val linesById = lines.associateBy { it.id }
                require(validPayments.all { it.orderLineId in linesById }) { "یکی از آیتم‌های تقسیم صورتحساب متعلق به این سفارش نیست." }
                val allocatedByLine = validPayments.groupBy { requireNotNull(it.orderLineId) }.mapValues { (_, rows) -> MoneyRial.sum(rows.map { it.amount }) }
                require(lines.all { line -> allocatedByLine[line.id] == MoneyRial.of(line.unitPriceRial).times(QuantityMicros.of(line.quantityMicros)) }) {
                    "در تقسیم بر اساس آیتم، جمع سهم هر آیتم باید دقیقاً برابر مبلغ همان آیتم باشد."
                }
            }
            val hasCredit = validPayments.any { it.method == SalesPaymentMethod.CREDIT }
            if (hasCredit) {
                require(order.customerId != null) { "برای سهم اعتباری باید مشتری انتخاب شود." }
                require(dueEpochDay != null && dueEpochDay >= order.openedEpochDay) { "سررسید فروش اعتباری معتبر نیست." }
            }
            val posted = sales.post(
                SalesInvoiceDraft(
                    businessEpochDay = epochDay(),
                    branchName = order.customerId?.let { database.salesDao().customerById(it)?.branch }.orEmpty(),
                    customerId = order.customerId,
                    dueEpochDay = dueEpochDay,
                    notes = "سفارش میز ${table.tableNo} / order=${order.id}",
                    lines = grouped,
                    payments = validPayments.map { SalesPaymentDraft(it.method, it.amount, it.referenceNo) },
                    commandId = "00000000-0000-4000-8000-${order.id.toString().padStart(12, '0').takeLast(12)}",
                ),
            )
            val now = clock()
            database.restaurantDao().deleteBillSplits(order.id)
            database.restaurantDao().insertBillSplits(
                validPayments.map { RestaurantBillSplitEntity(orderId = order.id, payerNo = it.payerNo, method = it.method.name, amountRial = it.amount.value, referenceNo = it.referenceNo, orderLineId = it.orderLineId) },
            )
            require(database.restaurantDao().updateOrder(order.copy(status = RestaurantOrderStatus.CLOSED.name, closedAtEpochMillis = now, salesInvoiceId = posted.id)) == 1)
            require(database.restaurantDao().updateTable(table.copy(status = RestaurantTableStatus.AVAILABLE.name, currentOrderId = null, updatedAtEpochMillis = now)) == 1)
            audit.appendAuthorized(
                authorizer, "CLOSE", "RESTAURANT_ORDER", order.id,
                "بستن میز ${table.tableNo} با فاکتور ${posted.invoiceNo}", now, epochDay(), "تسویه و بستن میز",
                beforeSnapshot = "status=OPEN;table=${table.id}", afterSnapshot = "status=CLOSED;invoice=${posted.id};net=${posted.netRial}",
                correlationId = "restaurant:order:${order.id}:close",
                referenceType = "SALES_INVOICE",
                referenceId = posted.id,
            )
            posted
        }
    }

    private companion object {
        val allowedReservationTransitions = mapOf(
            RestaurantReservationStatus.BOOKED to setOf(RestaurantReservationStatus.CONFIRMED, RestaurantReservationStatus.SEATED, RestaurantReservationStatus.CANCELLED, RestaurantReservationStatus.NO_SHOW),
            RestaurantReservationStatus.CONFIRMED to setOf(RestaurantReservationStatus.SEATED, RestaurantReservationStatus.CANCELLED, RestaurantReservationStatus.NO_SHOW),
            RestaurantReservationStatus.SEATED to setOf(RestaurantReservationStatus.COMPLETED),
            RestaurantReservationStatus.COMPLETED to emptySet(),
            RestaurantReservationStatus.CANCELLED to emptySet(),
            RestaurantReservationStatus.NO_SHOW to emptySet(),
        )

        val allowedKitchenTransitions = mapOf(
            KitchenTicketStatus.NEW to setOf(KitchenTicketStatus.ACCEPTED, KitchenTicketStatus.CANCELLED),
            KitchenTicketStatus.ACCEPTED to setOf(KitchenTicketStatus.PREPARING, KitchenTicketStatus.CANCELLED),
            KitchenTicketStatus.PREPARING to setOf(KitchenTicketStatus.READY, KitchenTicketStatus.CANCELLED),
            KitchenTicketStatus.READY to setOf(KitchenTicketStatus.SERVED, KitchenTicketStatus.CANCELLED),
            KitchenTicketStatus.SERVED to emptySet(),
            KitchenTicketStatus.CANCELLED to emptySet(),
        )
    }
}
