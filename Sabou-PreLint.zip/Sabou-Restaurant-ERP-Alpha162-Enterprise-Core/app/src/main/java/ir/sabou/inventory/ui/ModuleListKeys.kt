package ir.sabou.inventory.ui

internal fun crmCustomerListKey(id: Long): String = "crm-customer-$id"
internal fun crmFollowUpListKey(id: Long): String = "crm-follow-up-$id"

internal fun restaurantTableListKey(id: Long): String = "restaurant-table-$id"
internal fun restaurantTicketListKey(id: Long): String = "restaurant-ticket-$id"
internal fun restaurantApprovalListKey(id: Long): String = "restaurant-approval-$id"
internal fun restaurantShiftListKey(id: Long): String = "restaurant-shift-$id"
