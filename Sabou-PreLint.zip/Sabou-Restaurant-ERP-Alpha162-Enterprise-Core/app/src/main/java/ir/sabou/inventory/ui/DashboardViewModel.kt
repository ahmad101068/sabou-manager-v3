package ir.sabou.inventory.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import ir.sabou.inventory.core.currentLocalEpochDay
import ir.sabou.inventory.data.repository.DashboardPeriod
import ir.sabou.inventory.data.repository.DashboardRepository
import ir.sabou.inventory.data.repository.DashboardSnapshot
import ir.sabou.inventory.domain.operations.AppUserRecord
import java.time.LocalDate
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.stateIn

class DashboardViewModel(
    private val repository: DashboardRepository,
    private val epochDay: () -> Long = ::currentLocalEpochDay,
    private val rolloverPollMillis: Long = 60_000L,
) : ViewModel() {
    private val period = MutableStateFlow(DashboardPeriod.TODAY)
    private val customRange = MutableStateFlow(0L to 0L)
    private val branchName = MutableStateFlow<String?>(null)
    private val warehouseLocationId = MutableStateFlow<Long?>(null)
    private val dashboardContext = MutableStateFlow(DashboardContext(null, ""))
    private val currentDay = flow {
        while (true) {
            emit(epochDay())
            delay(rolloverPollMillis)
        }
    }.distinctUntilChanged()

    private val range = combine(currentDay, period, customRange) { today, selected, custom ->
        val result = when (selected) {
            DashboardPeriod.TODAY -> today to today
            DashboardPeriod.WEEK -> (today - (LocalDate.ofEpochDay(today).dayOfWeek.value.toLong() - 1L)) to today
            DashboardPeriod.MONTH -> LocalDate.ofEpochDay(today).withDayOfMonth(1).toEpochDay() to today
            DashboardPeriod.CUSTOM -> custom
        }
        require(result.first > 0 && result.second >= result.first) { "بازه داشبورد معتبر نیست." }
        Triple(result.first, result.second, selected)
    }

    private val query = combine(range, branchName, warehouseLocationId) { selectedRange, branch, warehouse ->
        DashboardQuery(selectedRange.first, selectedRange.second, selectedRange.third, branch, warehouse)
    }

    val state: StateFlow<DashboardSnapshot> = query.flatMapLatest { selected ->
        repository.observeRange(
            selected.fromEpochDay,
            selected.toEpochDay,
            selected.period,
            selected.branchName,
            selected.warehouseLocationId,
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = DashboardSnapshot(),
    )

    val homeState: StateFlow<DashboardUiState> = combine(state, dashboardContext) { snapshot, context ->
        DashboardUxComposer.compose(snapshot, context.user, context.organizationName)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = DashboardUiState(),
    )

    fun setContext(user: AppUserRecord?, organizationName: String) {
        dashboardContext.value = DashboardContext(user, organizationName.trim())
    }

    fun today() { period.value = DashboardPeriod.TODAY }
    fun week() { period.value = DashboardPeriod.WEEK }
    fun month() { period.value = DashboardPeriod.MONTH }
    fun custom(fromEpochDay: Long, toEpochDay: Long) {
        require(fromEpochDay > 0 && toEpochDay >= fromEpochDay)
        customRange.value = fromEpochDay to toEpochDay
        period.value = DashboardPeriod.CUSTOM
    }

    fun branch(value: String?) {
        branchName.value = value?.trim()?.takeIf { it.isNotEmpty() }
    }

    fun warehouse(locationId: Long?) {
        require(locationId == null || locationId > 0)
        warehouseLocationId.value = locationId
    }

    private data class DashboardContext(
        val user: AppUserRecord?,
        val organizationName: String,
    )

    private data class DashboardQuery(
        val fromEpochDay: Long,
        val toEpochDay: Long,
        val period: DashboardPeriod,
        val branchName: String?,
        val warehouseLocationId: Long?,
    )

    companion object {
        fun factory(repository: DashboardRepository): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    require(modelClass.isAssignableFrom(DashboardViewModel::class.java))
                    return DashboardViewModel(repository) as T
                }
            }
    }
}
