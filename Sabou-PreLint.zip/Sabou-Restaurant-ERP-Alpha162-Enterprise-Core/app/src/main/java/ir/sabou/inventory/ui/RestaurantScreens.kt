package ir.sabou.inventory.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import ir.sabou.inventory.core.MoneyRial
import ir.sabou.inventory.core.currentLocalEpochDay
import ir.sabou.inventory.domain.restaurant.KitchenTicketStatus
import ir.sabou.inventory.domain.restaurant.OpenTableCommand
import ir.sabou.inventory.domain.restaurant.RestaurantCourse
import ir.sabou.inventory.domain.restaurant.RestaurantPaymentSplit
import ir.sabou.inventory.domain.restaurant.RestaurantReservationStatus
import ir.sabou.inventory.domain.restaurant.RestaurantTableStatus
import ir.sabou.inventory.domain.restaurant.TableReservationDraft
import ir.sabou.inventory.domain.sales.SalesPaymentMethod

private data class PaymentDraftUi(
    val payerNo: Int,
    val method: SalesPaymentMethod,
    val amountRial: Long,
    val orderLineId: Long?,
)

@Composable
internal fun RestaurantScreen(
    state: RestaurantUiState,
    onSelectOrder: (Long?) -> Unit,
    onCreateHall: (String) -> Unit,
    onCreateTable: (Long, String, Int) -> Unit,
    onReserve: (TableReservationDraft) -> Unit,
    onReservationStatus: (Long, RestaurantReservationStatus, String) -> Unit,
    onOpenTable: (OpenTableCommand) -> Unit,
    onAddItem: (Long, Long, Long, RestaurantCourse, String) -> Unit,
    onChangeQuantity: (Long, Long) -> Unit,
    onTransfer: (Long, Long, String) -> Unit,
    onMerge: (Long, Long, String) -> Unit,
    onKitchen: (Long, KitchenTicketStatus, String) -> Unit,
    onClose: (Long, List<RestaurantPaymentSplit>, Long?) -> Unit,
    onBack: () -> Unit,
) {
    var hallName by remember { mutableStateOf("") }
    var tableNo by remember { mutableStateOf("") }
    var capacity by remember { mutableStateOf("4") }
    var guestCount by remember { mutableStateOf("2") }
    var waiterId by remember { mutableStateOf("") }
    var shiftReference by remember { mutableStateOf("") }
    var customerId by remember { mutableStateOf("") }
    var reservationName by remember { mutableStateOf("") }
    var reservationPhone by remember { mutableStateOf("") }
    var reservationDay by remember { mutableStateOf(currentLocalEpochDay()) }
    var reservationMinute by remember { mutableStateOf("1200") }
    var reservationNote by remember { mutableStateOf("") }
    var reservationReason by remember { mutableStateOf("") }
    var selectedCourse by remember { mutableStateOf(RestaurantCourse.MAIN) }
    var quantity by remember { mutableStateOf("1") }
    var itemNote by remember { mutableStateOf("") }
    var transferTarget by remember { mutableStateOf("") }
    var mergeTarget by remember { mutableStateOf("") }
    var actionReason by remember { mutableStateOf("") }
    var paymentAmount by remember { mutableStateOf("") }
    var paymentMethod by remember { mutableStateOf(SalesPaymentMethod.CASH) }
    var paymentLineId by remember { mutableStateOf<Long?>(null) }
    val payments = remember { mutableStateListOf<PaymentDraftUi>() }

    val selectedOrder = state.openOrders.firstOrNull { it.id == state.selectedOrderId }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("رستوران و KDS", style = MaterialTheme.typography.headlineSmall)
                TextButton(onClick = onBack) { Text("بازگشت") }
            }
        }
        state.message?.let { message ->
            item { Text(message, color = if (state.isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary) }
        }
        item { Text("سالن‌ها", style = MaterialTheme.typography.titleMedium) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = hallName,
                    onValueChange = { hallName = it },
                    modifier = Modifier.weight(1f).testTag("restaurant_hall_name"),
                    label = { Text("نام سالن") },
                )
                Button(
                    enabled = !state.isBusy && hallName.isNotBlank(),
                    modifier = Modifier.testTag("restaurant_create_hall"),
                    onClick = { onCreateHall(hallName.trim()); hallName = "" },
                ) { Text("ایجاد سالن") }
            }
            if (state.halls.isEmpty()) Text("برای شروع یک سالن تعریف کنید.")
            else Text("سالن فعال: ${state.halls.first().name}", style = MaterialTheme.typography.bodySmall)
        }
        item { Text("میزها", style = MaterialTheme.typography.titleMedium) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(tableNo, { tableNo = it }, Modifier.weight(1f).testTag("restaurant_table_no"), label = { Text("شماره میز") })
                OutlinedTextField(capacity, { capacity = it.filter(Char::isDigit) }, Modifier.weight(1f).testTag("restaurant_table_capacity"), label = { Text("ظرفیت") })
            }
        }
        item {
            Button(
                enabled = !state.isBusy && state.halls.isNotEmpty() && tableNo.isNotBlank() && (capacity.toIntOrNull() ?: 0) > 0,
                modifier = Modifier.testTag("restaurant_create_table"),
                onClick = { state.halls.firstOrNull()?.let { onCreateTable(it.id, tableNo.trim(), capacity.toIntOrNull() ?: 0) } },
            ) { Text("ایجاد میز در ${state.halls.firstOrNull()?.name ?: "سالن"}") }
        }
        if (state.tables.isEmpty()) {
            item { Text("میزی تعریف نشده است.") }
        } else {
            items(state.tables, key = { it.id }) { table ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("میز ${table.tableNo} · ظرفیت ${table.capacity} · ${table.status}")
                        if (table.status == RestaurantTableStatus.AVAILABLE) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(
                                    modifier = Modifier.testTag("restaurant_open_table_${table.id}"),
                                    onClick = {
                                    onOpenTable(
                                        OpenTableCommand(
                                            tableId = table.id,
                                            guestCount = guestCount.toIntOrNull() ?: 0,
                                            waiterUserId = waiterId.toLongOrNull(),
                                            shiftReference = shiftReference,
                                            customerId = customerId.toLongOrNull(),
                                        ),
                                    )
                                }) { Text("باز کردن") }
                                OutlinedButton(onClick = {
                                    onReserve(
                                        TableReservationDraft(
                                            tableId = table.id,
                                            customerId = customerId.toLongOrNull(),
                                            guestName = reservationName,
                                            guestPhone = reservationPhone,
                                            reservationEpochDay = reservationDay,
                                            startMinuteOfDay = reservationMinute.toIntOrNull() ?: -1,
                                            guestCount = guestCount.toIntOrNull() ?: 0,
                                            note = reservationNote,
                                        ),
                                    )
                                }) { Text("رزرو") }
                            }
                        }
                        table.currentOrderId?.let { orderId ->
                            OutlinedButton(modifier = Modifier.testTag("restaurant_order_$orderId"), onClick = { onSelectOrder(orderId) }) { Text("سفارش #$orderId") }
                        }
                    }
                }
            }
        }
        item {
            Text("اطلاعات مهمان/رزرو", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(guestCount, { guestCount = it.filter(Char::isDigit) }, Modifier.weight(1f), label = { Text("نفر") })
                OutlinedTextField(waiterId, { waiterId = it.filter(Char::isDigit) }, Modifier.weight(1f), label = { Text("شناسه گارسون") })
            }
            OutlinedTextField(shiftReference, { shiftReference = it.take(80) }, Modifier.fillMaxWidth().testTag("restaurant_shift_reference"), label = { Text("مرجع شیفت") })
            OutlinedTextField(customerId, { customerId = it.filter(Char::isDigit) }, Modifier.fillMaxWidth(), label = { Text("شناسه مشتری (اختیاری)") })
            OutlinedTextField(reservationName, { reservationName = it }, Modifier.fillMaxWidth(), label = { Text("نام رزرو") })
            PersianDateField("تاریخ رزرو", reservationDay) { reservationDay = it }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(reservationPhone, { reservationPhone = it.filter(Char::isDigit) }, Modifier.weight(1f), label = { Text("تلفن") })
                OutlinedTextField(reservationMinute, { reservationMinute = it.filter(Char::isDigit) }, Modifier.weight(1f), label = { Text("دقیقه روز (۰ تا ۱۴۳۹)") })
            }
            OutlinedTextField(reservationNote, { reservationNote = it.take(500) }, Modifier.fillMaxWidth(), label = { Text("توضیح رزرو") })
        }

        item { Text("رزروهای فعال", style = MaterialTheme.typography.titleMedium) }
        if (state.reservations.isEmpty()) {
            item { Text("رزرو فعالی وجود ندارد.") }
        } else {
            item {
                OutlinedTextField(reservationReason, { reservationReason = it.take(300) }, Modifier.fillMaxWidth(), label = { Text("دلیل لغو/عدم مراجعه رزرو") })
            }
            items(state.reservations, key = { "reservation-${it.id}" }) { reservation ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text("${reservation.guestName} · میز #${reservation.tableId} · ${reservation.status}")
                        Text("${epochDayToPersian(reservation.reservationEpochDay).display()} · دقیقه ${reservation.startMinuteOfDay} · ${reservation.guestCount} نفر", style = MaterialTheme.typography.bodySmall)
                        if (reservation.note.isNotBlank()) Text(reservation.note, style = MaterialTheme.typography.bodySmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            nextReservationStates(reservation.status).forEach { target ->
                                OutlinedButton(
                                    modifier = Modifier.testTag("restaurant_reservation_${reservation.id}_${target.name}"),
                                    onClick = { onReservationStatus(reservation.id, target, reservationReason) },
                                ) { Text(target.name) }
                            }
                        }
                    }
                }
            }
        }

        if (selectedOrder != null) {
            item { Text("سفارش فعال #${selectedOrder.id}", style = MaterialTheme.typography.titleMedium) }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    RestaurantCourse.entries.forEach { course ->
                        FilterChip(selected = selectedCourse == course, onClick = { selectedCourse = course }, label = { Text(course.name) })
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(quantity, { quantity = it.filter(Char::isDigit) }, Modifier.weight(1f), label = { Text("تعداد") })
                    OutlinedTextField(itemNote, { itemNote = it }, Modifier.weight(2f), label = { Text("یادداشت آشپزخانه") })
                }
            }
            if (state.menuItems.isEmpty()) {
                item { Text("آیتم فروش فعال برای سفارش وجود ندارد.") }
            } else {
                items(state.menuItems, key = { "menu-${it.id}" }) { menu ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(10.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column { Text(menu.name); Text(formatMoney(menu.salePriceRial), style = MaterialTheme.typography.bodySmall) }
                            Button(
                                enabled = !state.isBusy,
                                modifier = Modifier.testTag("restaurant_add_menu_${menu.id}"),
                                onClick = { onAddItem(selectedOrder.id, menu.id, quantity.toLongOrNull() ?: 0, selectedCourse, itemNote) },
                            ) { Text("افزودن") }
                        }
                    }
                }
            }
            item { Text("اقلام سفارش", style = MaterialTheme.typography.titleMedium) }
            if (state.selectedOrderLines.isEmpty()) {
                item { Text("سفارش هنوز آیتم ندارد.") }
            } else {
                items(state.selectedOrderLines, key = { "line-${it.id}" }) { line ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("${line.name} · ${line.course}")
                            Text("${line.quantity.value / 1_000_000L} × ${formatMoney(line.unitPrice.value)}")
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                OutlinedButton(onClick = { onChangeQuantity(line.id, (line.quantity.value / 1_000_000L) + 1L) }) { Text("+") }
                                if (line.quantity.value > 1_000_000L) {
                                    OutlinedButton(onClick = { onChangeQuantity(line.id, (line.quantity.value / 1_000_000L) - 1L) }) { Text("−") }
                                }
                            }
                        }
                    }
                }
            }
            item {
                OutlinedTextField(actionReason, { actionReason = it }, Modifier.fillMaxWidth(), label = { Text("دلیل انتقال/ادغام") })
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(transferTarget, { transferTarget = it.filter(Char::isDigit) }, Modifier.weight(1f), label = { Text("شناسه میز مقصد") })
                    Button(onClick = { onTransfer(selectedOrder.id, transferTarget.toLongOrNull() ?: 0, actionReason) }) { Text("انتقال میز") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(mergeTarget, { mergeTarget = it.filter(Char::isDigit) }, Modifier.weight(1f), label = { Text("شناسه سفارش مقصد") })
                    Button(onClick = { onMerge(selectedOrder.id, mergeTarget.toLongOrNull() ?: 0, actionReason) }) { Text("ادغام") }
                }
            }

            item { Text("تقسیم و پرداخت صورتحساب", style = MaterialTheme.typography.titleMedium) }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    SalesPaymentMethod.entries.forEach { method ->
                        FilterChip(
                            selected = paymentMethod == method,
                            onClick = { paymentMethod = method },
                            modifier = Modifier.testTag("restaurant_payment_method_${method.name}"),
                            label = { Text(method.title) },
                        )
                    }
                }
                OutlinedTextField(paymentAmount, { paymentAmount = it.filter(Char::isDigit) }, Modifier.fillMaxWidth().testTag("restaurant_payment_amount"), label = { Text("مبلغ سهم (ریال)") })
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = paymentLineId == null, onClick = { paymentLineId = null }, label = { Text("تقسیم بر مبلغ") })
                    state.selectedOrderLines.forEach { line ->
                        FilterChip(selected = paymentLineId == line.id, onClick = { paymentLineId = line.id }, label = { Text("آیتم #${line.id}") })
                    }
                }
                Button(
                    modifier = Modifier.testTag("restaurant_add_payment"),
                    onClick = {
                        val value = paymentAmount.toLongOrNull() ?: 0L
                        if (value > 0) {
                            payments += PaymentDraftUi(payments.size + 1, paymentMethod, value, paymentLineId)
                            paymentAmount = ""
                        }
                    },
                ) { Text("افزودن سهم پرداخت") }
            }
            items(payments, key = { "payment-${it.payerNo}" }) { payment ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("پرداخت‌کننده ${payment.payerNo}: ${payment.method.title} · ${formatMoney(payment.amountRial)}${payment.orderLineId?.let { " · آیتم #$it" }.orEmpty()}")
                    TextButton(onClick = { payments.remove(payment) }) { Text("حذف") }
                }
            }
            item {
                Button(
                    enabled = !state.isBusy && payments.isNotEmpty(),
                    modifier = Modifier.fillMaxWidth().testTag("restaurant_close_table"),
                    onClick = {
                        onClose(
                            selectedOrder.id,
                            payments.map { RestaurantPaymentSplit(it.payerNo, it.method, MoneyRial.of(it.amountRial), orderLineId = it.orderLineId) },
                            if (payments.any { it.method == SalesPaymentMethod.CREDIT }) currentLocalEpochDay() + 30 else null,
                        )
                    },
                ) { Text("صدور فاکتور نهایی و بستن میز") }
            }
        }

        item { Text("KDS آشپزخانه", style = MaterialTheme.typography.titleMedium) }
        if (state.kitchenTickets.isEmpty()) {
            item { Text("تیکت فعالی وجود ندارد.") }
        } else {
            items(state.kitchenTickets, key = { "ticket-${it.id}" }) { ticket ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("تیکت #${ticket.id} · آیتم سفارش #${ticket.orderLineId} · ${ticket.status}")
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            nextKitchenStates(ticket.status).forEach { status ->
                                OutlinedButton(
                                    modifier = Modifier.testTag("restaurant_kds_${ticket.id}_${status.name}"),
                                    onClick = { onKitchen(ticket.id, status, if (status == KitchenTicketStatus.CANCELLED) actionReason else "") },
                                ) { Text(status.name) }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun nextReservationStates(status: RestaurantReservationStatus): List<RestaurantReservationStatus> = when (status) {
    RestaurantReservationStatus.BOOKED -> listOf(RestaurantReservationStatus.CONFIRMED, RestaurantReservationStatus.SEATED, RestaurantReservationStatus.CANCELLED, RestaurantReservationStatus.NO_SHOW)
    RestaurantReservationStatus.CONFIRMED -> listOf(RestaurantReservationStatus.SEATED, RestaurantReservationStatus.CANCELLED, RestaurantReservationStatus.NO_SHOW)
    RestaurantReservationStatus.SEATED -> listOf(RestaurantReservationStatus.COMPLETED)
    RestaurantReservationStatus.COMPLETED, RestaurantReservationStatus.CANCELLED, RestaurantReservationStatus.NO_SHOW -> emptyList()
}

private fun nextKitchenStates(status: KitchenTicketStatus): List<KitchenTicketStatus> = when (status) {
    KitchenTicketStatus.NEW -> listOf(KitchenTicketStatus.ACCEPTED, KitchenTicketStatus.CANCELLED)
    KitchenTicketStatus.ACCEPTED -> listOf(KitchenTicketStatus.PREPARING, KitchenTicketStatus.CANCELLED)
    KitchenTicketStatus.PREPARING -> listOf(KitchenTicketStatus.READY, KitchenTicketStatus.CANCELLED)
    KitchenTicketStatus.READY -> listOf(KitchenTicketStatus.SERVED)
    KitchenTicketStatus.SERVED, KitchenTicketStatus.CANCELLED -> emptyList()
}
