package ir.sabou.inventory.application.sales

import ir.sabou.inventory.domain.recipe.MenuItem
import ir.sabou.inventory.domain.recipe.RecipeRepository
import ir.sabou.inventory.domain.sales.CustomerDraft
import ir.sabou.inventory.domain.sales.CustomerRecord
import ir.sabou.inventory.domain.sales.PostedSalesInvoice
import ir.sabou.inventory.domain.sales.PostedSalesReturn
import ir.sabou.inventory.domain.sales.ProfessionalSalesDayClosureRecord
import ir.sabou.inventory.domain.sales.ProfessionalSalesRepository
import ir.sabou.inventory.domain.sales.SalesHoldDraft
import ir.sabou.inventory.domain.sales.SalesHoldRecord
import ir.sabou.inventory.domain.sales.SalesInvoiceDetails
import ir.sabou.inventory.domain.sales.SalesInvoiceDraft
import ir.sabou.inventory.domain.sales.SalesInvoiceRecord
import ir.sabou.inventory.domain.sales.SalesReturnDraft
import kotlinx.coroutines.flow.Flow

/** Application boundary between presentation and professional sales domain. */
class SalesUseCases(
    private val sales: ProfessionalSalesRepository,
    private val recipes: RecipeRepository,
) {
    val customers: Flow<List<CustomerRecord>> get() = sales.customers
    val holds: Flow<List<SalesHoldRecord>> get() = sales.holds
    val dayClosures: Flow<List<ProfessionalSalesDayClosureRecord>> get() = sales.dayClosures
    val menuItems: Flow<List<MenuItem>> get() = recipes.observeMenuItems()

    fun invoices(query: String): Flow<List<SalesInvoiceRecord>> = sales.observeInvoices(query.trim())
    fun invoiceDetails(invoiceId: Long): Flow<SalesInvoiceDetails?> = sales.observeDetails(invoiceId)

    suspend fun postSale(draft: SalesInvoiceDraft): PostedSalesInvoice = sales.post(draft)
    suspend fun returnSale(draft: SalesReturnDraft): PostedSalesReturn = sales.returnSale(draft)
    suspend fun voidSale(invoiceId: Long, epochDay: Long, reason: String) = sales.voidInvoice(invoiceId, epochDay, reason)
    suspend fun auditInvoicePrint(invoiceId: Long) = sales.auditInvoicePrint(invoiceId)
    suspend fun closeDay(businessEpochDay: Long, note: String = "") = sales.closeDay(businessEpochDay, note)
    suspend fun reopenDay(businessEpochDay: Long, reason: String) = sales.reopenDay(businessEpochDay, reason)
    suspend fun saveCustomer(id: Long?, draft: CustomerDraft): Long = sales.saveCustomer(id, draft)
    suspend fun deactivateCustomer(id: Long) = sales.deactivateCustomer(id)
    suspend fun holdSale(draft: SalesHoldDraft): Long = sales.hold(draft)
    suspend fun loadHold(id: Long): SalesHoldDraft = sales.loadHold(id)
    suspend fun deleteHold(id: Long) = sales.deleteHold(id)
}
