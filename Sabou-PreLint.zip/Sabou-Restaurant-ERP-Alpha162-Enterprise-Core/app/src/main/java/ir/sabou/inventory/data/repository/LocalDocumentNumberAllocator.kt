package ir.sabou.inventory.data.repository

import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.db.DocumentSequenceEntity
import ir.sabou.inventory.domain.common.DocumentNumberType

/** Must be called from the same Room transaction that persists the owning document. */
internal class LocalDocumentNumberAllocator(
    private val database: AppDatabase,
    private val clock: () -> Long = System::currentTimeMillis,
) {
    suspend fun next(type: DocumentNumberType): String {
        val dao = database.documentSequenceDao()
        val now = clock()
        dao.insertIfMissing(DocumentSequenceEntity(type.sequenceKey, 1L, now))
        repeat(MAX_RETRIES) {
            val current = checkNotNull(dao.nextValue(type.sequenceKey)) {
                "توالی شماره‌گذاری ${type.sequenceKey} پیدا نشد."
            }
            require(current in 1..MAX_SEQUENCE) { "ظرفیت شماره‌گذاری ${type.sequenceKey} تکمیل شده است." }
            val next = Math.addExact(current, 1L)
            if (dao.compareAndAdvance(type.sequenceKey, current, next, now) == 1) {
                return "${type.prefix}-${current.toString().padStart(8, '0')}"
            }
        }
        error("شماره‌گذاری هم‌زمان با تغییر دیگری تداخل داشت؛ عملیات را دوباره انجام دهید.")
    }

    private companion object {
        const val MAX_RETRIES = 32
        const val MAX_SEQUENCE = 99_999_999L
    }
}
