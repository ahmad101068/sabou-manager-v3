package ir.sabou.inventory.ui

import ir.sabou.inventory.R
import androidx.compose.ui.res.stringResource
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Assessment
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MoreHoriz
import androidx.compose.material.icons.outlined.PointOfSale
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import ir.sabou.inventory.domain.operations.AppUserRecord

private data class HubModule(
    val title: String,
    val subtitle: String,
    val screen: AppScreen,
)

private data class HubGroup(val title: String, val modules: List<HubModule>)

private val operationsModules = listOf(
    HubModule("فروش", "فاکتور، پرداخت و مرجوعی", AppScreen.SALES),
    HubModule("رستوران و KDS", "سالن، میز، سفارش و آشپزخانه", AppScreen.RESTAURANT),
    HubModule("خرید", "خرید و دریافت کالا", AppScreen.PURCHASES),
    HubModule("انبار", "موجودی، گردش و کنترل کالا", AppScreen.INVENTORY),
    HubModule("دریافت و پرداخت", "خزانه، صندوق و بانک", AppScreen.TREASURY),
    HubModule("پرسنل", "کارکنان، حضور و حقوق", AppScreen.PERSONNEL),
)

private val moreGroups = listOf(
    HubGroup("عملیات", listOf(
        HubModule("فروش", "صندوق فروش", AppScreen.SALES),
        HubModule("رستوران", "سالن و KDS", AppScreen.RESTAURANT),
        HubModule("خرید", "خرید و فاکتورها", AppScreen.PURCHASES),
        HubModule("تأمین‌کنندگان", "فروشندگان و مانده‌ها", AppScreen.SUPPLIERS),
        HubModule("انبار", "موجودی و گردش", AppScreen.INVENTORY),
        HubModule("رسپی", "تولید و بهای مواد", AppScreen.RECIPES),
    )),
    HubGroup("مالی", listOf(
        HubModule("حسابداری", "اسناد و دفاتر", AppScreen.ACCOUNTING),
        HubModule("خزانه", "صندوق، بانک و پرداخت", AppScreen.TREASURY),
        HubModule("CRM", "مشتریان و دریافتنی", AppScreen.CRM),
    )),
    HubGroup("منابع انسانی", listOf(
        HubModule("پرسنل", "کارکنان و قرارداد", AppScreen.PERSONNEL),
        HubModule("دارایی", "اموال و استهلاک", AppScreen.ASSETS),
    )),
    HubGroup("مدیریت", listOf(
        HubModule("گزارش‌ها", "مرکز گزارش", AppScreen.REPORTS),
        HubModule("هشدارها", "موارد نیازمند اقدام", AppScreen.ALERTS),
        HubModule("مرکز کنترل", "کنترل مدیریتی", AppScreen.MANAGEMENT_CONTROL),
    )),
    HubGroup("سیستم", listOf(
        HubModule("کاربران و دسترسی", "کاربران، نقش و پشتیبان", AppScreen.SECURITY),
        HubModule("تنظیمات", "تنظیمات برنامه", AppScreen.SETTINGS),
        HubModule("امنیت و حسابرسی", "رویدادهای سیستم", AppScreen.AUDIT_LOG),
    )),
)

@Composable
internal fun NavigationHubRoutes(
    screen: AppScreen,
    currentUser: AppUserRecord?,
    navigate: (AppScreen) -> Unit,
) {
    when (screen) {
        AppScreen.OPERATIONS_HUB -> OperationsHubScreen(currentUser, navigate)
        AppScreen.MORE -> MoreHubScreen(currentUser, navigate)
        else -> error("hub_route_group_mismatch:${screen.name}")
    }
}

@Composable
private fun OperationsHubScreen(currentUser: AppUserRecord?, navigate: (AppScreen) -> Unit) {
    val allowed = operationsModules.filter { canOpenScreen(currentUser, it.screen) }
    Scaffold(
        topBar = { ProfessionalTopBar("عملیات", "مسیرهای پرتکرار روزانه", { navigate(AppScreen.DASHBOARD) }) },
        bottomBar = { MainTopLevelNavigation(selected = AppScreen.OPERATIONS_HUB, navigate = navigate) },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp).testTag("operations_hub"),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item { Text("عملیات مجاز", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black, modifier = Modifier.padding(top = 12.dp)) }
            items(allowed, key = { it.screen.name }) { module -> HubModuleRow(module, navigate) }
            if (allowed.isEmpty()) item { HubEmptyState("برای نقش فعلی عملیات مستقیمی در دسترس نیست.") }
        }
    }
}

@Composable
private fun MoreHubScreen(currentUser: AppUserRecord?, navigate: (AppScreen) -> Unit) {
    val visibleGroups = moreGroups.mapNotNull { group ->
        val modules = group.modules.filter { canOpenScreen(currentUser, it.screen) }
        if (modules.isEmpty()) null else group.copy(modules = modules)
    }
    Scaffold(
        topBar = { ProfessionalTopBar("بیشتر", "همه بخش‌های مجاز به‌صورت گروه‌بندی‌شده", { navigate(AppScreen.DASHBOARD) }) },
        bottomBar = { MainTopLevelNavigation(selected = AppScreen.MORE, navigate = navigate) },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp).testTag("more_hub"),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            visibleGroups.forEach { group ->
                item(key = "group-${group.title}") {
                    Text(group.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black, modifier = Modifier.padding(top = 12.dp))
                }
                items(group.modules, key = { "${group.title}-${it.screen.name}" }) { module -> HubModuleRow(module, navigate) }
            }
            if (visibleGroups.isEmpty()) item { HubEmptyState("بخشی برای نقش فعلی در دسترس نیست.") }
        }
    }
}

@Composable
private fun HubModuleRow(module: HubModule, navigate: (AppScreen) -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().testTag("module_${module.screen.name}").clickable { navigate(module.screen) },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(module.title, fontWeight = FontWeight.Bold)
                Text(module.subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text("باز کردن", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
private fun HubEmptyState(message: String) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)) {
        Text(message, Modifier.fillMaxWidth().padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
internal fun MainTopLevelNavigation(selected: AppScreen, navigate: (AppScreen) -> Unit) {
    NavigationBar(modifier = Modifier.testTag("main_bottom_navigation")) {
        NavigationBarItem(
            selected == AppScreen.DASHBOARD,
            { navigate(AppScreen.DASHBOARD) },
            { Icon(Icons.Outlined.Home, contentDescription = stringResource(R.string.ux2_text_1e0e4ac2e8)) },
            modifier = Modifier.testTag("nav_home"),
            label = { Text(stringResource(R.string.ux2_text_1e0e4ac2e8)) },
        )
        NavigationBarItem(
            selected == AppScreen.OPERATIONS_HUB,
            { navigate(AppScreen.OPERATIONS_HUB) },
            { Icon(Icons.Outlined.PointOfSale, contentDescription = stringResource(R.string.ux2_text_8d1cc546f4)) },
            modifier = Modifier.testTag("nav_operations"),
            label = { Text(stringResource(R.string.ux2_text_8d1cc546f4)) },
        )
        NavigationBarItem(
            selected == AppScreen.REPORTS,
            { navigate(AppScreen.REPORTS) },
            { Icon(Icons.Outlined.Assessment, contentDescription = stringResource(R.string.ux2_text_20ecfa9f52)) },
            modifier = Modifier.testTag("nav_reports"),
            label = { Text(stringResource(R.string.ux2_text_20ecfa9f52)) },
        )
        NavigationBarItem(
            selected == AppScreen.MORE,
            { navigate(AppScreen.MORE) },
            { Icon(Icons.Outlined.MoreHoriz, contentDescription = stringResource(R.string.ux2_text_46dd186fe2)) },
            modifier = Modifier.testTag("nav_more"),
            label = { Text(stringResource(R.string.ux2_text_46dd186fe2)) },
        )
    }
}
