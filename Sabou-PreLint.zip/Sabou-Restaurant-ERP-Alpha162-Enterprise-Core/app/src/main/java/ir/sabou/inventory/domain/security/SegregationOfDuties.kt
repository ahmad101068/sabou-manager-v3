package ir.sabou.inventory.domain.security

import ir.sabou.inventory.domain.common.BusinessError
import ir.sabou.inventory.domain.common.businessRequire

/** Pure domain policy shared by approval command boundaries. */
object SegregationOfDuties {
    fun requireDifferentActors(
        operation: String,
        creatorActorId: Long,
        approverActorId: Long,
    ) {
        businessRequire(creatorActorId > 0 && approverActorId > 0 && creatorActorId != approverActorId) {
            BusinessError.SeparationOfDutiesViolation(operation)
        }
    }

    fun requireDifferentLegacyAware(
        operation: String,
        creatorActorId: Long?,
        creatorDisplayName: String,
        approverActorId: Long,
        approverDisplayName: String,
    ) {
        if (creatorActorId != null) {
            requireDifferentActors(operation, creatorActorId, approverActorId)
            return
        }
        businessRequire(
            creatorDisplayName.trim().isNotEmpty() &&
                !creatorDisplayName.trim().equals(approverDisplayName.trim(), ignoreCase = true),
        ) { BusinessError.SeparationOfDutiesViolation(operation) }
    }
}
