package ir.sabou.inventory.data.repository

import ir.sabou.inventory.core.toLongExactCompat
import ir.sabou.inventory.core.SignedLongMath
import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.db.InventoryItemEntity
import ir.sabou.inventory.domain.common.BusinessError
import ir.sabou.inventory.domain.common.asViolation
import ir.sabou.inventory.domain.recipe.FullCostCalculator
import ir.sabou.inventory.domain.sales.PreparedSalesInvoice
import ir.sabou.inventory.domain.sales.PreparedSalesLine
import java.math.BigInteger

/**
 * Pure sales-side recipe expansion boundary.
 *
 * It owns nested-recipe traversal and immutable cost-snapshot preparation so the sales repository
 * remains a transaction coordinator instead of also being a recursive costing engine.
 */
internal class SalesRecipeCostSnapshotService(private val database: AppDatabase) {
    suspend fun prepare(calculated: PreparedSalesInvoice): List<PreparedLineWithCost> =
        calculated.lines.map { financial ->
            val menu = database.recipeDao().activeMenuItem(financial.menuItemId)
                ?: throw BusinessError.EntityNotFound("MENU_ITEM", financial.menuItemId).asViolation()
            val version = database.recipeDao().effectiveVersion(menu.id, calculated.draft.businessEpochDay)
                ?: error("برای «${menu.name}» در تاریخ فروش، نسخه مؤثر رسپی وجود ندارد.")
            val flattened = flattenIngredients(version.id)
            require(flattened.isNotEmpty()) { "رسپی «${menu.name}» ماده اولیه یا زیررسپی قابل مصرف ندارد." }
            val consumptions = flattened.entries.map { (inventoryItemId, quantityPerUnit) ->
                val item = database.inventoryDao().activeById(inventoryItemId)
                    ?: throw BusinessError.EntityNotFound("INVENTORY_ITEM", inventoryItemId).asViolation()
                val quantity = mulDiv(quantityPerUnit, financial.quantityMicros, QUANTITY_SCALE)
                require(quantity > 0) { "مقدار مصرف ${item.name} نامعتبر است." }
                val value = if (item.stockMicros == 0L) 0L else mulDiv(item.inventoryValueRial, quantity, item.stockMicros)
                PreparedConsumption(item, quantity, value)
            }
            val rawCogs = exactSum(consumptions.map { it.valueRial })
            val nestedExtras = nestedRecipeExtras(version.id)
            val packaging = mulDiv(SignedLongMath.add(version.packagingCostRial, nestedExtras.packagingRial), financial.quantityMicros, QUANTITY_SCALE)
            val labor = mulDiv(SignedLongMath.add(version.directLaborCostRial, nestedExtras.laborRial), financial.quantityMicros, QUANTITY_SCALE)
            val overhead = mulDiv(SignedLongMath.add(version.allocatedOverheadRial, nestedExtras.overheadRial), financial.quantityMicros, QUANTITY_SCALE)
            val full = FullCostCalculator.calculate(
                FullCostCalculator.Input(
                    rawIngredientCostRial = rawCogs,
                    yieldMicros = version.yieldMicros,
                    preparationWasteBasisPoints = version.preparationWasteBasisPoints,
                    cookingWasteBasisPoints = version.cookingWasteBasisPoints,
                    packagingCostRial = packaging,
                    directLaborCostRial = labor,
                    allocatedOverheadRial = overhead,
                    salePriceRial = financial.grossRial,
                ),
            )
            PreparedLineWithCost(financial, version.id, menu.name, rawCogs, full.foodCostRial, packaging, labor, overhead, consumptions)
        }

    private suspend fun flattenIngredients(versionId: Long): Map<Long, Long> {
        suspend fun walk(currentVersionId: Long, factorMicros: Long, path: MutableSet<Long>, target: MutableMap<Long, Long>) {
            require(path.add(currentVersionId)) { "وابستگی حلقوی رسپی هنگام فروش شناسایی شد." }
            database.recipeDao().versionIngredients(currentVersionId).forEach { ingredient ->
                val scaled = mulDiv(ingredient.quantityMicrosPerUnit, factorMicros, QUANTITY_SCALE)
                target[ingredient.inventoryItemId] = SignedLongMath.add(target[ingredient.inventoryItemId] ?: 0L, scaled)
            }
            database.alpha162RecipeDao().components(currentVersionId).forEach { component ->
                val childFactor = mulDiv(factorMicros, component.quantityMicrosPerUnit, QUANTITY_SCALE)
                walk(component.subRecipeVersionId, childFactor, path, target)
            }
            path.remove(currentVersionId)
        }
        val result = linkedMapOf<Long, Long>()
        walk(versionId, QUANTITY_SCALE, linkedSetOf(), result)
        return result
    }

    private suspend fun nestedRecipeExtras(versionId: Long): RecipeCostExtras {
        suspend fun walk(currentVersionId: Long, factorMicros: Long, path: MutableSet<Long>): RecipeCostExtras {
            require(path.add(currentVersionId)) { "وابستگی حلقوی رسپی هنگام محاسبه بها شناسایی شد." }
            var result = RecipeCostExtras()
            database.alpha162RecipeDao().components(currentVersionId).forEach { component ->
                val child = database.alpha162RecipeDao().versionById(component.subRecipeVersionId)
                    ?: error("نسخه زیررسپی پیدا نشد.")
                val childFactor = mulDiv(factorMicros, component.quantityMicrosPerUnit, QUANTITY_SCALE)
                result = result + RecipeCostExtras(
                    packagingRial = mulDiv(child.packagingCostRial, childFactor, QUANTITY_SCALE),
                    laborRial = mulDiv(child.directLaborCostRial, childFactor, QUANTITY_SCALE),
                    overheadRial = mulDiv(child.allocatedOverheadRial, childFactor, QUANTITY_SCALE),
                ) + walk(child.id, childFactor, path)
            }
            path.remove(currentVersionId)
            return result
        }
        return walk(versionId, QUANTITY_SCALE, linkedSetOf())
    }

    private fun exactSum(values: Iterable<Long>): Long = values.fold(0L, SignedLongMath::add)

    private fun mulDiv(a: Long, b: Long, divisor: Long): Long {
        require(a >= 0 && b >= 0 && divisor > 0)
        return BigInteger.valueOf(a).multiply(BigInteger.valueOf(b)).divide(BigInteger.valueOf(divisor)).toLongExactCompat()
    }

    private data class RecipeCostExtras(
        val packagingRial: Long = 0,
        val laborRial: Long = 0,
        val overheadRial: Long = 0,
    ) {
        operator fun plus(other: RecipeCostExtras) = RecipeCostExtras(
            SignedLongMath.add(packagingRial, other.packagingRial),
            SignedLongMath.add(laborRial, other.laborRial),
            SignedLongMath.add(overheadRial, other.overheadRial),
        )
    }

    private companion object {
        const val QUANTITY_SCALE = 1_000_000L
    }
}

internal data class PreparedConsumption(
    val item: InventoryItemEntity,
    val quantityMicros: Long,
    val valueRial: Long,
)

internal data class PreparedLineWithCost(
    val financial: PreparedSalesLine,
    val recipeVersionId: Long,
    val menuName: String,
    val rawCogsRial: Long,
    val foodCostRial: Long,
    val packagingRial: Long,
    val laborRial: Long,
    val overheadRial: Long,
    val consumptions: List<PreparedConsumption>,
)
