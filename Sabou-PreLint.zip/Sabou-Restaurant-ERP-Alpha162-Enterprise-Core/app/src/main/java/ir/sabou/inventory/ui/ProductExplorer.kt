package ir.sabou.inventory.ui

/** Shared matching rules for data-heavy business screens. */
internal fun businessTextMatches(query: String, vararg fields: String?): Boolean {
    val normalized = query.trim()
    return normalized.isBlank() || fields.any { it.orEmpty().contains(normalized, ignoreCase = true) }
}

internal fun businessActivityMatches(filter: String, isActive: Boolean): Boolean = when (filter) {
    "ACTIVE" -> isActive
    "INACTIVE" -> !isActive
    else -> true
}
