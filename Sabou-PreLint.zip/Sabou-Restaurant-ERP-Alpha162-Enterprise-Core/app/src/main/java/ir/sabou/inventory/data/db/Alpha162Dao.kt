package ir.sabou.inventory.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface TreasuryDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertTransaction(entity: TreasuryTransactionEntity)

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertLedgerEntries(entries: List<TreasuryLedgerEntryEntity>)

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertReconciliation(entity: TreasuryReconciliationEntity): Long

    @Query("SELECT * FROM treasury_transactions WHERE commandId=:commandId LIMIT 1")
    suspend fun byCommandId(commandId: String): TreasuryTransactionEntity?

    @Query("SELECT * FROM treasury_transactions WHERE id=:id LIMIT 1")
    suspend fun transactionById(id: String): TreasuryTransactionEntity?

    @Query("SELECT * FROM treasury_ledger_entries WHERE transactionId=:transactionId ORDER BY id")
    suspend fun entriesForTransaction(transactionId: String): List<TreasuryLedgerEntryEntity>

    @Query("UPDATE treasury_transactions SET status='REVERSED', reversedAtEpochMillis=:now WHERE id=:id AND status='POSTED'")
    suspend fun markReversed(id: String, now: Long): Int

    @Query("SELECT * FROM treasury_transactions ORDER BY createdAtEpochMillis DESC LIMIT :limit")
    fun observeRecentTransactions(limit: Int = 250): Flow<List<TreasuryTransactionEntity>>

    @Query("SELECT COALESCE(SUM(CASE direction WHEN 'RECEIPT' THEN amountRial ELSE -amountRial END),0) FROM treasury_ledger_entries WHERE accountId=:accountId")
    fun observeLedgerBalance(accountId: String): Flow<Long>
}

@Dao
interface RestaurantDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertHall(entity: RestaurantHallEntity): Long

    @Query("SELECT COALESCE(MAX(sortOrder),0) FROM restaurant_halls")
    suspend fun maxHallSortOrder(): Int

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertTable(entity: RestaurantTableEntity): Long

    @Update
    suspend fun updateTable(entity: RestaurantTableEntity): Int

    @Query("SELECT * FROM restaurant_tables WHERE id=:id")
    suspend fun tableById(id: Long): RestaurantTableEntity?

    @Query("SELECT * FROM restaurant_tables ORDER BY hallId, tableNo")
    fun observeTables(): Flow<List<RestaurantTableEntity>>

    @Query("SELECT * FROM restaurant_halls WHERE isActive=1 ORDER BY sortOrder, name")
    fun observeHalls(): Flow<List<RestaurantHallEntity>>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertReservation(entity: RestaurantReservationEntity): Long

    @Update
    suspend fun updateReservation(entity: RestaurantReservationEntity): Int

    @Query("SELECT * FROM restaurant_reservations WHERE id=:id")
    suspend fun reservationById(id: Long): RestaurantReservationEntity?

    @Query("SELECT * FROM restaurant_reservations WHERE status NOT IN ('CANCELLED','NO_SHOW','COMPLETED') ORDER BY reservationEpochDay,startMinuteOfDay,id")
    fun observeActiveReservations(): Flow<List<RestaurantReservationEntity>>

    @Query("SELECT COUNT(*) FROM restaurant_reservations WHERE tableId=:tableId AND reservationEpochDay=:epochDay AND id!=:excludeId AND status IN ('BOOKED','CONFIRMED')")
    suspend fun activeReservationCountForTable(tableId: Long, epochDay: Long, excludeId: Long): Int

    @Query("SELECT * FROM restaurant_reservations WHERE reservationEpochDay BETWEEN :fromEpochDay AND :toEpochDay AND status NOT IN ('CANCELLED','NO_SHOW') ORDER BY reservationEpochDay,startMinuteOfDay")
    fun observeReservations(fromEpochDay: Long, toEpochDay: Long): Flow<List<RestaurantReservationEntity>>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertOrder(entity: RestaurantOrderEntity): Long

    @Update
    suspend fun updateOrder(entity: RestaurantOrderEntity): Int

    @Query("SELECT * FROM restaurant_orders WHERE id=:id")
    suspend fun orderById(id: Long): RestaurantOrderEntity?

    @Query("SELECT * FROM restaurant_orders WHERE commandId=:commandId LIMIT 1")
    suspend fun orderByCommandId(commandId: String): RestaurantOrderEntity?

    @Query("SELECT * FROM restaurant_orders WHERE tableId=:tableId AND status='OPEN' LIMIT 1")
    suspend fun openOrderForTable(tableId: Long): RestaurantOrderEntity?

    @Query("SELECT * FROM restaurant_orders WHERE status='OPEN' ORDER BY openedAtEpochMillis")
    fun observeOpenOrders(): Flow<List<RestaurantOrderEntity>>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertOrderLine(entity: RestaurantOrderLineEntity): Long

    @Update
    suspend fun updateOrderLine(entity: RestaurantOrderLineEntity): Int

    @Query("SELECT * FROM restaurant_order_lines WHERE id=:id")
    suspend fun orderLineById(id: Long): RestaurantOrderLineEntity?

    @Query("SELECT * FROM restaurant_order_lines WHERE orderId=:orderId AND status='ACTIVE' ORDER BY id")
    suspend fun activeOrderLines(orderId: Long): List<RestaurantOrderLineEntity>

    @Query("SELECT * FROM restaurant_order_lines WHERE orderId=:orderId AND menuItemId=:menuItemId AND status='ACTIVE' LIMIT 1")
    suspend fun activeLine(orderId: Long, menuItemId: Long): RestaurantOrderLineEntity?

    @Query("UPDATE restaurant_order_lines SET orderId=:targetOrderId, updatedAtEpochMillis=:now WHERE orderId=:sourceOrderId AND status='ACTIVE'")
    suspend fun moveActiveLines(sourceOrderId: Long, targetOrderId: Long, now: Long): Int

    @Query("SELECT * FROM restaurant_order_lines WHERE orderId=:orderId ORDER BY id")
    fun observeOrderLines(orderId: Long): Flow<List<RestaurantOrderLineEntity>>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertKitchenTicket(entity: KitchenTicketEntity): Long

    @Update
    suspend fun updateKitchenTicket(entity: KitchenTicketEntity): Int

    @Query("SELECT * FROM kitchen_tickets WHERE id=:id")
    suspend fun kitchenTicketById(id: Long): KitchenTicketEntity?

    @Query("SELECT * FROM kitchen_tickets WHERE orderLineId=:orderLineId LIMIT 1")
    suspend fun kitchenTicketByOrderLine(orderLineId: Long): KitchenTicketEntity?

    @Query("SELECT * FROM kitchen_tickets WHERE status NOT IN ('SERVED','CANCELLED') ORDER BY updatedAtEpochMillis")
    fun observeActiveKitchenTickets(): Flow<List<KitchenTicketEntity>>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertKitchenEvent(entity: KitchenTicketEventEntity): Long

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertBillSplits(entities: List<RestaurantBillSplitEntity>)

    @Query("DELETE FROM restaurant_bill_splits WHERE orderId=:orderId")
    suspend fun deleteBillSplits(orderId: Long): Int
}


data class ActiveRecipeVersionRow(
    val versionId: Long,
    val menuItemId: Long,
    val menuItemName: String,
    val revisionNo: Int,
)

@Dao
interface Alpha162RecipeDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertComponents(entities: List<RecipeComponentEntity>)

    @Query("DELETE FROM recipe_components WHERE recipeVersionId=:recipeVersionId")
    suspend fun deleteComponents(recipeVersionId: Long): Int

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertSubstitution(entity: RecipeSubstitutionEntity): Long

    @Query("SELECT * FROM recipe_components WHERE recipeVersionId=:recipeVersionId ORDER BY id")
    suspend fun components(recipeVersionId: Long): List<RecipeComponentEntity>

    @Query("SELECT * FROM recipe_substitutions WHERE recipeVersionId=:recipeVersionId ORDER BY id")
    suspend fun substitutions(recipeVersionId: Long): List<RecipeSubstitutionEntity>

    @Query("SELECT subRecipeVersionId FROM recipe_components WHERE recipeVersionId=:recipeVersionId")
    suspend fun childRecipeVersions(recipeVersionId: Long): List<Long>

    @Query("UPDATE recipe_versions SET status=:status WHERE id=:versionId AND status=:expected")
    suspend fun transitionStatus(versionId: Long, expected: String, status: String): Int

    @Query("UPDATE recipe_versions SET status='RETIRED' WHERE menuItemId=:menuItemId AND status='ACTIVE' AND id!=:exceptVersionId")
    suspend fun retireOtherActive(menuItemId: Long, exceptVersionId: Long): Int

    @Query("SELECT * FROM recipe_versions WHERE id=:versionId")
    suspend fun versionById(versionId: Long): RecipeVersionEntity?

    @Query("""
        SELECT rv.id AS versionId, rv.menuItemId AS menuItemId, mi.name AS menuItemName, rv.revisionNo AS revisionNo
        FROM recipe_versions rv
        INNER JOIN menu_items mi ON mi.id=rv.menuItemId
        WHERE rv.status='ACTIVE'
        ORDER BY mi.name,rv.revisionNo DESC
    """)
    fun observeActiveVersionOptions(): Flow<List<ActiveRecipeVersionRow>>
}

@Dao
interface AssetLifecycleDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertEvent(entity: AssetLifecycleEventEntity): Long

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertMaintenance(entity: AssetMaintenanceEntity): Long

    @Query("SELECT * FROM asset_lifecycle_events WHERE assetId=:assetId ORDER BY businessEpochDay DESC,id DESC")
    fun observeEvents(assetId: Long): Flow<List<AssetLifecycleEventEntity>>

    @Query("SELECT * FROM asset_maintenance WHERE assetId=:assetId ORDER BY serviceEpochDay DESC,id DESC")
    fun observeMaintenance(assetId: Long): Flow<List<AssetMaintenanceEntity>>
}

@Dao
interface CustomerReceivableDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertLedger(entity: CustomerReceivableLedgerEntity): Long

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertMerge(entity: CustomerMergeHistoryEntity): Long

    @Query("SELECT * FROM customer_receivable_ledger WHERE customerId=:customerId ORDER BY businessEpochDay,id")
    fun observeLedger(customerId: Long): Flow<List<CustomerReceivableLedgerEntity>>

    @Query("SELECT * FROM customer_receivable_ledger WHERE customerId=:customerId ORDER BY businessEpochDay,id")
    suspend fun ledger(customerId: Long): List<CustomerReceivableLedgerEntity>

    @Query("SELECT COALESCE(SUM(debitRial-creditRial),0) FROM customer_receivable_ledger WHERE customerId=:customerId")
    suspend fun balanceRial(customerId: Long): Long

    @Query("SELECT * FROM customer_receivable_ledger WHERE sourceType=:sourceType AND reference=:reference LIMIT 1")
    suspend fun ledgerByReference(sourceType: String, reference: String): CustomerReceivableLedgerEntity?

    @Query("UPDATE sales_invoices SET customerId=:targetId WHERE customerId=:sourceId")
    suspend fun moveSalesInvoices(sourceId: Long, targetId: Long): Int

    @Query("UPDATE sales_holds SET customerId=:targetId WHERE customerId=:sourceId")
    suspend fun moveSalesHolds(sourceId: Long, targetId: Long): Int

    @Query("UPDATE restaurant_reservations SET customerId=:targetId WHERE customerId=:sourceId")
    suspend fun moveReservations(sourceId: Long, targetId: Long): Int

    @Query("UPDATE restaurant_orders SET customerId=:targetId WHERE customerId=:sourceId")
    suspend fun moveRestaurantOrders(sourceId: Long, targetId: Long): Int

    @Query("UPDATE customer_receivable_ledger SET customerId=:targetId WHERE customerId=:sourceId")
    suspend fun moveLedger(sourceId: Long, targetId: Long): Int
}
