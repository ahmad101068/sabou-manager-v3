package ir.sabou.inventory.data.db

import androidx.room.Entity
import androidx.room.ColumnInfo
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "daily_sales_summaries",
    indices = [Index("businessEpochDay"), Index("reversedAtEpochDay")],
)
data class DailySalesSummaryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val businessEpochDay: Long,
    val grossSalesRial: Long,
    val discountRial: Long,
    val serviceRial: Long,
    val taxRial: Long,
    val netSalesRial: Long,
    val theoreticalCostRial: Long,
    val cashRial: Long,
    val cardRial: Long,
    val transferRial: Long,
    val notes: String,
    val journalEntryId: Long?,
    val costJournalEntryId: Long?,
    val isLegacyArchive: Boolean = false,
    val reversedAtEpochDay: Long? = null,
    @ColumnInfo(defaultValue = "''") val reversalReason: String = "",
    val reversalJournalEntryId: Long? = null,
    val reversalCostJournalEntryId: Long? = null,
    val createdAtEpochMillis: Long,
)

@Entity(
    tableName = "daily_sales_menu_lines",
    foreignKeys = [
        ForeignKey(
            entity = DailySalesSummaryEntity::class,
            parentColumns = ["id"],
            childColumns = ["summaryId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
    indices = [Index("summaryId"), Index("menuItemId"), Index("recipeVersionId")],
)
data class DailySalesMenuLineEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val summaryId: Long,
    val menuItemId: Long?,
    val recipeVersionId: Long? = null,
    val menuItemNameSnapshot: String,
    val quantityMicros: Long,
    val grossSalesRial: Long,
    val theoreticalCostRial: Long,
    /** Null distinguishes pre-alpha154 sales whose historical full-cost profile is unavailable. */
    val foodCostSnapshotRial: Long? = null,
    val packagingCostSnapshotRial: Long? = null,
    val directLaborCostSnapshotRial: Long? = null,
    val allocatedOverheadSnapshotRial: Long? = null,
)

@Entity(
    tableName = "sales_day_closures",
    foreignKeys = [ForeignKey(entity = DailySalesSummaryEntity::class, parentColumns = ["id"], childColumns = ["summaryId"], onDelete = ForeignKey.RESTRICT)],
    indices = [Index(value = ["summaryId"], unique = true), Index("createdAtEpochMillis")],
)
data class SalesDayClosureEntity(
    @PrimaryKey val businessEpochDay: Long,
    val summaryId: Long,
    val grossSalesRial: Long,
    val netSalesRial: Long,
    val theoreticalCostRial: Long,
    val cashRial: Long,
    val cardRial: Long,
    val transferRial: Long,
    @ColumnInfo(defaultValue = "'CLOSED'") val status: String = "CLOSED",
    @ColumnInfo(defaultValue = "1") val revisionNo: Int = 1,
    val closedBy: String,
    val note: String,
    val reopenedBy: String? = null,
    @ColumnInfo(defaultValue = "''") val reopenReason: String = "",
    val reopenedAtEpochMillis: Long? = null,
    val createdAtEpochMillis: Long,
)
