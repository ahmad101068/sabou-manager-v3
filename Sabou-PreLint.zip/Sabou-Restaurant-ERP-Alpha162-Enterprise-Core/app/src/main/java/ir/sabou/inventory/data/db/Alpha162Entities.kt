package ir.sabou.inventory.data.db

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "treasury_transactions",
    indices = [
        Index(value = ["commandId"], unique = true),
        Index("businessEpochDay"),
        Index(value = ["sourceType", "sourceId"]),
        Index("journalEntryId"),
        Index("status"),
        Index("reversalOfTransactionId"),
    ],
)
data class TreasuryTransactionEntity(
    @PrimaryKey val id: String,
    val commandId: String,
    val kind: String,
    val businessEpochDay: Long,
    val sourceType: String,
    val sourceId: Long,
    val counterpartyType: String = "",
    val counterpartyId: Long? = null,
    val reference: String = "",
    val reason: String,
    val amountRial: Long,
    val status: String = "POSTED",
    val journalEntryId: Long? = null,
    val reversalOfTransactionId: String? = null,
    val actorId: Long,
    val correlationId: String,
    val createdAtEpochMillis: Long,
    val reversedAtEpochMillis: Long? = null,
)

@Entity(
    tableName = "treasury_ledger_entries",
    foreignKeys = [
        ForeignKey(
            entity = TreasuryTransactionEntity::class,
            parentColumns = ["id"],
            childColumns = ["transactionId"],
            onDelete = ForeignKey.RESTRICT,
        ),
    ],
    indices = [
        Index("transactionId"),
        Index(value = ["accountId", "businessEpochDay"]),
        Index(value = ["sourceType", "sourceId"]),
        Index("direction"),
    ],
)
data class TreasuryLedgerEntryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val transactionId: String,
    val accountId: String,
    val direction: String,
    val amountRial: Long,
    val sourceType: String,
    val sourceId: Long,
    val counterpartyType: String = "",
    val counterpartyId: Long? = null,
    val reference: String = "",
    val businessEpochDay: Long,
    val actorId: Long,
    val createdAtEpochMillis: Long,
)

@Entity(
    tableName = "treasury_reconciliations",
    indices = [Index(value = ["accountId", "businessEpochDay"]), Index("transactionId")],
)
data class TreasuryReconciliationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val transactionId: String,
    val accountId: String,
    val businessEpochDay: Long,
    val expectedRial: Long,
    val actualRial: Long,
    val differenceRial: Long,
    val reason: String,
    val actorId: Long,
    val createdAtEpochMillis: Long,
)

@Entity(
    tableName = "restaurant_halls",
    indices = [Index(value = ["name"], unique = true), Index("isActive")],
)
data class RestaurantHallEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val sortOrder: Int = 0,
    val isActive: Boolean = true,
    val createdAtEpochMillis: Long,
)

@Entity(
    tableName = "restaurant_tables",
    foreignKeys = [
        ForeignKey(entity = RestaurantHallEntity::class, parentColumns = ["id"], childColumns = ["hallId"], onDelete = ForeignKey.RESTRICT),
    ],
    indices = [Index(value = ["hallId", "tableNo"], unique = true), Index("status")],
)
data class RestaurantTableEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val hallId: Long,
    val tableNo: String,
    val capacity: Int,
    val status: String = "AVAILABLE",
    val currentOrderId: Long? = null,
    val updatedAtEpochMillis: Long,
)

@Entity(
    tableName = "restaurant_reservations",
    foreignKeys = [
        ForeignKey(entity = RestaurantTableEntity::class, parentColumns = ["id"], childColumns = ["tableId"], onDelete = ForeignKey.RESTRICT),
        ForeignKey(entity = CustomerEntity::class, parentColumns = ["id"], childColumns = ["customerId"], onDelete = ForeignKey.RESTRICT),
    ],
    indices = [Index("tableId"), Index("customerId"), Index(value = ["reservationEpochDay", "startMinuteOfDay"]), Index("status")],
)
data class RestaurantReservationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val customerId: Long?,
    val guestName: String,
    val guestPhone: String,
    val reservationEpochDay: Long,
    val startMinuteOfDay: Int,
    val guestCount: Int,
    val tableId: Long,
    val status: String = "BOOKED",
    val note: String = "",
    val createdByActorId: Long,
    val createdAtEpochMillis: Long,
    val updatedAtEpochMillis: Long,
)

@Entity(
    tableName = "restaurant_orders",
    foreignKeys = [
        ForeignKey(entity = RestaurantTableEntity::class, parentColumns = ["id"], childColumns = ["tableId"], onDelete = ForeignKey.RESTRICT),
        ForeignKey(entity = AppUserEntity::class, parentColumns = ["id"], childColumns = ["waiterUserId"], onDelete = ForeignKey.RESTRICT),
        ForeignKey(entity = CustomerEntity::class, parentColumns = ["id"], childColumns = ["customerId"], onDelete = ForeignKey.RESTRICT),
    ],
    indices = [Index("tableId"), Index("status"), Index("openedEpochDay"), Index("waiterUserId"), Index("customerId"), Index(value = ["commandId"], unique = true)],
)
data class RestaurantOrderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val commandId: String,
    val tableId: Long,
    val waiterUserId: Long?,
    val shiftReference: String = "",
    val customerId: Long? = null,
    val guestCount: Int,
    val status: String = "OPEN",
    val openedEpochDay: Long,
    val openedAtEpochMillis: Long,
    val closedAtEpochMillis: Long? = null,
    val salesInvoiceId: Long? = null,
    val note: String = "",
)

@Entity(
    tableName = "restaurant_order_lines",
    foreignKeys = [
        ForeignKey(entity = RestaurantOrderEntity::class, parentColumns = ["id"], childColumns = ["orderId"], onDelete = ForeignKey.RESTRICT),
        ForeignKey(entity = MenuItemEntity::class, parentColumns = ["id"], childColumns = ["menuItemId"], onDelete = ForeignKey.RESTRICT),
    ],
    indices = [Index("orderId"), Index("menuItemId"), Index("status")],
)
data class RestaurantOrderLineEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val orderId: Long,
    val menuItemId: Long,
    val menuItemNameSnapshot: String,
    val course: String,
    val quantityMicros: Long,
    val unitPriceRial: Long,
    val note: String = "",
    val status: String = "ACTIVE",
    val createdAtEpochMillis: Long,
    val updatedAtEpochMillis: Long,
)

@Entity(
    tableName = "kitchen_tickets",
    foreignKeys = [
        ForeignKey(entity = RestaurantOrderLineEntity::class, parentColumns = ["id"], childColumns = ["orderLineId"], onDelete = ForeignKey.RESTRICT),
    ],
    indices = [Index(value = ["orderLineId"], unique = true), Index("status"), Index("updatedAtEpochMillis")],
)
data class KitchenTicketEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val orderLineId: Long,
    val status: String = "NEW",
    val acceptedAtEpochMillis: Long? = null,
    val preparingAtEpochMillis: Long? = null,
    val readyAtEpochMillis: Long? = null,
    val servedAtEpochMillis: Long? = null,
    val cancelledAtEpochMillis: Long? = null,
    val cancelReason: String = "",
    val updatedByActorId: Long,
    val updatedAtEpochMillis: Long,
)

@Entity(
    tableName = "kitchen_ticket_events",
    foreignKeys = [
        ForeignKey(entity = KitchenTicketEntity::class, parentColumns = ["id"], childColumns = ["ticketId"], onDelete = ForeignKey.RESTRICT),
    ],
    indices = [Index("ticketId"), Index("createdAtEpochMillis")],
)
data class KitchenTicketEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val ticketId: Long,
    val fromStatus: String,
    val toStatus: String,
    val reason: String = "",
    val actorId: Long,
    val createdAtEpochMillis: Long,
)

@Entity(
    tableName = "restaurant_bill_splits",
    foreignKeys = [
        ForeignKey(entity = RestaurantOrderEntity::class, parentColumns = ["id"], childColumns = ["orderId"], onDelete = ForeignKey.RESTRICT),
    ],
    indices = [Index("orderId"), Index("payerNo")],
)
data class RestaurantBillSplitEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val orderId: Long,
    val payerNo: Int,
    val method: String,
    val amountRial: Long,
    val referenceNo: String = "",
    val orderLineId: Long? = null,
)

@Entity(
    tableName = "recipe_components",
    foreignKeys = [
        ForeignKey(entity = RecipeVersionEntity::class, parentColumns = ["id"], childColumns = ["recipeVersionId"], onDelete = ForeignKey.RESTRICT),
        ForeignKey(entity = RecipeVersionEntity::class, parentColumns = ["id"], childColumns = ["subRecipeVersionId"], onDelete = ForeignKey.RESTRICT),
    ],
    indices = [Index("recipeVersionId"), Index("subRecipeVersionId")],
)
data class RecipeComponentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val recipeVersionId: Long,
    val subRecipeVersionId: Long,
    val quantityMicrosPerUnit: Long,
)

@Entity(
    tableName = "recipe_substitutions",
    foreignKeys = [
        ForeignKey(entity = RecipeVersionEntity::class, parentColumns = ["id"], childColumns = ["recipeVersionId"], onDelete = ForeignKey.RESTRICT),
        ForeignKey(entity = InventoryItemEntity::class, parentColumns = ["id"], childColumns = ["originalInventoryItemId"], onDelete = ForeignKey.RESTRICT),
        ForeignKey(entity = InventoryItemEntity::class, parentColumns = ["id"], childColumns = ["substituteInventoryItemId"], onDelete = ForeignKey.RESTRICT),
    ],
    indices = [Index("recipeVersionId"), Index("originalInventoryItemId"), Index("substituteInventoryItemId")],
)
data class RecipeSubstitutionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val recipeVersionId: Long,
    val originalInventoryItemId: Long,
    val substituteInventoryItemId: Long,
    val ratioNumerator: Long = 1,
    val ratioDenominator: Long = 1,
    val reason: String,
    val approvedByActorId: Long,
    val createdAtEpochMillis: Long,
)

@Entity(
    tableName = "asset_lifecycle_events",
    foreignKeys = [
        ForeignKey(entity = FixedAssetEntity::class, parentColumns = ["id"], childColumns = ["assetId"], onDelete = ForeignKey.RESTRICT),
    ],
    indices = [Index("assetId"), Index("eventType"), Index("businessEpochDay"), Index("journalEntryId")],
)
data class AssetLifecycleEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val assetId: Long,
    val eventType: String,
    val businessEpochDay: Long,
    val amountRial: Long = 0,
    val fromLocation: String = "",
    val toLocation: String = "",
    val fromBranch: String = "",
    val toBranch: String = "",
    val fromResponsiblePerson: String = "",
    val toResponsiblePerson: String = "",
    val counterparty: String = "",
    val note: String = "",
    val journalEntryId: Long? = null,
    val actorId: Long,
    val createdAtEpochMillis: Long,
)

@Entity(
    tableName = "asset_maintenance",
    foreignKeys = [
        ForeignKey(entity = FixedAssetEntity::class, parentColumns = ["id"], childColumns = ["assetId"], onDelete = ForeignKey.RESTRICT),
    ],
    indices = [Index("assetId"), Index("serviceEpochDay"), Index("nextServiceEpochDay")],
)
data class AssetMaintenanceEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val assetId: Long,
    val serviceType: String,
    val serviceEpochDay: Long,
    val costRial: Long,
    val contractor: String = "",
    val note: String = "",
    val nextServiceEpochDay: Long? = null,
    val actorId: Long,
    val createdAtEpochMillis: Long,
)

@Entity(
    tableName = "customer_receivable_ledger",
    foreignKeys = [
        ForeignKey(entity = CustomerEntity::class, parentColumns = ["id"], childColumns = ["customerId"], onDelete = ForeignKey.RESTRICT),
    ],
    indices = [Index(value = ["customerId", "businessEpochDay"]), Index(value = ["sourceType", "sourceId"]), Index("entryType")],
)
data class CustomerReceivableLedgerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val customerId: Long,
    val businessEpochDay: Long,
    val entryType: String,
    val debitRial: Long,
    val creditRial: Long,
    val sourceType: String,
    val sourceId: Long,
    val reference: String = "",
    val dueEpochDay: Long? = null,
    val reversalOfLedgerId: Long? = null,
    val actorId: Long,
    val createdAtEpochMillis: Long,
)

@Entity(
    tableName = "customer_merge_history",
    indices = [Index("sourceCustomerId"), Index("targetCustomerId"), Index("mergedAtEpochMillis")],
)
data class CustomerMergeHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sourceCustomerId: Long,
    val targetCustomerId: Long,
    val reason: String,
    val actorId: Long,
    val mergedAtEpochMillis: Long,
)
