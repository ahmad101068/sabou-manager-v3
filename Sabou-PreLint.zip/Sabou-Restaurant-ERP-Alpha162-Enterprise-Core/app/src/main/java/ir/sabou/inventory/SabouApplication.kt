package ir.sabou.inventory

import android.app.Application
import ir.sabou.inventory.data.AppContainer
import ir.sabou.inventory.data.AutomaticBackupScheduler
import ir.sabou.inventory.data.BackupPolicyStore

class SabouApplication : Application() {
    val container: AppContainer by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
        AppContainer(applicationContext)
    }

    override fun onCreate() {
        super.onCreate()
        // Protected ERP workers are session-scoped. A fresh process begins unauthenticated and must
        // not instantiate Alerts/Sync until SabouApp enters the authenticated graph.
        ProtectedWorkScheduler.disable(this)
        AutomaticBackupScheduler.apply(this, BackupPolicyStore(this).load())
    }
}
