package ir.sabou.inventory.ui

import androidx.annotation.StringRes
import ir.sabou.inventory.R
import ir.sabou.inventory.data.repository.DashboardSnapshot
import ir.sabou.inventory.domain.operations.AppUserRecord
import ir.sabou.inventory.domain.security.Permission
import ir.sabou.inventory.domain.security.UserRole

enum class DashboardKpiKind { MONEY, COUNT }
enum class DashboardAttentionSeverity { NOTICE, WARNING, CRITICAL }

data class DashboardHeaderUi(
    val organizationName: String,
    val userName: String,
    val roleTitle: String,
    val unreadAttentionCount: Int,
)

data class DashboardKpiUi(
    val id: String,
    val title: String,
    val value: Long,
    val kind: DashboardKpiKind,
    val destination: AppScreen?,
)

data class DashboardQuickActionUi(
    val id: String,
    val title: String,
    val subtitle: String,
    val destination: AppScreen,
)

data class DashboardAttentionUi(
    val id: String,
    val severity: DashboardAttentionSeverity,
    val title: String,
    val explanation: String,
    val count: Long,
    val destination: AppScreen,
)

data class DashboardUiState(
    val header: DashboardHeaderUi = DashboardHeaderUi("", "", "", 0),
    val kpis: List<DashboardKpiUi> = emptyList(),
    val quickActions: List<DashboardQuickActionUi> = emptyList(),
    val alerts: List<DashboardAttentionUi> = emptyList(),
    val loading: Boolean = true,
    val partialErrors: List<String> = emptyList(),
)

/**
 * Presentation policy for Home. The screen receives only already-authorized KPIs/actions.
 * This keeps sensitive dashboard composition out of Composables and makes permission tests deterministic.
 */
internal object DashboardUxComposer {
    fun compose(snapshot: DashboardSnapshot, user: AppUserRecord?, organizationName: String): DashboardUiState {
        if (user == null) return DashboardUiState(loading = snapshot.fromEpochDay <= 0L)
        val alerts = resolveAlerts(snapshot, user)
        return DashboardUiState(
            header = DashboardHeaderUi(
                organizationName = organizationName,
                userName = user.displayName,
                roleTitle = user.role.title,
                unreadAttentionCount = alerts.sumOf { it.count }.coerceAtMost(Int.MAX_VALUE.toLong()).toInt(),
            ),
            kpis = resolveKpis(snapshot, user).take(4),
            quickActions = resolveQuickActions(user).take(6),
            alerts = alerts,
            loading = snapshot.fromEpochDay <= 0L,
            partialErrors = emptyList(),
        )
    }

    internal fun resolveKpis(snapshot: DashboardSnapshot, user: AppUserRecord): List<DashboardKpiUi> = when (user.role) {
        UserRole.OWNER, UserRole.MANAGER -> ownerKpis(snapshot, user)
        UserRole.CASHIER -> listOfNotNull(
            permitted(user, Permission.SALES) { money("sales", "فروش بازه", snapshot.todayProfessionalSalesRial, AppScreen.SALES) },
            permitted(user, Permission.SALES) { count("invoice_count", R.string.dashboard_kpi_invoice_count, snapshot.todayProfessionalInvoiceCount, AppScreen.SALES) },
            // Cashier is allowed to see the operational cash position without gaining Accounting navigation.
            money("cash", R.string.dashboard_kpi_cash_amount, snapshot.cashBalanceRial, AppScreen.SALES),
            permitted(user, Permission.SALES) { count("held", "فروش‌های معلق", snapshot.heldSaleCount, AppScreen.SALES) },
        )
        UserRole.INVENTORY, UserRole.STOREKEEPER -> listOfNotNull(
            permitted(user, Permission.INVENTORY) { count("low_stock", "کم‌موجودی", snapshot.lowStockCount, AppScreen.INVENTORY) },
            permitted(user, Permission.INVENTORY) { count("expiry", R.string.dashboard_kpi_expiring, snapshot.expiringLotCount, AppScreen.INVENTORY) },
            permitted(user, Permission.INVENTORY) { count("slow_stock", "کم‌گردش", snapshot.slowStockCount, AppScreen.INVENTORY) },
            permitted(user, Permission.INVENTORY) { money("waste", "ضایعات بازه", snapshot.wasteRial, AppScreen.STOCK_MOVEMENTS) },
        )
        UserRole.ACCOUNTANT -> listOfNotNull(
            permitted(user, Permission.ACCOUNTING) { money("liquidity", R.string.dashboard_kpi_liquidity, snapshot.cashBalanceRial + snapshot.bankBalanceRial, AppScreen.TREASURY) },
            permitted(user, Permission.ACCOUNTING) { money("payables", R.string.dashboard_kpi_payables, snapshot.supplierPayablesRial, AppScreen.PURCHASES) },
            permitted(user, Permission.ACCOUNTING) { money("receivables", R.string.dashboard_kpi_receivables, snapshot.customerReceivablesRial, AppScreen.CRM) },
            permitted(user, Permission.PERSONNEL) { money("unpaid_payroll", R.string.dashboard_kpi_unpaid_payroll, snapshot.unpaidPayrollRial, AppScreen.PERSONNEL) },
        )
        UserRole.HR -> listOfNotNull(
            permitted(user, Permission.PERSONNEL_VIEW) { count("hr_present", R.string.dashboard_kpi_hr_present, snapshot.presentCount, AppScreen.PERSONNEL) },
            permitted(user, Permission.ATTENDANCE_EDIT) { count("hr_anomaly", R.string.dashboard_kpi_hr_anomaly, snapshot.attendanceAnomalyCount, AppScreen.PERSONNEL) },
            permitted(user, Permission.ATTENDANCE_EDIT) { count("hr_absence", R.string.dashboard_kpi_hr_absence, snapshot.absentCount, AppScreen.PERSONNEL) },
            permitted(user, Permission.PAYROLL_VIEW_ALL) { money("hr_payroll", R.string.dashboard_kpi_unpaid_payroll, snapshot.unpaidPayrollRial, AppScreen.PERSONNEL) },
        )
        UserRole.KITCHEN -> emptyList()
        UserRole.LEGACY_RESTRICTED -> emptyList()
    }

    private fun ownerKpis(snapshot: DashboardSnapshot, user: AppUserRecord): List<DashboardKpiUi> = listOfNotNull(
        permitted(user, Permission.SALES) { money("sales", "فروش بازه", snapshot.todayProfessionalSalesRial, AppScreen.SALES) },
        permitted(user, Permission.ACCOUNTING) { money("gross_profit", "سود تقریبی مواد", snapshot.todayProfessionalGrossProfitRial, AppScreen.REPORTS) },
        permitted(user, Permission.ACCOUNTING) { money("liquidity", R.string.dashboard_kpi_liquidity, snapshot.cashBalanceRial + snapshot.bankBalanceRial, AppScreen.TREASURY) },
        count("critical", R.string.dashboard_kpi_critical_alerts, criticalCount(snapshot, user), AppScreen.ALERTS),
    )

    internal fun resolveQuickActions(user: AppUserRecord): List<DashboardQuickActionUi> {
        val allowed = buildList {
            if (user.role.allows(Permission.SALES)) add(DashboardQuickActionUi("sale", R.string.dashboard_action_new_sale, "ثبت فاکتور", AppScreen.SALES))
            if (user.role.allows(Permission.PURCHASES)) add(DashboardQuickActionUi("purchase", R.string.dashboard_action_new_purchase, "ثبت خرید", AppScreen.NEW_PURCHASE))
            if (user.role.allows(Permission.INVENTORY)) add(DashboardQuickActionUi("inventory", R.string.dashboard_action_inventory, "موجودی و گردش", AppScreen.INVENTORY))
            if (user.role.allows(Permission.TREASURY)) add(DashboardQuickActionUi("treasury", R.string.dashboard_action_treasury, "خزانه‌داری", AppScreen.TREASURY))
            if (user.role.allows(Permission.PERSONNEL)) add(DashboardQuickActionUi("personnel", R.string.dashboard_action_personnel, "حضور و حقوق", AppScreen.PERSONNEL))
            if (user.role.allows(Permission.REPORTS)) add(DashboardQuickActionUi("reports", R.string.dashboard_action_reports, "مرکز گزارش", AppScreen.REPORTS))
        }.take(5).toMutableList()
        allowed += DashboardQuickActionUi("more", R.string.dashboard_action_more, "همه بخش‌های مجاز", AppScreen.MORE)
        return allowed
    }

    internal fun resolveAlerts(snapshot: DashboardSnapshot, user: AppUserRecord): List<DashboardAttentionUi> = buildList {
        if (user.role.allows(Permission.INVENTORY) && snapshot.lowStockCount > 0) add(
            DashboardAttentionUi("low_stock", DashboardAttentionSeverity.WARNING, "کالاهای کم‌موجودی", "موجودی این اقلام نیازمند بررسی است.", snapshot.lowStockCount, AppScreen.INVENTORY),
        )
        if (user.role.allows(Permission.INVENTORY) && snapshot.expiringLotCount > 0) add(
            DashboardAttentionUi("expiry", DashboardAttentionSeverity.CRITICAL, R.string.dashboard_kpi_expiring, "لات‌های نزدیک به انقضا را بررسی کنید.", snapshot.expiringLotCount, AppScreen.INVENTORY),
        )
        if (user.role.allows(Permission.PERSONNEL) && snapshot.attendanceAnomalyCount > 0) add(
            DashboardAttentionUi("attendance", DashboardAttentionSeverity.WARNING, "مغایرت حضور", "رکوردهای حضور نیازمند رسیدگی هستند.", snapshot.attendanceAnomalyCount, AppScreen.PERSONNEL),
        )
        if (user.role.allows(Permission.PERSONNEL) && snapshot.unpaidPayrollRial > 0) add(
            DashboardAttentionUi("payroll", DashboardAttentionSeverity.WARNING, R.string.dashboard_kpi_unpaid_payroll, "پرداخت‌های حقوق باز را بررسی کنید.", 1, AppScreen.PERSONNEL),
        )
        if (user.role.allows(Permission.ASSETS) && snapshot.dueMaintenanceCount > 0) add(
            DashboardAttentionUi("maintenance", DashboardAttentionSeverity.NOTICE, "سرویس دارایی", "دارایی‌های سررسید سرویس دارند.", snapshot.dueMaintenanceCount, AppScreen.ASSETS),
        )
    }

    private fun criticalCount(snapshot: DashboardSnapshot, user: AppUserRecord): Long = resolveAlerts(snapshot, user)
        .filter { it.severity == DashboardAttentionSeverity.CRITICAL || it.severity == DashboardAttentionSeverity.WARNING }
        .sumOf { it.count }

    private inline fun <T> permitted(user: AppUserRecord, permission: Permission, block: () -> T): T? =
        if (user.role.allows(permission)) block() else null

    private fun money(id: String, title: String, value: Long, destination: AppScreen?) =
        DashboardKpiUi(id, title, value, DashboardKpiKind.MONEY, destination)

    private fun count(id: String, title: String, value: Long, destination: AppScreen?) =
        DashboardKpiUi(id, title, value, DashboardKpiKind.COUNT, destination)
}
