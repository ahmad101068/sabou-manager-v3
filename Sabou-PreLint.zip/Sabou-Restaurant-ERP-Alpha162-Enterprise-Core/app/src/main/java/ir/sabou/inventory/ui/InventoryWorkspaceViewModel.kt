package ir.sabou.inventory.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import ir.sabou.inventory.application.inventory.InventoryUseCases
import ir.sabou.inventory.application.procurement.ProcurementUseCases
import ir.sabou.inventory.core.GlobalId
import ir.sabou.inventory.domain.inventory.ChangeInventoryLotStatusCommand
import ir.sabou.inventory.domain.inventory.CreateInventoryCountSessionCommand
import ir.sabou.inventory.domain.inventory.CreateInventoryTransferCommand
import ir.sabou.inventory.domain.inventory.CreateWasteCommand
import ir.sabou.inventory.domain.inventory.InventoryBalanceQuery
import ir.sabou.inventory.domain.inventory.InventoryBalanceView
import ir.sabou.inventory.domain.inventory.InventoryCountActionCommand
import ir.sabou.inventory.domain.inventory.InventoryCountLineView
import ir.sabou.inventory.domain.inventory.InventoryCountScope
import ir.sabou.inventory.domain.inventory.InventoryCountSearch
import ir.sabou.inventory.domain.inventory.InventoryCountSession
import ir.sabou.inventory.domain.inventory.InventoryDashboardSnapshot
import ir.sabou.inventory.domain.inventory.InventoryItemMasterDraft
import ir.sabou.inventory.domain.inventory.InventoryItemMasterRecord
import ir.sabou.inventory.domain.inventory.InventoryItemSearch
import ir.sabou.inventory.domain.inventory.InventoryLocationDraft
import ir.sabou.inventory.domain.inventory.InventoryLocationRecord
import ir.sabou.inventory.domain.inventory.InventoryLocationSearch
import ir.sabou.inventory.domain.inventory.InventoryLot
import ir.sabou.inventory.domain.inventory.InventoryLotDraft
import ir.sabou.inventory.domain.inventory.InventoryLotSearch
import ir.sabou.inventory.domain.inventory.InventoryLotStatus
import ir.sabou.inventory.domain.inventory.InventoryMovementQuery
import ir.sabou.inventory.domain.inventory.InventoryMovementView
import ir.sabou.inventory.domain.inventory.InventoryReplenishmentQuery
import ir.sabou.inventory.domain.inventory.InventoryReplenishmentRecommendation
import ir.sabou.inventory.domain.inventory.InventoryStockStatus
import ir.sabou.inventory.domain.inventory.InventoryTransferDocument
import ir.sabou.inventory.domain.inventory.InventoryTransferSearch
import ir.sabou.inventory.domain.inventory.PostInventoryCountCommand
import ir.sabou.inventory.domain.inventory.PostWasteCommand
import ir.sabou.inventory.domain.inventory.ReceiveInventoryTransferCommand
import ir.sabou.inventory.domain.inventory.RecordInventoryCountCommand
import ir.sabou.inventory.domain.inventory.RegisterInventoryLotCommand
import ir.sabou.inventory.domain.inventory.TransferActionCommand
import ir.sabou.inventory.domain.inventory.InventoryWasteDocument
import ir.sabou.inventory.domain.inventory.InventoryWasteSearch
import ir.sabou.inventory.domain.inventory.WasteActionCommand
import ir.sabou.inventory.domain.operations.AppUserRecord
import ir.sabou.inventory.domain.operations.SecurityRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

enum class InventoryWorkspaceSection {
    OVERVIEW,
    ITEMS,
    EXPIRY,
    MOVEMENTS,
    COUNTS,
    WASTE,
    TRANSFERS,
    REPLENISHMENT,
    PERIODS,
}

data class InventoryWorkspaceUiState(
    val section: InventoryWorkspaceSection = InventoryWorkspaceSection.OVERVIEW,
    val currentUser: AppUserRecord? = null,
    val loading: Boolean = true,
    val busy: Boolean = false,
    val message: String? = null,
    val dashboard: InventoryDashboardSnapshot? = null,
    val items: List<InventoryItemMasterRecord> = emptyList(),
    val balances: List<InventoryBalanceView> = emptyList(),
    val locations: List<InventoryLocationRecord> = emptyList(),
    val lots: List<InventoryLot> = emptyList(),
    val countSessions: List<InventoryCountSession> = emptyList(),
    val selectedCountSession: InventoryCountSession? = null,
    val selectedCountLines: List<InventoryCountLineView> = emptyList(),
    val wasteDocuments: List<InventoryWasteDocument> = emptyList(),
    val transfers: List<InventoryTransferDocument> = emptyList(),
    val replenishment: List<InventoryReplenishmentRecommendation> = emptyList(),
    val movements: List<InventoryMovementView> = emptyList(),
    val query: String = "",
    val locationId: Long? = null,
    val stockStatus: InventoryStockStatus = InventoryStockStatus.ALL,
    val focusedItemId: Long? = null,
)

/** Coordinates Inventory 2.0 workflows; Compose only renders this state and emits intents. */
class InventoryWorkspaceViewModel(
    private val inventory: InventoryUseCases,
    private val procurement: ProcurementUseCases,
    private val security: SecurityRepository,
) : ViewModel() {
    private val mutableState = MutableStateFlow(InventoryWorkspaceUiState())
    val state: StateFlow<InventoryWorkspaceUiState> = mutableState.asStateFlow()
    private var refreshJob: Job? = null

    init {
        viewModelScope.launch {
            security.currentUser.collect { user ->
                mutableState.update { it.copy(currentUser = user) }
                if (user != null) refresh()
            }
        }
    }

    fun selectSection(section: InventoryWorkspaceSection) {
        mutableState.update { it.copy(section = section, message = null) }
    }

    fun setQuery(value: String) {
        mutableState.update { it.copy(query = value.take(80), focusedItemId = null) }
    }

    fun setLocation(locationId: Long?) {
        mutableState.update { it.copy(locationId = locationId) }
        refresh()
    }

    fun setStockStatus(status: InventoryStockStatus) {
        mutableState.update { it.copy(stockStatus = status) }
        refresh()
    }

    fun search() = refresh()

    fun focusItem(itemId: Long, section: InventoryWorkspaceSection = InventoryWorkspaceSection.ITEMS) {
        viewModelScope.launch {
            runCatching { inventory.item(itemId) }
                .onSuccess { item ->
                    mutableState.update { it.copy(query = item.sku.value, focusedItemId = item.id, section = section) }
                    refresh()
                }
                .onFailure { failure ->
                    mutableState.update { it.copy(message = UiErrorHandler.message("InventoryItemDrillDown", failure)) }
                }
        }
    }

    fun refresh() {
        if (mutableState.value.currentUser == null) return
        refreshJob?.cancel()
        refreshJob = viewModelScope.launch {
            mutableState.update { it.copy(loading = true, message = null) }
            runCatching {
                val current = mutableState.value
                val today = currentEpochDay()
                val locationId = current.locationId
                InventoryWorkspaceData(
                    dashboard = inventory.dashboard(today),
                    items = inventory.searchItems(
                        InventoryItemSearch(query = current.query, limit = PAGE_SIZE),
                    ),
                    balances = inventory.balances(
                        InventoryBalanceQuery(
                            query = current.query,
                            locationId = locationId,
                            stockStatus = current.stockStatus,
                            limit = PAGE_SIZE,
                        ),
                    ),
                    locations = inventory.searchLocations(InventoryLocationSearch(limit = PAGE_SIZE)),
                    lots = inventory.searchLots(InventoryLotSearch(locationId = locationId, limit = PAGE_SIZE)),
                    countSessions = inventory.searchCounts(InventoryCountSearch(locationId = locationId, limit = PAGE_SIZE)),
                    wastes = inventory.searchWaste(
                        InventoryWasteSearch(
                            locationId = locationId,
                            fromEpochDay = (today - 365).coerceAtLeast(1),
                            toEpochDay = today,
                            limit = PAGE_SIZE,
                        ),
                    ),
                    transfers = inventory.searchTransfers(InventoryTransferSearch(locationId = locationId, limit = PAGE_SIZE)),
                    replenishment = inventory.replenishmentRecommendations(
                        InventoryReplenishmentQuery(
                            locationId = locationId,
                            asOfEpochDay = today,
                            actionableOnly = false,
                            limit = PAGE_SIZE,
                        ),
                    ),
                    movements = inventory.movements(
                        InventoryMovementQuery(itemId = current.focusedItemId, locationId = locationId, limit = PAGE_SIZE),
                    ),
                )
            }.onSuccess { data ->
                mutableState.update {
                    it.copy(
                        loading = false,
                        dashboard = data.dashboard,
                        items = data.items,
                        balances = data.balances,
                        locations = data.locations,
                        lots = data.lots,
                        countSessions = data.countSessions,
                        wasteDocuments = data.wastes,
                        transfers = data.transfers,
                        replenishment = data.replenishment,
                        movements = data.movements,
                    )
                }
            }.onFailure { failure ->
                mutableState.update {
                    it.copy(loading = false, message = UiErrorHandler.message("InventoryWorkspaceViewModel", failure))
                }
            }
        }
    }

    fun saveItem(id: Long?, draft: InventoryItemMasterDraft, done: () -> Unit = {}) =
        runAction("اطلاعات کالای انبار ذخیره شد.", done) { inventory.saveItem(id, draft) }

    fun deactivateItem(id: Long) = runAction("کالا غیرفعال شد.") { inventory.deactivateItem(id) }

    fun saveLocation(id: Long?, draft: InventoryLocationDraft, done: () -> Unit = {}) =
        runAction("محل نگهداری ذخیره شد.", done) { inventory.saveLocation(id, draft) }

    fun registerLot(draft: InventoryLotDraft, reason: String, done: () -> Unit = {}) =
        runActorAction("لات کالا ثبت شد.", done) { actorId ->
            inventory.registerLot(RegisterInventoryLotCommand(draft, actorId, reason))
        }

    fun changeLotStatus(
        lot: InventoryLot,
        nextStatus: InventoryLotStatus,
        reason: String,
    ) = runActorAction("وضعیت لات به‌روزرسانی شد.") { actorId ->
        inventory.changeLotStatus(
            ChangeInventoryLotStatusCommand(
                lotId = lot.id,
                expectedStatus = lot.status,
                nextStatus = nextStatus,
                businessEpochDay = currentEpochDay(),
                actorId = actorId,
                reason = reason,
            ),
        )
    }

    fun createCount(
        locationId: Long,
        itemIds: Set<Long>,
        blindCount: Boolean,
        notes: String,
        done: () -> Unit = {},
    ) = runAction("جلسه انبارگردانی ایجاد شد.", done) {
        inventory.createCount(
            CreateInventoryCountSessionCommand(
                locationId = locationId,
                scope = if (itemIds.isEmpty()) InventoryCountScope.ALL_LOCATION else InventoryCountScope.ITEM_SELECTION,
                itemIds = itemIds,
                blindCount = blindCount,
                businessEpochDay = currentEpochDay(),
                notes = notes,
            ),
        )
    }

    fun selectCount(session: InventoryCountSession?, canReviewVariance: Boolean) {
        mutableState.update { it.copy(selectedCountSession = session, selectedCountLines = emptyList()) }
        if (session != null) viewModelScope.launch {
            runCatching { inventory.countLines(session.id, canReviewVariance) }
                .onSuccess { lines -> mutableState.update { it.copy(selectedCountLines = lines) } }
                .onFailure { failure ->
                    mutableState.update { it.copy(message = UiErrorHandler.message("InventoryCountCenter", failure)) }
                }
        }
    }

    fun openCount(sessionId: Long) = countAction(sessionId, "جلسه شمارش باز شد.") { command -> inventory.openCount(command) }

    fun recordCount(lineId: Long, quantityMicros: Long, unitCostRial: Long?, reason: String) {
        val session = mutableState.value.selectedCountSession ?: return
        runActorAction("مقدار شمارش ثبت شد.") { actorId ->
            inventory.recordCount(
                RecordInventoryCountCommand(session.id, lineId, quantityMicros, unitCostRial, reason, actorId),
            )
            val canReview = mutableState.value.currentUser?.role?.allows(
                ir.sabou.inventory.domain.security.Permission.INVENTORY_COUNT_APPROVE,
            ) == true
            val updatedSession = inventory.countSession(session.id)
            val updatedLines = inventory.countLines(session.id, canReview)
            mutableState.update {
                it.copy(selectedCountSession = updatedSession, selectedCountLines = updatedLines)
            }
        }
    }

    fun submitCount(sessionId: Long) = countAction(sessionId, "جلسه برای بررسی ارسال شد.") { inventory.submitCount(it) }
    fun approveCount(sessionId: Long) = countAction(sessionId, "انبارگردانی تأیید شد.") { inventory.approveCount(it) }
    fun cancelCount(sessionId: Long) = countAction(sessionId, "جلسه انبارگردانی لغو شد.") { inventory.cancelCount(it) }
    fun postCount(sessionId: Long) = runActorAction("مغایرت انبارگردانی به دفترکل ثبت شد.") { actorId ->
        inventory.postCount(PostInventoryCountCommand(sessionId, actorId))
    }

    fun submitWaste(command: CreateWasteCommand, done: () -> Unit = {}) =
        runAction("سند ضایعات برای ثبت آماده شد.", done) { inventory.submitWaste(command) }

    fun approveWaste(id: Long, reason: String) = runActorAction("سند ضایعات تأیید شد.") { actorId ->
        inventory.approveWaste(WasteActionCommand(id, actorId, reason))
    }

    fun postWaste(id: Long) = runActorAction("ضایعات به دفترکل موجودی ثبت شد.") { actorId ->
        inventory.postWaste(PostWasteCommand(id, actorId))
    }

    fun createTransfer(command: CreateInventoryTransferCommand, done: () -> Unit = {}) =
        runAction("درخواست انتقال ایجاد شد.", done) { inventory.createTransfer(command) }

    fun approveTransfer(id: Long, reason: String) = transferAction(id, "انتقال تأیید شد.", reason) {
        inventory.approveTransfer(it)
    }

    fun issueTransfer(id: Long, reason: String) = transferAction(id, "کالا از مبدأ صادر و در راه ثبت شد.", reason) {
        inventory.issueTransfer(it)
    }

    fun receiveTransfer(document: InventoryTransferDocument, reason: String) =
        runActorAction("انتقال در مقصد دریافت شد.") { actorId ->
            inventory.receiveTransfer(
                ReceiveInventoryTransferCommand(
                    transferId = document.id,
                    actorId = actorId,
                    businessEpochDay = currentEpochDay(),
                    receivedQuantityByLineId = document.lines.associate { line ->
                        line.id to requireNotNull(line.issuedQuantityMicros)
                    },
                    reason = reason,
                ),
            )
        }

    fun submitReplenishment(itemIds: List<Long>) = runAction("پیشنهادها به درخواست خرید ارسال شدند.") {
        procurement.submitSuggestedRequisition(itemIds.distinct().take(100))
    }

    fun clearMessage() {
        mutableState.update { it.copy(message = null) }
    }

    private fun countAction(
        sessionId: Long,
        success: String,
        block: suspend (InventoryCountActionCommand) -> Unit,
    ) = runActorAction(success) { actorId ->
        block(InventoryCountActionCommand(sessionId, actorId, "تغییر وضعیت کنترل‌شده انبارگردانی"))
        if (mutableState.value.selectedCountSession?.id == sessionId) {
            val canReview = mutableState.value.currentUser?.role?.allows(
                ir.sabou.inventory.domain.security.Permission.INVENTORY_COUNT_APPROVE,
            ) == true
            val updatedSession = inventory.countSession(sessionId)
            val updatedLines = inventory.countLines(sessionId, canReview)
            mutableState.update {
                it.copy(
                    selectedCountSession = updatedSession,
                    selectedCountLines = updatedLines,
                )
            }
        }
    }

    private fun transferAction(
        transferId: Long,
        success: String,
        reason: String,
        block: suspend (TransferActionCommand) -> InventoryTransferDocument,
    ) = runActorAction(success) { actorId ->
        block(TransferActionCommand(transferId, actorId, currentEpochDay(), reason, GlobalId.new().value))
    }

    private fun runActorAction(
        success: String,
        done: () -> Unit = {},
        block: suspend (Long) -> Unit,
    ) {
        val actorId = mutableState.value.currentUser?.id ?: return
        runAction(success, done) { block(actorId) }
    }

    private fun runAction(success: String, done: () -> Unit = {}, block: suspend () -> Unit) {
        if (mutableState.value.busy) return
        viewModelScope.launch {
            mutableState.update { it.copy(busy = true, message = null) }
            runCatching { block() }
                .onSuccess {
                    mutableState.update { state -> state.copy(busy = false, message = success) }
                    done()
                    refresh()
                }
                .onFailure { failure ->
                    mutableState.update {
                        it.copy(busy = false, message = UiErrorHandler.message("InventoryWorkspaceViewModel", failure))
                    }
                }
        }
    }

    companion object {
        private const val PAGE_SIZE = 100

        fun factory(
            inventory: InventoryUseCases,
            procurement: ProcurementUseCases,
            security: SecurityRepository,
        ): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T = InventoryWorkspaceViewModel(
                inventory,
                procurement,
                security,
            ) as T
        }
    }
}

private data class InventoryWorkspaceData(
    val dashboard: InventoryDashboardSnapshot,
    val items: List<InventoryItemMasterRecord>,
    val balances: List<InventoryBalanceView>,
    val locations: List<InventoryLocationRecord>,
    val lots: List<InventoryLot>,
    val countSessions: List<InventoryCountSession>,
    val wastes: List<InventoryWasteDocument>,
    val transfers: List<InventoryTransferDocument>,
    val replenishment: List<InventoryReplenishmentRecommendation>,
    val movements: List<InventoryMovementView>,
)
