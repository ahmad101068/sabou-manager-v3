package ir.sabou.inventory

import android.content.Context

const val DEFAULT_ORGANIZATION_TITLE = "مدیریت کافه رستوران"
private const val UI_PREFERENCES = "restaurant_manager_ui"
private const val ORGANIZATION_NAME_KEY = "organization_name"

fun Context.loadOrganizationName(): String =
    getSharedPreferences(UI_PREFERENCES, Context.MODE_PRIVATE)
        .getString(ORGANIZATION_NAME_KEY, "")
        .orEmpty()
        .trim()

fun Context.saveOrganizationName(value: String) {
    getSharedPreferences(UI_PREFERENCES, Context.MODE_PRIVATE)
        .edit()
        .putString(ORGANIZATION_NAME_KEY, value.trim())
        .apply()
}

fun organizationDisplayTitle(value: String): String =
    value.trim().ifBlank { DEFAULT_ORGANIZATION_TITLE }

fun Context.organizationDisplayName(): String = organizationDisplayTitle(loadOrganizationName())
