package ir.sabou.inventory.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun InventoryWorkspaceScreen(
    state: InventoryWorkspaceUiState,
    viewModel: InventoryWorkspaceViewModel,
    operationsState: OperationsUiState,
    operations: OperationsViewModel,
    onBack: () -> Unit,
) {
    val section = state.section
    val title = inventorySectionTitle(section)
    val subtitle = inventorySectionSubtitle(section)
    Scaffold(
        topBar = {
            ProfessionalTopBar(
                title = title,
                subtitle = subtitle,
                onBack = {
                    if (section == InventoryWorkspaceSection.OVERVIEW) onBack()
                    else viewModel.selectSection(InventoryWorkspaceSection.OVERVIEW)
                },
                actionLabel = "تازه‌سازی",
                onAction = viewModel::refresh,
            )
        },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            state.message?.let { MessageCard(it) }
            when (section) {
                InventoryWorkspaceSection.OVERVIEW -> InventoryOverviewScreen(state, viewModel::selectSection)
                InventoryWorkspaceSection.ITEMS -> InventoryItemCenterScreen(state, viewModel)
                InventoryWorkspaceSection.EXPIRY -> InventoryExpiryCenterScreen(state, viewModel)
                InventoryWorkspaceSection.MOVEMENTS -> InventoryMovementCenterScreen(state)
                InventoryWorkspaceSection.COUNTS -> InventoryCountCenterScreen(state, viewModel)
                InventoryWorkspaceSection.WASTE -> InventoryWasteCenterScreen(state, viewModel)
                InventoryWorkspaceSection.TRANSFERS -> InventoryTransferCenterScreen(state, viewModel)
                InventoryWorkspaceSection.REPLENISHMENT -> InventoryReplenishmentCenterScreen(state, viewModel)
                InventoryWorkspaceSection.PERIODS -> InventoryPeriodCenterScreen(
                    state = operationsState,
                    onClose = operations::closeInventoryPeriod,
                    onReopen = operations::reopenInventoryPeriod,
                    onSelectClosure = operations::selectInventoryClosure,
                )
            }
        }
    }
}

@Composable
private fun InventoryOverviewScreen(
    state: InventoryWorkspaceUiState,
    onOpen: (InventoryWorkspaceSection) -> Unit,
) {
    val dashboard = state.dashboard
    val actionableReplenishment = state.replenishment.count { it.isActionable }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        if (state.loading && dashboard == null) item { MessageCard("در حال خواندن دفترکل و کنترل‌های انبار…") }
        item { SectionHeading("نیازمند اقدام", "هر کارت به مرکز عملیاتی همان موضوع باز می‌شود") }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                InventoryDecisionCard(
                    "کمبود / اتمام",
                    "${dashboard?.lowStockItemCount ?: 0} / ${dashboard?.outOfStockItemCount ?: 0}",
                    "بازبینی نقطه سفارش",
                    Modifier.weight(1f),
                ) { onOpen(InventoryWorkspaceSection.REPLENISHMENT) }
                InventoryDecisionCard(
                    "لات در خطر",
                    "${dashboard?.expiringLotCount ?: 0} + ${dashboard?.expiredLotCount ?: 0}",
                    "انقضا و قرنطینه",
                    Modifier.weight(1f),
                ) { onOpen(InventoryWorkspaceSection.EXPIRY) }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                InventoryDecisionCard(
                    "انبارگردانی باز",
                    (dashboard?.pendingCountSessionCount ?: 0).toString(),
                    "شمارش و تأیید",
                    Modifier.weight(1f),
                ) { onOpen(InventoryWorkspaceSection.COUNTS) }
                InventoryDecisionCard(
                    "انتقال باز",
                    (dashboard?.pendingTransferCount ?: 0).toString(),
                    "درخواست تا دریافت",
                    Modifier.weight(1f),
                ) { onOpen(InventoryWorkspaceSection.TRANSFERS) }
            }
        }
        item { SectionHeading("وضعیت مالی موجودی", "مقادیر از Ledger و Projection کنترل‌شده استخراج شده‌اند") }
        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
            ) {
                Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("ارزش موجودی", style = MaterialTheme.typography.labelLarge)
                    Text(formatMoney(dashboard?.totalInventoryValueRial ?: 0), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                    CompactInfoRow("هزینه ضایعات ۳۰ روز", formatMoney(dashboard?.wasteCostRial ?: 0), (dashboard?.wasteCostRial ?: 0) > 0)
                    CompactInfoRow("قدر مطلق مغایرت شمارش ۳۰ روز", formatMoney(dashboard?.inventoryVarianceRial ?: 0), (dashboard?.inventoryVarianceRial ?: 0) > 0)
                }
            }
        }
        item { SectionHeading("مراکز کنترل", "داده‌ها bounded و فیلترها در پایگاه داده اجرا می‌شوند") }
        items(inventoryCenters, key = { it.first.name }) { (target, description) ->
            Card(
                modifier = Modifier.fillMaxWidth().testTag("inventory_section_${target.name}").clickable { onOpen(target) },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(inventorySectionTitle(target), fontWeight = FontWeight.Bold)
                    Text(
                        if (target == InventoryWorkspaceSection.REPLENISHMENT) "$description · $actionableReplenishment پیشنهاد قابل اقدام" else description,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }
        }
    }
}

@Composable
private fun InventoryDecisionCard(
    title: String,
    value: String,
    context: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    Card(
        modifier = modifier.clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(title, style = MaterialTheme.typography.labelLarge)
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
            Text(context, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
        }
    }
}

private val inventoryCenters = listOf(
    InventoryWorkspaceSection.ITEMS to "کالا، SKU، بارکد، محل و مانده",
    InventoryWorkspaceSection.EXPIRY to "FEFO، انقضا، قرنطینه و لات",
    InventoryWorkspaceSection.MOVEMENTS to "دفتر غیرقابل‌ویرایش گردش موجودی",
    InventoryWorkspaceSection.COUNTS to "شمارش کور، بازشماری، تأیید و Posting",
    InventoryWorkspaceSection.WASTE to "ضایعات ردیابی‌پذیر و بهای ثبت‌شده",
    InventoryWorkspaceSection.TRANSFERS to "انتقال سندمحور و کالای در راه",
    InventoryWorkspaceSection.REPLENISHMENT to "پوشش، نقطه سفارش و درخواست خرید",
    InventoryWorkspaceSection.PERIODS to "بستن و بازگشایی کنترل‌شده دوره انبار",
)

internal fun inventorySectionTitle(section: InventoryWorkspaceSection): String = when (section) {
    InventoryWorkspaceSection.OVERVIEW -> "مرکز کنترل انبار"
    InventoryWorkspaceSection.ITEMS -> "کالا و محل نگهداری"
    InventoryWorkspaceSection.EXPIRY -> "مرکز انقضا و لات"
    InventoryWorkspaceSection.MOVEMENTS -> "دفتر گردش موجودی"
    InventoryWorkspaceSection.COUNTS -> "مرکز انبارگردانی"
    InventoryWorkspaceSection.WASTE -> "مرکز ضایعات"
    InventoryWorkspaceSection.TRANSFERS -> "مرکز انتقال"
    InventoryWorkspaceSection.REPLENISHMENT -> "تأمین مجدد"
    InventoryWorkspaceSection.PERIODS -> "کنترل دوره انبار"
}

private fun inventorySectionSubtitle(section: InventoryWorkspaceSection): String = when (section) {
    InventoryWorkspaceSection.OVERVIEW -> "آنچه اکنون نیازمند تصمیم و اقدام است"
    InventoryWorkspaceSection.ITEMS -> "Master Data، موجودی مکان‌محور و جست‌وجوی سریع"
    InventoryWorkspaceSection.EXPIRY -> "مصرف FEFO، قرنطینه و تبدیل صریح به ضایعات"
    InventoryWorkspaceSection.MOVEMENTS -> "ردیابی تا سند مبدأ، Actor و correlationId"
    InventoryWorkspaceSection.COUNTS -> "چرخه Draft تا Posted با تفکیک وظایف"
    InventoryWorkspaceSection.WASTE -> "مقدار، علت، بهای تاریخی، تأیید و ثبت"
    InventoryWorkspaceSection.TRANSFERS -> "درخواست، صدور، کالای در راه و دریافت"
    InventoryWorkspaceSection.REPLENISHMENT -> "تقاضا، Lead Time، Safety Stock و Procurement"
    InventoryWorkspaceSection.PERIODS -> "کنترل ثبت اسناد Backdated موجودی"
}

@Composable
internal fun InventoryEmptyState(text: String) {
    EmptyStatePanel("موردی یافت نشد", text)
}
