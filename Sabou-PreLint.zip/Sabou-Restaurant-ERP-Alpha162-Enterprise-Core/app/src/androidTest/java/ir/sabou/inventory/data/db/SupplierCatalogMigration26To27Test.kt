package ir.sabou.inventory.data.db

import android.content.Context
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.sqlite.db.SupportSQLiteOpenHelper
import androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class SupplierCatalogMigration26To27Test {
    private val context = ApplicationProvider.getApplicationContext<Context>()
    private val name = "supplier-catalog-migration-26-27.db"
    @After fun cleanUp() { context.deleteDatabase(name) }

    @Test fun addsCatalogAndKeepsExistingData() {
        open(26).use { it.writableDatabase.execSQL("CREATE TABLE marker (id INTEGER PRIMARY KEY NOT NULL, value TEXT NOT NULL)"); it.writableDatabase.execSQL("INSERT INTO marker VALUES (1, 'محفوظ')") }
        open(27).use { helper ->
            helper.writableDatabase.query("SELECT value FROM marker").use { cursor -> assertTrue(cursor.moveToFirst()); assertEquals("محفوظ", cursor.getString(0)) }
            helper.writableDatabase.query("PRAGMA table_info(supplier_item_offers)").use { cursor ->
                val columns = mutableSetOf<String>(); while (cursor.moveToNext()) columns += cursor.getString(cursor.getColumnIndexOrThrow("name"))
                assertTrue(columns.containsAll(setOf("supplierId", "itemId", "unitCostRial", "minimumOrderMicros", "orderMultipleMicros", "leadTimeDays", "validUntilEpochDay")))
            }
        }
    }

    private fun open(version: Int): SupportSQLiteOpenHelper {
        val callback = object : SupportSQLiteOpenHelper.Callback(version) {
            override fun onCreate(db: SupportSQLiteDatabase) = Unit
            override fun onUpgrade(db: SupportSQLiteDatabase, oldVersion: Int, newVersion: Int) { if (oldVersion == 26 && newVersion == 27) MIGRATION_26_27.migrate(db) }
        }
        return FrameworkSQLiteOpenHelperFactory().create(SupportSQLiteOpenHelper.Configuration.builder(context).name(name).callback(callback).build())
    }
}
