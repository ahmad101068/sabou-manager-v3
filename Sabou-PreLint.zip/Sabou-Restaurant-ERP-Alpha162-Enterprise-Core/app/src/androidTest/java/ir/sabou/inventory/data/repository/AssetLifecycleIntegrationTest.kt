package ir.sabou.inventory.data.repository

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.security.SessionAuthorizer
import ir.sabou.inventory.domain.assets.AssetAcquisitionSource
import ir.sabou.inventory.domain.assets.AssetDraft
import ir.sabou.inventory.domain.assets.AssetImpairmentDraft
import ir.sabou.inventory.domain.assets.AssetLifecycleType
import ir.sabou.inventory.domain.assets.AssetMaintenanceDraft
import ir.sabou.inventory.domain.assets.AssetSaleDraft
import ir.sabou.inventory.domain.assets.AssetTransferDraft
import ir.sabou.inventory.domain.assets.DepreciationDraft
import ir.sabou.inventory.domain.operations.UserDraft
import ir.sabou.inventory.domain.operations.UserRole
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class AssetLifecycleIntegrationTest {
    private lateinit var database: AppDatabase
    private lateinit var authorizer: SessionAuthorizer
    private lateinit var repository: LocalAssetRepository
    private var now = 3_000_000L

    @Before
    fun setUp() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = AppDatabase.createInMemory(context)
        authorizer = SessionAuthorizer(database)
        val security = LocalSecurityRepository(database, clock = { ++now }, authorizer = authorizer)
        val ownerId = security.save(null, UserDraft("owner-assets", "مالک دارایی", "123456", UserRole.OWNER, "87654321"))
        security.switchUser(ownerId, "123456")
        repository = LocalAssetRepository(database, clock = { ++now }, syncRecorder = null, authorizer = authorizer)
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun transfer_changesOperationalOwnership_preservesHistoricalCost_andAuditsLifecycle() = runBlocking {
        val assetId = repository.save(null, draft("AST-LIFE-1"))
        val historicalCost = requireNotNull(database.assetDao().assetById(assetId)).purchaseCostRial

        repository.transfer(
            AssetTransferDraft(
                assetId = assetId,
                toLocation = "انبار مرکزی",
                toBranch = "شعبه دو",
                toResponsiblePerson = "مسئول جدید",
                businessEpochDay = 20_010,
                reason = "انتقال بین شعب",
            ),
        )

        val after = requireNotNull(database.assetDao().assetById(assetId))
        assertEquals(historicalCost, after.purchaseCostRial)
        assertEquals("انبار مرکزی", after.location)
        assertEquals("شعبه دو", after.branch)
        assertEquals("مسئول جدید", after.responsiblePerson)
        val lifecycle = repository.observeLifecycle(assetId).first()
        assertTrue(lifecycle.any { it.type == AssetLifecycleType.PURCHASE })
        assertTrue(lifecycle.any { it.type == AssetLifecycleType.TRANSFER })
        val audits = database.auditLogDao().observeRecent(50).first()
        assertTrue(audits.any { it.entityType == "ASSET" && it.entityId == assetId && it.action == "TRANSFER" })
    }

    @Test
    fun maintenance_persistsSchedule_postsBalancedExpenseJournal_andKeepsAssetCostImmutable() = runBlocking {
        val assetId = repository.save(null, draft("AST-LIFE-2"))
        val costBefore = requireNotNull(database.assetDao().assetById(assetId)).purchaseCostRial

        repository.recordMaintenance(
            AssetMaintenanceDraft(
                assetId = assetId,
                serviceType = "سرویس دوره‌ای",
                serviceEpochDay = 20_020,
                costRial = 120_000L,
                contractor = "پیمانکار تست",
                note = "تعویض قطعه مصرفی",
                nextServiceEpochDay = 20_110,
                paymentSource = AssetAcquisitionSource.CASH,
            ),
        )

        val maintenance = repository.observeMaintenance(assetId).first().single()
        assertEquals(120_000L, maintenance.costRial)
        assertEquals(20_110L, maintenance.nextServiceEpochDay)
        assertEquals(costBefore, requireNotNull(database.assetDao().assetById(assetId)).purchaseCostRial)
        assertBalanced("ASSET_MAINTENANCE", assetId)
        assertTrue(repository.observeLifecycle(assetId).first().any { it.type == AssetLifecycleType.MAINTENANCE })
    }

    @Test
    fun impairment_reducesBookValue_withoutMutatingHistoricalCost_andPostsBalancedJournal() = runBlocking {
        val assetId = repository.save(null, draft("AST-LIFE-3"))
        val before = requireNotNull(database.assetDao().assetById(assetId))

        repository.impair(AssetImpairmentDraft(assetId, 20_030, 1_100_000L, "افت ارزش فنی"))

        val after = requireNotNull(database.assetDao().assetById(assetId))
        assertEquals(before.purchaseCostRial, after.purchaseCostRial)
        assertEquals(1_100_000L, after.impairmentRial)
        assertEquals(before.purchaseCostRial - 1_100_000L, after.purchaseCostRial - after.accumulatedDepreciationRial - after.impairmentRial)
        assertBalanced("ASSET_IMPAIRMENT", assetId)
        assertTrue(repository.observeLifecycle(assetId).first().any { it.type == AssetLifecycleType.IMPAIRMENT })
    }

    @Test
    fun sale_afterDepreciationAndImpairment_preservesHistoricalCost_calculatesGain_andBalancesJournal() = runBlocking {
        val assetId = repository.save(null, draft("AST-LIFE-4"))
        repository.postDepreciation(DepreciationDraft(assetId, 1405, 1, 20_040))
        repository.impair(AssetImpairmentDraft(assetId, 20_041, 1_100_000L, "افت ارزش قبل از فروش"))
        val beforeSale = requireNotNull(database.assetDao().assetById(assetId))
        val expectedBook = beforeSale.purchaseCostRial - beforeSale.accumulatedDepreciationRial - beforeSale.impairmentRial
        val salePrice = expectedBook + 1_000_000L

        repository.sell(
            AssetSaleDraft(
                assetId = assetId,
                businessEpochDay = 20_050,
                salePriceRial = salePrice,
                receiptSource = AssetAcquisitionSource.BANK,
                buyer = "خریدار تست",
                reason = "فروش دارایی مازاد",
            ),
        )

        val sold = requireNotNull(database.assetDao().assetById(assetId))
        assertEquals("SOLD", sold.status)
        assertEquals(12_000_000L, sold.purchaseCostRial)
        assertEquals(beforeSale.accumulatedDepreciationRial, sold.accumulatedDepreciationRial)
        assertEquals(beforeSale.impairmentRial, sold.impairmentRial)
        assertEquals(salePrice, sold.salePriceRial)
        val saleEntry = assertBalanced("ASSET_SALE", assetId)
        val lines = database.accountingDao().linesByEntry(saleEntry)
        assertEquals(1_000_000L, lines.single { it.accountCode == "4102" }.creditRial)
        assertEquals(12_000_000L, lines.single { it.accountCode == "1501" }.creditRial)
        assertTrue(repository.observeLifecycle(assetId).first().any { it.type == AssetLifecycleType.SALE })
    }

    private suspend fun assertBalanced(sourceType: String, assetId: Long): Long {
        val entry = database.accountingDao().entryBySource(sourceType, assetId)
        assertNotNull("journal missing for $sourceType", entry)
        val id = requireNotNull(entry).id
        val lines = database.accountingDao().linesByEntry(id)
        assertTrue(lines.isNotEmpty())
        assertEquals(lines.sumOf { it.debitRial }, lines.sumOf { it.creditRial })
        return id
    }

    private fun draft(code: String) = AssetDraft(
        assetCode = code,
        name = "فر صنعتی تست",
        category = "تجهیزات آشپزخانه",
        quantity = 1,
        purchaseEpochDay = 20_000,
        purchaseCostRial = 12_000_000L,
        salvageValueRial = 1_200_000L,
        usefulLifeMonths = 12,
        location = "آشپزخانه اصلی",
        notes = "دارایی تست چرخه عمر",
        acquisitionSource = AssetAcquisitionSource.BANK,
        branch = "شعبه یک",
        responsiblePerson = "مسئول اولیه",
    )
}
