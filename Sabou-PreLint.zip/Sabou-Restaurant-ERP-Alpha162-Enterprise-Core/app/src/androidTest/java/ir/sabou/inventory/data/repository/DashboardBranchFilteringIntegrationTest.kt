package ir.sabou.inventory.data.repository

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.db.SalesInvoiceEntity
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/** Regression proof that branch filtering happens in the dashboard query, not in ViewModel labels. */
@RunWith(AndroidJUnit4::class)
class DashboardBranchFilteringIntegrationTest {
    private lateinit var database: AppDatabase

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
    }

    @After fun tearDown() { database.close() }

    @Test
    fun salesBranchFilter_A100_B300_All400_isDatabaseScoped() = runBlocking {
        val day = 24_000L
        database.salesDao().insertInvoice(invoice("SAL-A", "cmd-a", "Branch A", day, 100))
        database.salesDao().insertInvoice(invoice("SAL-B", "cmd-b", "Branch B", day, 300))
        val repository = DashboardRepository(database)

        val branchA = repository.observeRange(day, day, DashboardPeriod.TODAY, branchName = "Branch A").first()
        val branchB = repository.observeRange(day, day, DashboardPeriod.TODAY, branchName = "Branch B").first()
        val all = repository.observeRange(day, day, DashboardPeriod.TODAY, branchName = null).first()

        assertEquals(100L, branchA.grossSalesRial)
        assertEquals(100L, branchA.todayProfessionalSalesRial)
        assertEquals(300L, branchB.grossSalesRial)
        assertEquals(300L, branchB.todayProfessionalSalesRial)
        assertEquals(400L, all.grossSalesRial)
        assertEquals(400L, all.todayProfessionalSalesRial)
    }

    private fun invoice(no: String, command: String, branch: String, day: Long, amount: Long) =
        SalesInvoiceEntity(
            invoiceNo = no,
            commandId = command,
            businessEpochDay = day,
            branchName = branch,
            customerId = null,
            dueEpochDay = null,
            grossRial = amount,
            discountRial = 0,
            serviceRial = 0,
            taxRial = 0,
            netRial = amount,
            creditRial = 0,
            theoreticalCostRial = 0,
            journalEntryId = null,
            cogsJournalEntryId = null,
            status = "POSTED",
            notes = "branch-filter-test",
            createdByActorId = 1,
            createdAtEpochMillis = day * 86_400_000L,
        )
}
