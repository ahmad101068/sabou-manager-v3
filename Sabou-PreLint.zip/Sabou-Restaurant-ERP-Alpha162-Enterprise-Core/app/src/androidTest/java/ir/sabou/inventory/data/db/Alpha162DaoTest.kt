package ir.sabou.inventory.data.db

import android.content.Context
import android.database.sqlite.SQLiteConstraintException
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class Alpha162DaoTest {
    private lateinit var database: AppDatabase

    @Before
    fun setUp() {
        database = AppDatabase.createInMemory(ApplicationProvider.getApplicationContext<Context>())
    }

    @After
    fun tearDown() = database.close()

    @Test
    fun restaurantDao_enforcesHallForeignKeyAndUniqueTableNumberPerHall() = runBlocking {
        val hallId = database.restaurantDao().insertHall(
            RestaurantHallEntity(name = "سالن DAO", sortOrder = 10, createdAtEpochMillis = 1L),
        )
        database.restaurantDao().insertTable(
            RestaurantTableEntity(hallId = hallId, tableNo = "A-1", capacity = 4, updatedAtEpochMillis = 2L),
        )

        assertThrows(SQLiteConstraintException::class.java) {
            runBlocking {
                database.restaurantDao().insertTable(
                    RestaurantTableEntity(hallId = hallId, tableNo = "A-1", capacity = 2, updatedAtEpochMillis = 3L),
                )
            }
        }
        assertThrows(SQLiteConstraintException::class.java) {
            runBlocking {
                database.restaurantDao().insertTable(
                    RestaurantTableEntity(hallId = Long.MAX_VALUE, tableNo = "FK-FAIL", capacity = 2, updatedAtEpochMillis = 4L),
                )
            }
        }
        assertEquals(1, database.restaurantDao().observeTables().first().count { it.hallId == hallId })
    }

    @Test
    fun restaurantOrder_rejectsOrphanWaiterAndCustomerReferences() = runBlocking {
        val hallId = database.restaurantDao().insertHall(RestaurantHallEntity(name = "سالن FK سفارش", sortOrder = 20, createdAtEpochMillis = 20L))
        val tableId = database.restaurantDao().insertTable(RestaurantTableEntity(hallId = hallId, tableNo = "FK-01", capacity = 4, updatedAtEpochMillis = 21L))

        assertThrows(SQLiteConstraintException::class.java) {
            runBlocking {
                database.restaurantDao().insertOrder(
                    RestaurantOrderEntity(
                        commandId = "00000000-0000-4000-8000-000000000901",
                        tableId = tableId,
                        waiterUserId = Long.MAX_VALUE,
                        guestCount = 2,
                        openedEpochDay = 20_000L,
                        openedAtEpochMillis = 22L,
                    ),
                )
            }
        }
        assertThrows(SQLiteConstraintException::class.java) {
            runBlocking {
                database.restaurantDao().insertOrder(
                    RestaurantOrderEntity(
                        commandId = "00000000-0000-4000-8000-000000000902",
                        tableId = tableId,
                        waiterUserId = null,
                        customerId = Long.MAX_VALUE,
                        guestCount = 2,
                        openedEpochDay = 20_000L,
                        openedAtEpochMillis = 23L,
                    ),
                )
            }
        }
        assertEquals(0L, scalar("SELECT COUNT(*) FROM restaurant_orders WHERE tableId=$tableId"))
    }

    @Test
    fun treasuryDao_rejectsDuplicateCommandAndOrphanLedgerEntry() = runBlocking {
        val first = TreasuryTransactionEntity(
            id = "txn-dao-1",
            commandId = "cmd-dao-unique",
            kind = "RECEIPT",
            businessEpochDay = 20_000L,
            sourceType = "DAO_TEST",
            sourceId = 1L,
            reason = "کنترل یکتایی فرمان",
            amountRial = 10_000L,
            actorId = 1L,
            correlationId = "dao:treasury:1",
            createdAtEpochMillis = 10L,
        )
        database.treasuryDao().insertTransaction(first)

        assertThrows(SQLiteConstraintException::class.java) {
            runBlocking { database.treasuryDao().insertTransaction(first.copy(id = "txn-dao-2")) }
        }
        assertThrows(SQLiteConstraintException::class.java) {
            runBlocking {
                database.treasuryDao().insertLedgerEntries(
                    listOf(
                        TreasuryLedgerEntryEntity(
                            transactionId = "missing-transaction",
                            accountId = "CASH:MAIN",
                            direction = "RECEIPT",
                            amountRial = 1_000L,
                            sourceType = "DAO_TEST",
                            sourceId = 2L,
                            businessEpochDay = 20_000L,
                            actorId = 1L,
                            createdAtEpochMillis = 11L,
                        ),
                    ),
                )
            }
        }
        assertEquals(first, database.treasuryDao().transactionById(first.id))
    }

    @Test
    fun restaurantDao_ordersActiveHallsBySortOrderThenName() = runBlocking {
        database.restaurantDao().insertHall(RestaurantHallEntity(name = "سالن آخر", sortOrder = 30, createdAtEpochMillis = 1L))
        database.restaurantDao().insertHall(RestaurantHallEntity(name = "سالن اول", sortOrder = 10, createdAtEpochMillis = 2L))

        val names = database.restaurantDao().observeHalls().first()
            .filter { it.name in setOf("سالن اول", "سالن آخر") }
            .map { it.name }
        assertEquals(listOf("سالن اول", "سالن آخر"), names)
    }

    private fun scalar(sql: String): Long = database.openHelper.writableDatabase.query(sql).use { cursor ->
        check(cursor.moveToFirst())
        cursor.getLong(0)
    }
}
