package ir.sabou.inventory.data.repository

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.db.InventoryItemEntity
import ir.sabou.inventory.data.security.SessionAuthorizer
import ir.sabou.inventory.core.GlobalId
import ir.sabou.inventory.domain.common.BusinessError
import ir.sabou.inventory.domain.common.BusinessRuleViolation
import ir.sabou.inventory.domain.inventory.CreateInventoryCountSessionCommand
import ir.sabou.inventory.domain.inventory.InventoryCommandContext
import ir.sabou.inventory.domain.inventory.InventoryCountActionCommand
import ir.sabou.inventory.domain.inventory.InventoryCountScope
import ir.sabou.inventory.domain.inventory.InventoryCountStatus
import ir.sabou.inventory.domain.inventory.InventoryMovementType
import ir.sabou.inventory.domain.inventory.InventoryReasonCode
import ir.sabou.inventory.domain.inventory.InventoryReferenceType
import ir.sabou.inventory.domain.inventory.PostInventoryCountCommand
import ir.sabou.inventory.domain.inventory.RecordInventoryCountCommand
import ir.sabou.inventory.domain.operations.UserDraft
import ir.sabou.inventory.domain.operations.UserRole
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class InventoryCountWorkflowIntegrationTest {
    private lateinit var database: AppDatabase
    private lateinit var authorizer: SessionAuthorizer
    private lateinit var security: LocalSecurityRepository
    private lateinit var service: LocalInventoryCountService
    private var now = 1_900_000_000_000L
    private lateinit var fixture: Fixture

    @Before
    fun setUp() = runBlocking {
        database = AppDatabase.createInMemory(ApplicationProvider.getApplicationContext<Context>())
        authorizer = SessionAuthorizer(database)
        security = LocalSecurityRepository(database, clock = { now }, authorizer = authorizer)
        val ownerId = security.save(
            null,
            UserDraft("count-owner", "مالک شمارش", "123456", UserRole.OWNER, "87654321"),
        )
        val managerId = security.save(
            null,
            UserDraft("count-manager", "مدیر شمارش", "654321", UserRole.MANAGER),
        )
        val cashierId = security.save(
            null,
            UserDraft("count-cashier", "صندوقدار شمارش", "456789", UserRole.CASHIER),
        )
        val locationId = requireNotNull(database.inventoryLocationDao().defaultLocationId())
        val itemId = database.inventoryDao().insert(
            InventoryItemEntity(
                name = "برنج شمارش",
                category = "مواد اولیه",
                unit = "کیلوگرم",
                createdAtEpochMillis = now,
                updatedAtEpochMillis = now,
            ),
        )
        LocalInventoryCommandEngine(database, clock = { now }).receive(
            itemId = itemId,
            quantityMicros = 10_000_000,
            valueRial = 2_000_000,
            movementType = InventoryMovementType.OPENING_BALANCE,
            referenceType = InventoryReferenceType.MIGRATION,
            referenceId = 1,
            movementEpochDay = BUSINESS_DAY,
            context = InventoryCommandContext.local(
                referenceType = InventoryReferenceType.MIGRATION,
                referenceId = 1,
                suffix = "count-test-opening:$itemId",
                actorId = ownerId,
                reasonCode = InventoryReasonCode.OPENING_BALANCE,
                reason = "مانده آغاز آزمون شمارش",
                correlationId = "count-test:opening:$itemId",
                locationId = locationId,
            ),
        )
        fixture = Fixture(ownerId, managerId, cashierId, locationId, itemId)
        service = LocalInventoryCountService(database, authorizer, clock = { ++now })
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun blindRecountApprovalAndPostAreAtomicAndReplaySafe() = runBlocking {
        val sessionId = createAndOpen()
        val line = service.lines(sessionId, canReviewVariance = false).single()
        assertNull(line.systemQuantityMicros)
        assertNull(line.varianceQuantityMicros)

        service.record(record(sessionId, line.lineId, 8_000_000))
        service.submit(action(sessionId, fixture.ownerId, "ارسال شمارش اول"))
        assertEquals(InventoryCountStatus.RECOUNT_REQUIRED, service.session(sessionId).status)

        service.record(record(sessionId, line.lineId, 8_000_000))
        service.submit(action(sessionId, fixture.ownerId, "ارسال بازشماری"))
        assertEquals(InventoryCountStatus.PENDING_APPROVAL, service.session(sessionId).status)

        security.switchUser(fixture.managerId, "654321")
        val review = service.lines(sessionId, canReviewVariance = true).single()
        assertEquals(10_000_000L, review.systemQuantityMicros)
        assertEquals(-2_000_000L, review.varianceQuantityMicros)
        service.approve(action(sessionId, fixture.managerId, "مغایرت بررسی شد"))

        val postCommandId = GlobalId.new().value
        val command = PostInventoryCountCommand(sessionId, fixture.managerId, postCommandId)
        val posted = service.post(command)
        val replay = service.post(command)

        assertEquals(InventoryCountStatus.POSTED, posted.status)
        assertEquals(posted.id, replay.id)
        assertEquals(8_000_000L, database.inventoryBalanceDao().byKey(fixture.itemId, fixture.locationId)?.onHandMicros)
        assertEquals(1L, scalar("SELECT COUNT(*) FROM stock_movements WHERE movementType='INVENTORY_COUNT'"))
        assertEquals(1L, scalar("SELECT COUNT(*) FROM inventory_counts WHERE itemId=${fixture.itemId}"))
        assertEquals(1L, scalar("SELECT COUNT(*) FROM audit_logs WHERE entityType='INVENTORY_COUNT_SESSION' AND action='POST'"))
    }

    @Test
    fun unapprovedCountCannotPostAndDoesNotMutateLedger() = runBlocking {
        val sessionId = createAndOpen()
        val line = service.lines(sessionId, false).single()
        service.record(record(sessionId, line.lineId, 10_000_000))
        service.submit(action(sessionId, fixture.ownerId, "ارسال شمارش بدون مغایرت"))
        val before = scalar("SELECT COUNT(*) FROM stock_movements")

        try {
            service.post(PostInventoryCountCommand(sessionId, fixture.ownerId, GlobalId.new().value))
            fail("ثبت جلسه تأییدنشده باید رد شود")
        } catch (error: BusinessRuleViolation) {
            assertTrue(error.error is BusinessError.CountNotApproved)
        }

        assertEquals(before, scalar("SELECT COUNT(*) FROM stock_movements"))
        assertEquals(0L, scalar("SELECT COUNT(*) FROM inventory_counts"))
    }

    @Test
    fun unauthorizedActorCannotApproveOrPostCount() = runBlocking {
        val sessionId = createAndOpen()
        val line = service.lines(sessionId, false).single()
        service.record(record(sessionId, line.lineId, 10_000_000))
        service.submit(action(sessionId, fixture.ownerId, "ارسال شمارش برای تأیید"))
        assertEquals(InventoryCountStatus.PENDING_APPROVAL, service.session(sessionId).status)
        val movementCount = scalar("SELECT COUNT(*) FROM stock_movements")

        security.switchUser(fixture.cashierId, "456789")
        try {
            service.approve(action(sessionId, fixture.cashierId, "تلاش تأیید بدون مجوز"))
            fail("کاربر بدون مجوز نباید شمارش را تأیید کند")
        } catch (error: BusinessRuleViolation) {
            assertTrue(error.error is BusinessError.PermissionDenied)
        }
        assertEquals(
            InventoryCountStatus.PENDING_APPROVAL.storedValue,
            database.inventoryCountDao().session(sessionId)?.status,
        )

        security.switchUser(fixture.managerId, "654321")
        service.approve(action(sessionId, fixture.managerId, "شمارش بررسی و تأیید شد"))
        security.switchUser(fixture.cashierId, "456789")
        try {
            service.post(PostInventoryCountCommand(sessionId, fixture.cashierId, GlobalId.new().value))
            fail("کاربر بدون مجوز نباید شمارش را ثبت نهایی کند")
        } catch (error: BusinessRuleViolation) {
            assertTrue(error.error is BusinessError.PermissionDenied)
        }

        assertEquals(
            InventoryCountStatus.APPROVED.storedValue,
            database.inventoryCountDao().session(sessionId)?.status,
        )
        assertEquals(movementCount, scalar("SELECT COUNT(*) FROM stock_movements"))
        assertEquals(0L, scalar("SELECT COUNT(*) FROM inventory_counts"))
    }

    @Test
    fun outboxFailureRollsBackCountMovementProjectionAuditAndStatus() = runBlocking {
        val sessionId = approvedSession(countedQuantityMicros = 9_000_000)
        val failing = LocalInventoryCountService(
            database,
            authorizer,
            clock = { ++now },
            syncRecorder = object : SyncRecorder(database, "count-failing-device") {
                override suspend fun record(
                    entityType: String,
                    entityId: Long,
                    changeType: String,
                    occurredAt: Long,
                    payloadFields: Map<String, String>,
                    recordAudit: Boolean,
                ) {
                    error("forced outbox failure")
                }
            },
        )
        val movementCount = scalar("SELECT COUNT(*) FROM stock_movements")
        val postAuditCount = scalar("SELECT COUNT(*) FROM audit_logs WHERE action='POST'")

        try {
            failing.post(PostInventoryCountCommand(sessionId, fixture.managerId, GlobalId.new().value))
            fail("خرابی outbox باید کل تراکنش را rollback کند")
        } catch (_: IllegalStateException) {
            Unit
        }

        assertEquals(InventoryCountStatus.APPROVED, service.session(sessionId).status)
        assertEquals(10_000_000L, database.inventoryBalanceDao().byKey(fixture.itemId, fixture.locationId)?.onHandMicros)
        assertEquals(movementCount, scalar("SELECT COUNT(*) FROM stock_movements"))
        assertEquals(0L, scalar("SELECT COUNT(*) FROM inventory_counts"))
        assertEquals(postAuditCount, scalar("SELECT COUNT(*) FROM audit_logs WHERE action='POST'"))
    }

    private suspend fun createAndOpen(): Long {
        val sessionId = service.create(
            CreateInventoryCountSessionCommand(
                locationId = fixture.locationId,
                scope = InventoryCountScope.ITEM_SELECTION,
                itemIds = setOf(fixture.itemId),
                blindCount = true,
                assignedToActorId = fixture.ownerId,
                businessEpochDay = BUSINESS_DAY,
                commandId = GlobalId.new().value,
                correlationId = "count-test:session:${now}",
            ),
        )
        service.open(action(sessionId, fixture.ownerId, "شروع شمارش فیزیکی"))
        return sessionId
    }

    private suspend fun approvedSession(countedQuantityMicros: Long): Long {
        val sessionId = createAndOpen()
        val line = service.lines(sessionId, false).single()
        service.record(record(sessionId, line.lineId, countedQuantityMicros))
        service.submit(action(sessionId, fixture.ownerId, "ارسال شمارش اول"))
        if (service.session(sessionId).status == InventoryCountStatus.RECOUNT_REQUIRED) {
            service.record(record(sessionId, line.lineId, countedQuantityMicros))
            service.submit(action(sessionId, fixture.ownerId, "ارسال بازشماری"))
        }
        security.switchUser(fixture.managerId, "654321")
        service.approve(action(sessionId, fixture.managerId, "مغایرت تأیید شد"))
        return sessionId
    }

    private fun action(sessionId: Long, actorId: Long, reason: String) =
        InventoryCountActionCommand(sessionId, actorId, reason)

    private fun record(sessionId: Long, lineId: Long, quantityMicros: Long) =
        RecordInventoryCountCommand(sessionId, lineId, quantityMicros, actorId = fixture.ownerId, reason = "شمارش کنترل‌شده")

    private fun scalar(sql: String): Long = database.openHelper.writableDatabase.query(sql).use { cursor ->
        check(cursor.moveToFirst())
        cursor.getLong(0)
    }

    private data class Fixture(
        val ownerId: Long,
        val managerId: Long,
        val cashierId: Long,
        val locationId: Long,
        val itemId: Long,
    )

    private companion object {
        const val BUSINESS_DAY = 21_000L
    }
}
