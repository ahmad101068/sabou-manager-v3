package ir.sabou.inventory.data.db

import android.content.Context
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.sqlite.db.SupportSQLiteOpenHelper
import androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class RestaurantOperationsMigration18To19Test {
    private val context = ApplicationProvider.getApplicationContext<Context>()
    private val databaseName = "restaurant-operations-migration-18-19.db"

    @After
    fun cleanUp() {
        context.deleteDatabase(databaseName)
    }

    @Test
    fun createsOperationalTablesAndRequiredUniqueIndex() {
        open(version = 18).use { it.writableDatabase }

        open(version = 19).use { helper ->
            val database = helper.writableDatabase
            val expectedTables = setOf(
                "restaurant_tables",
                "reservations",
                "kitchen_tickets",
                "planned_shifts",
                "approval_requests",
            )
            database.query(
                "SELECT name FROM sqlite_master WHERE type = 'table' AND name IN ('restaurant_tables','reservations','kitchen_tickets','planned_shifts','approval_requests')",
            ).use { cursor ->
                val actualTables = buildSet {
                    while (cursor.moveToNext()) add(cursor.getString(0))
                }
                assertEquals(expectedTables, actualTables)
            }

            database.execSQL(
                "INSERT INTO restaurant_tables(label, capacity, zone, status, activeOrderId) VALUES ('A1', 4, 'سالن', 'FREE', NULL)",
            )
            database.query("SELECT capacity, status FROM restaurant_tables WHERE label = 'A1'").use { cursor ->
                assertTrue(cursor.moveToFirst())
                assertEquals(4, cursor.getInt(0))
                assertEquals("FREE", cursor.getString(1))
            }
            database.query(
                "SELECT COUNT(*) FROM sqlite_master WHERE type = 'index' AND name = 'index_restaurant_tables_label'",
            ).use { cursor ->
                assertTrue(cursor.moveToFirst())
                assertEquals(1, cursor.getInt(0))
            }
        }
    }

    private fun open(version: Int): SupportSQLiteOpenHelper {
        val callback = object : SupportSQLiteOpenHelper.Callback(version) {
            override fun onCreate(db: SupportSQLiteDatabase) = Unit

            override fun onUpgrade(db: SupportSQLiteDatabase, oldVersion: Int, newVersion: Int) {
                if (oldVersion == 18 && newVersion == 19) MIGRATION_18_19.migrate(db)
            }
        }
        return FrameworkSQLiteOpenHelperFactory().create(
            SupportSQLiteOpenHelper.Configuration.builder(context)
                .name(databaseName)
                .callback(callback)
                .build(),
        )
    }
}
