package ir.sabou.inventory.data.repository

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import ir.sabou.inventory.core.GlobalId
import ir.sabou.inventory.core.QuantityMicros
import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.db.InventoryItemEntity
import ir.sabou.inventory.data.security.SessionAuthorizer
import ir.sabou.inventory.domain.operations.UserDraft
import ir.sabou.inventory.domain.operations.UserRole
import ir.sabou.inventory.domain.recipe.RecipeCostProfile
import ir.sabou.inventory.domain.recipe.RecipeIngredientInput
import ir.sabou.inventory.domain.restaurant.KitchenTicketStatus
import ir.sabou.inventory.domain.restaurant.OpenTableCommand
import ir.sabou.inventory.domain.restaurant.RestaurantOrderLineDraft
import ir.sabou.inventory.domain.restaurant.RestaurantTableStatus
import ir.sabou.inventory.domain.restaurant.RestaurantReservationStatus
import ir.sabou.inventory.domain.restaurant.TableReservationDraft
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class RestaurantV2IntegrationTest {
    private lateinit var database: AppDatabase
    private lateinit var authorizer: SessionAuthorizer
    private lateinit var service: LocalRestaurantService
    private lateinit var recipe: LocalRecipeRepository
    private var now = 50_000L
    private val today = 21_000L

    @Before
    fun setUp() = runBlocking {
        database = AppDatabase.createInMemory(ApplicationProvider.getApplicationContext<Context>())
        authorizer = SessionAuthorizer(database)
        LocalSecurityRepository(database, authorizer = authorizer, clock = { now }).save(
            null,
            UserDraft("restaurant-owner", "مالک رستوران", "123456", UserRole.OWNER, "87654321"),
        )
        val sales = LocalProfessionalSalesRepository(database, authorizer, clock = { now++ })
        recipe = LocalRecipeRepository(database = database, authorizer = authorizer, clock = { now++ }, epochDay = { today })
        service = LocalRestaurantService(database, sales, authorizer, clock = { now++ }, epochDay = { today })
    }

    @After
    fun tearDown() = database.close()

    @Test
    fun openTableReplay_isIdempotent_andSecondCommandCannotDoubleOccupyTable() = runBlocking {
        val hallId = service.createHall("سالن اصلی")
        val tableId = service.createTable(hallId, "A-01", 4)
        val commandId = GlobalId.new().value
        val first = service.openTable(OpenTableCommand(tableId = tableId, guestCount = 3, commandId = commandId))
        val replay = service.openTable(OpenTableCommand(tableId = tableId, guestCount = 3, commandId = commandId))

        assertEquals(first, replay)
        assertEquals(1L, scalar("SELECT COUNT(*) FROM restaurant_orders WHERE commandId='$commandId'"))
        val table = requireNotNull(database.restaurantDao().tableById(tableId))
        assertEquals(RestaurantTableStatus.OCCUPIED.name, table.status)
        assertEquals(first, table.currentOrderId)

        try {
            service.openTable(OpenTableCommand(tableId = tableId, guestCount = 2, commandId = GlobalId.new().value))
            fail("یک میز اشغال نباید با فرمان جدید دوباره باز شود")
        } catch (_: IllegalArgumentException) {
            Unit
        }
        assertEquals(1L, scalar("SELECT COUNT(*) FROM restaurant_orders WHERE tableId=$tableId AND status='OPEN'"))
    }

    @Test
    fun reservationLifecycle_updatesTableState_andOpenTablePersistsValidatedWaiterAndShift() = runBlocking {
        val hallId = service.createHall("سالن رزرو")
        val tableId = service.createTable(hallId, "R-01", 4)
        val reservationId = service.reserve(
            TableReservationDraft(
                tableId = tableId,
                guestName = "مهمان رزرو",
                guestPhone = "09121234567",
                reservationEpochDay = today,
                startMinuteOfDay = 1_200,
                guestCount = 3,
                note = "کنار پنجره",
            ),
        )
        assertEquals(RestaurantTableStatus.RESERVED.name, database.restaurantDao().tableById(tableId)?.status)

        service.transitionReservation(reservationId, RestaurantReservationStatus.CONFIRMED)
        assertEquals(RestaurantReservationStatus.CONFIRMED.name, database.restaurantDao().reservationById(reservationId)?.status)
        service.transitionReservation(reservationId, RestaurantReservationStatus.CANCELLED, "لغو توسط مهمان")
        assertEquals(RestaurantReservationStatus.CANCELLED.name, database.restaurantDao().reservationById(reservationId)?.status)
        assertEquals(RestaurantTableStatus.AVAILABLE.name, database.restaurantDao().tableById(tableId)?.status)

        try {
            service.openTable(OpenTableCommand(tableId = tableId, guestCount = 2, waiterUserId = Long.MAX_VALUE, shiftReference = "SHIFT-NIGHT"))
            fail("شناسه گارسون نامعتبر نباید ذخیره شود")
        } catch (_: IllegalStateException) {
            Unit
        }
        assertEquals(0L, scalar("SELECT COUNT(*) FROM restaurant_orders WHERE tableId=$tableId"))
        assertEquals(RestaurantTableStatus.AVAILABLE.name, database.restaurantDao().tableById(tableId)?.status)

        val currentUserId = requireNotNull(database.securityDao().currentUser()).id
        val orderId = service.openTable(OpenTableCommand(tableId = tableId, guestCount = 2, waiterUserId = currentUserId, shiftReference = "SHIFT-NIGHT"))
        val order = requireNotNull(database.restaurantDao().orderById(orderId))
        assertEquals(currentUserId, order.waiterUserId)
        assertEquals("SHIFT-NIGHT", order.shiftReference)
        assertEquals(RestaurantTableStatus.OCCUPIED.name, database.restaurantDao().tableById(tableId)?.status)
    }

    @Test
    fun kitchenInvalidTransition_isRejectedWithoutStateOrEventMutation_thenValidPathIsAudited() = runBlocking {
        val hallId = service.createHall("سالن KDS")
        val tableId = service.createTable(hallId, "K-01", 4)
        val orderId = service.openTable(OpenTableCommand(tableId = tableId, guestCount = 2))
        val inventoryItemId = database.inventoryDao().insert(
            InventoryItemEntity(
                name = "ماده KDS",
                category = "TEST",
                unit = "عدد",
                alertEnabled = false,
                createdAtEpochMillis = now++,
                updatedAtEpochMillis = now++,
            ),
        )
        val menuId = recipe.saveMenuItem(
            id = null,
            name = "آیتم KDS",
            category = "TEST",
            salePriceRial = 90_000L,
            ingredients = listOf(RecipeIngredientInput(inventoryItemId, QuantityMicros.SCALE)),
            costProfile = RecipeCostProfile(),
        )
        val lineId = service.addItem(RestaurantOrderLineDraft(orderId, menuId, QuantityMicros.positive(QuantityMicros.SCALE)))
        val ticket = requireNotNull(database.restaurantDao().kitchenTicketByOrderLine(lineId))
        val eventsBefore = scalar("SELECT COUNT(*) FROM kitchen_ticket_events WHERE ticketId=${ticket.id}")

        try {
            service.transitionKitchen(ticket.id, KitchenTicketStatus.READY)
            fail("NEW → READY باید به عنوان transition نامعتبر رد شود")
        } catch (_: IllegalArgumentException) {
            Unit
        }
        assertEquals(KitchenTicketStatus.NEW.name, database.restaurantDao().kitchenTicketById(ticket.id)?.status)
        assertEquals(eventsBefore, scalar("SELECT COUNT(*) FROM kitchen_ticket_events WHERE ticketId=${ticket.id}"))

        service.transitionKitchen(ticket.id, KitchenTicketStatus.ACCEPTED)
        service.transitionKitchen(ticket.id, KitchenTicketStatus.PREPARING)
        service.transitionKitchen(ticket.id, KitchenTicketStatus.READY)
        service.transitionKitchen(ticket.id, KitchenTicketStatus.SERVED)

        val served = requireNotNull(database.restaurantDao().kitchenTicketById(ticket.id))
        assertEquals(KitchenTicketStatus.SERVED.name, served.status)
        assertTrue(requireNotNull(served.acceptedAtEpochMillis) < requireNotNull(served.preparingAtEpochMillis))
        assertTrue(requireNotNull(served.preparingAtEpochMillis) < requireNotNull(served.readyAtEpochMillis))
        assertTrue(requireNotNull(served.readyAtEpochMillis) < requireNotNull(served.servedAtEpochMillis))
        assertEquals(eventsBefore + 4, scalar("SELECT COUNT(*) FROM kitchen_ticket_events WHERE ticketId=${ticket.id}"))
        assertTrue(scalar("SELECT COUNT(*) FROM audit_logs WHERE entityType='KITCHEN_TICKET' AND entityId=${ticket.id}") >= 4L)
    }

    @Test
    fun transferTable_movesOpenOrderAtomicallyAndReleasesSourceTable() = runBlocking {
        val hallId = service.createHall("سالن انتقال")
        val sourceTableId = service.createTable(hallId, "T-01", 4)
        val targetTableId = service.createTable(hallId, "T-02", 6)
        val orderId = service.openTable(OpenTableCommand(tableId = sourceTableId, guestCount = 2))

        service.transferTable(orderId, targetTableId, "درخواست مهمان")

        val source = requireNotNull(database.restaurantDao().tableById(sourceTableId))
        val target = requireNotNull(database.restaurantDao().tableById(targetTableId))
        val order = requireNotNull(database.restaurantDao().orderById(orderId))
        assertEquals(RestaurantTableStatus.AVAILABLE.name, source.status)
        assertEquals(null, source.currentOrderId)
        assertEquals(RestaurantTableStatus.OCCUPIED.name, target.status)
        assertEquals(orderId, target.currentOrderId)
        assertEquals(targetTableId, order.tableId)
        assertEquals(1L, scalar("SELECT COUNT(*) FROM audit_logs WHERE entityType='RESTAURANT_ORDER' AND entityId=$orderId AND action='TRANSFER'"))
    }

    private fun scalar(sql: String): Long = database.openHelper.writableDatabase.query(sql).use { cursor ->
        check(cursor.moveToFirst())
        cursor.getLong(0)
    }
}
