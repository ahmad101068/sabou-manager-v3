package ir.sabou.inventory.data.db

import android.content.Context
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.sqlite.db.SupportSQLiteOpenHelper
import androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class TableOrdersMigration21To22Test {
    private val context = ApplicationProvider.getApplicationContext<Context>()
    private val databaseName = "table-orders-migration-21-22.db"

    @After
    fun cleanUp() {
        context.deleteDatabase(databaseName)
    }

    @Test
    fun addsOpenOrdersWithoutChangingExistingTables() {
        open(21).use { helper ->
            val db = helper.writableDatabase
            db.execSQL("CREATE TABLE restaurant_tables (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,label TEXT NOT NULL)")
            db.execSQL("INSERT INTO restaurant_tables(label) VALUES ('VIP-1')")
        }

        open(22).use { helper ->
            val db = helper.writableDatabase
            db.query("SELECT label FROM restaurant_tables").use { cursor ->
                assertTrue(cursor.moveToFirst())
                assertEquals("VIP-1", cursor.getString(0))
            }
            db.query("SELECT COUNT(*) FROM table_orders").use { cursor ->
                assertTrue(cursor.moveToFirst())
                assertEquals(0, cursor.getInt(0))
            }
            db.query("PRAGMA table_info(table_order_lines)").use { cursor ->
                var hasKitchenDispatchColumn = false
                while (cursor.moveToNext()) if (cursor.getString(1) == "sentToKitchenAtEpochMillis") hasKitchenDispatchColumn = true
                assertTrue(hasKitchenDispatchColumn)
            }
        }
    }

    private fun open(version: Int): SupportSQLiteOpenHelper {
        val callback = object : SupportSQLiteOpenHelper.Callback(version) {
            override fun onCreate(db: SupportSQLiteDatabase) = Unit
            override fun onUpgrade(db: SupportSQLiteDatabase, oldVersion: Int, newVersion: Int) {
                if (oldVersion == 21 && newVersion == 22) MIGRATION_21_22.migrate(db)
            }
        }
        return FrameworkSQLiteOpenHelperFactory().create(
            SupportSQLiteOpenHelper.Configuration.builder(context).name(databaseName).callback(callback).build(),
        )
    }
}
