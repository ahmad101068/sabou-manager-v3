package ir.sabou.inventory.data.repository

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import ir.sabou.inventory.core.CorrelationId
import ir.sabou.inventory.core.GlobalId
import ir.sabou.inventory.core.MoneyRial
import ir.sabou.inventory.core.QuantityMicros
import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.db.CustomerEntity
import ir.sabou.inventory.data.db.InventoryItemEntity
import ir.sabou.inventory.data.security.AccessDeniedException
import ir.sabou.inventory.data.security.SessionAuthorizer
import ir.sabou.inventory.data.treasury.LegacyTreasuryAccountCatalog
import ir.sabou.inventory.data.treasury.LocalTreasuryServiceV2
import ir.sabou.inventory.domain.assets.AssetAcquisitionSource
import ir.sabou.inventory.domain.assets.AssetDraft
import ir.sabou.inventory.domain.assets.AssetTransferDraft
import ir.sabou.inventory.domain.operations.UserDraft
import ir.sabou.inventory.domain.operations.UserRole
import ir.sabou.inventory.domain.recipe.RecipeDraftInput
import ir.sabou.inventory.domain.recipe.RecipeIngredientInput
import ir.sabou.inventory.domain.restaurant.OpenTableCommand
import ir.sabou.inventory.domain.security.Permission
import ir.sabou.inventory.domain.treasury.TreasuryAccountId
import ir.sabou.inventory.domain.treasury.TreasuryChannel
import ir.sabou.inventory.domain.treasury.TreasuryCommand
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.fail
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class EnterprisePermissionIntegrationTest {
    private lateinit var database: AppDatabase
    private lateinit var authorizer: SessionAuthorizer
    private lateinit var security: LocalSecurityRepository
    private var now = 5_000_000L
    private val today = 23_000L
    private var ownerId: Long = 0
    private var cashierId: Long = 0
    private var storekeeperId: Long = 0

    @Before
    fun setUp() = runBlocking {
        database = AppDatabase.createInMemory(ApplicationProvider.getApplicationContext<Context>())
        authorizer = SessionAuthorizer(database)
        security = LocalSecurityRepository(database, authorizer = authorizer, clock = { ++now })
        ownerId = security.save(null, UserDraft("owner-perm", "مالک مجوز", "123456", UserRole.OWNER, "87654321"))
        security.switchUser(ownerId, "123456")
        cashierId = security.save(null, UserDraft("cashier-perm", "صندوقدار مجوز", "654321", UserRole.CASHIER))
        storekeeperId = security.save(null, UserDraft("storekeeper-perm", "انباردار مجوز", "456789", UserRole.STOREKEEPER))
        security.switchUser(ownerId, "123456")
    }

    @After
    fun tearDown() = database.close()

    @Test
    fun treasuryReceipt_requiresTreasuryPermissionAtDomainBoundary() = runBlocking {
        val service = LocalTreasuryServiceV2(
            database = database,
            accounting = LocalAccountingPostingEngine(database, clock = { ++now }),
            authorizer = authorizer,
            accountCatalog = LegacyTreasuryAccountCatalog(),
            clock = { ++now },
        )
        security.switchUser(cashierId, "654321")
        val commandId = GlobalId.new()

        expectDenied(Permission.TREASURY) {
            service.execute(
                TreasuryCommand.Receipt(
                    commandId = commandId,
                    businessEpochDay = today,
                    correlationId = CorrelationId.forCommand("permission_test", commandId),
                    sourceType = "OTHER_RECEIPT",
                    sourceId = 99,
                    reason = "آزمون مجوز خزانه",
                    accountId = TreasuryAccountId.parse("cash_main"),
                    channel = TreasuryChannel.CASH,
                    amount = MoneyRial.of(10_000L),
                ),
            )
        }
        assertEquals(0L, scalar("SELECT COUNT(*) FROM treasury_transactions"))
        assertEquals(0L, scalar("SELECT COUNT(*) FROM journal_entries WHERE sourceType='OTHER_RECEIPT'"))
    }

    @Test
    fun restaurantMerge_requiresDedicatedMergePermission_evenWhenCashierCanUseRestaurantPos() = runBlocking {
        val restaurant = LocalRestaurantService(
            database,
            LocalProfessionalSalesRepository(database, authorizer, clock = { ++now }),
            authorizer,
            clock = { ++now },
            epochDay = { today },
        )
        val hall = restaurant.createHall("سالن مجوز")
        val table1 = restaurant.createTable(hall, "P-01", 4)
        val table2 = restaurant.createTable(hall, "P-02", 4)
        val order1 = restaurant.openTable(OpenTableCommand(tableId = table1, guestCount = 2))
        val order2 = restaurant.openTable(OpenTableCommand(tableId = table2, guestCount = 2))
        security.switchUser(cashierId, "654321")

        expectDenied(Permission.RESTAURANT_MERGE) {
            restaurant.mergeTables(order1, order2, "آزمون منع ادغام")
        }
        assertEquals("OPEN", requireNotNull(database.restaurantDao().orderById(order1)).status)
        assertEquals("OPEN", requireNotNull(database.restaurantDao().orderById(order2)).status)
    }

    @Test
    fun customerMerge_requiresCustomerMergePermission_andDoesNotMoveReferencesOnDenial() = runBlocking {
        val source = insertCustomer("CUS-PERM-1", "مشتری یک")
        val target = insertCustomer("CUS-PERM-2", "مشتری دو")
        val service = LocalCustomerAccountService(database, authorizer, clock = { ++now })
        security.switchUser(cashierId, "654321")

        expectDenied(Permission.CUSTOMER_MERGE) {
            service.merge(source, target, "آزمون منع ادغام مشتری")
        }
        assertEquals("ACTIVE", requireNotNull(database.salesDao().customerById(source)).status)
        assertEquals(0L, scalar("SELECT COUNT(*) FROM customer_merge_history"))
    }

    @Test
    fun assetTransfer_requiresLifecyclePermission_andLeavesAssetUntouchedOnDenial() = runBlocking {
        val assets = LocalAssetRepository(database, clock = { ++now }, authorizer = authorizer)
        val assetId = assets.save(
            null,
            AssetDraft(
                assetCode = "AST-PERM-1",
                name = "دارایی مجوز",
                category = "تجهیزات",
                quantity = 1,
                purchaseEpochDay = today,
                purchaseCostRial = 2_000_000L,
                salvageValueRial = 200_000L,
                usefulLifeMonths = 24,
                location = "محل اولیه",
                notes = "",
                acquisitionSource = AssetAcquisitionSource.BANK,
                branch = "شعبه یک",
                responsiblePerson = "مسئول یک",
            ),
        )
        security.switchUser(cashierId, "654321")

        expectDenied(Permission.ASSET_LIFECYCLE) {
            assets.transfer(AssetTransferDraft(assetId, "محل جدید", "شعبه دو", "مسئول دو", today + 1, "آزمون منع انتقال"))
        }
        val asset = requireNotNull(database.assetDao().assetById(assetId))
        assertEquals("محل اولیه", asset.location)
        assertEquals("شعبه یک", asset.branch)
        assertEquals(0L, scalar("SELECT COUNT(*) FROM asset_lifecycle_events WHERE assetId=$assetId AND eventType='TRANSFER'"))
    }

    @Test
    fun recipeActivation_requiresDedicatedPermission_evenWhenRoleCanEditRecipes() = runBlocking {
        val itemId = database.inventoryDao().insert(
            InventoryItemEntity(
                name = "ماده مجوز رسپی",
                category = "TEST",
                unit = "عدد",
                alertEnabled = false,
                createdAtEpochMillis = ++now,
                updatedAtEpochMillis = ++now,
            ),
        )
        val recipes = LocalRecipeRepository(database, authorizer = authorizer, clock = { ++now }, epochDay = { today })
        val menuId = recipes.saveMenuItem(null, "غذای مجوز", "TEST", 200_000L, listOf(RecipeIngredientInput(itemId, QuantityMicros.SCALE)))
        security.switchUser(storekeeperId, "456789")
        val draftId = recipes.createDraft(
            RecipeDraftInput(menuId, listOf(RecipeIngredientInput(itemId, QuantityMicros.SCALE)), note = "ویرایش مجاز"),
        )

        expectDenied(Permission.RECIPE_ACTIVATE) {
            recipes.activate(draftId, today)
        }
        assertEquals("DRAFT", requireNotNull(database.alpha162RecipeDao().versionById(draftId)).status)
    }

    private suspend fun insertCustomer(code: String, name: String): Long = database.salesDao().insertCustomer(
        CustomerEntity(
            customerCode = code,
            name = name,
            phone = "",
            nationalId = "",
            creditLimitRial = 0,
            notes = "",
            createdAtEpochMillis = ++now,
            updatedAtEpochMillis = ++now,
        ),
    )

    private suspend fun expectDenied(permission: Permission, block: suspend () -> Unit) {
        try {
            block()
            fail("Expected AccessDeniedException for $permission")
        } catch (denied: AccessDeniedException) {
            assertEquals(permission, denied.permission)
        }
    }

    private fun scalar(sql: String): Long = database.openHelper.writableDatabase.query(sql).use { cursor ->
        check(cursor.moveToFirst())
        cursor.getLong(0)
    }
}
