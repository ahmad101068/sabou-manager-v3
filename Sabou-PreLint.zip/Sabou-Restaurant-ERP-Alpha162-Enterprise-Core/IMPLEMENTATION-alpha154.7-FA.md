# alpha154.7 — Unit Conversion Architecture Phase 1

- Added exact rational UnitConversionFactor using BigInteger and no floating-point arithmetic.
- Inventory items now persist separate Stock, Purchase and Recipe units.
- Purchase→Stock and Recipe→Stock factors are persisted as numerator/denominator pairs.
- Migration 40→41 preserves all existing items as 1:1 conversions and copies the legacy unit into purchase/recipe units.
- Added unit tests for exact conversion, inverse conversion, overflow-safe arithmetic and rejection of non-representable micros.
- This phase deliberately preserves current purchase/recipe behavior at 1:1. UI configuration and workflow adoption are the next phase; no existing transaction is silently reinterpreted.
