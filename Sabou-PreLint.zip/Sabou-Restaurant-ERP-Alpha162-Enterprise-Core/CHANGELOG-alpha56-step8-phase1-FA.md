# Sabou Manager v3 — alpha56 HR Step 8 / Phase 1

## زیرساخت دیتابیس مدیریت عملکرد

- افزودن جدول `performance_goals` برای اهداف و KPIهای کارکنان.
- افزودن جدول `performance_reviews` برای ارزیابی‌های دوره‌ای.
- افزودن جدول `performance_scores` برای امتیاز هر هدف در هر ارزیابی.
- تعریف کلیدهای خارجی، شاخص‌های جست‌وجو و محدودیت یکتایی امتیاز هدف در ارزیابی.
- ارتقای Room database از نسخه 14 به 15 با `MIGRATION_14_15`.
- ارتقای نسخه برنامه به `versionCode 88` و `3.0.0-alpha56-hr-step8-performance-phase1`.

این فاز فقط زیرساخت ذخیره‌سازی را ایجاد می‌کند. DAO، Repository، ViewModel و UI در فازهای بعدی اضافه می‌شوند.
