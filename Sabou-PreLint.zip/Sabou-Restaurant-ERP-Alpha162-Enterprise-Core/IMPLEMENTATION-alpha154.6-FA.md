# CafeManager alpha154.6 — Inventory Command Engine Phase 2

## اجرا شده
- انتقال Inventory Count authoritative valuation/movement mutation به `LocalInventoryCommandEngine.adjustToCount`.
- انتقال Waste quantity/value/FEFO lot consumption به `LocalInventoryCommandEngine.issue(... FEFO_ALL)`.
- انتقال Lot Transfer mutation و transfer persistence به `LocalInventoryCommandEngine.transferLot`.
- حفظ `Room.withTransaction` در workflowهای فراخواننده، Audit، Sync/Outbox و Semantic Accounting مربوط به Waste.
- اسکن استاتیک repositoryها: mutationهای مستقیم `updateValuation`, `restoreValuation`, `stockMovementDao().insert`, `managementControlDao().updateLot` خارج از Inventory Command Engine باقی نمانده‌اند.

## Build/Test
`./gradlew testDebugUnitTest --offline` اجرا شد، اما Gradle Wrapper برای Gradle 8.13 نیاز به دریافت distribution از services.gradle.org داشت و محیط شبکه DNS/Internet ندارد. بنابراین Build/Test موفق ادعا نشده است.

## مرحله بعد
Unit Conversion Architecture: Purchase Unit / Stock Unit / Recipe Unit با conversion دقیق و migration-safe.
