# تغییرات alpha153.6.1 — Print Build Fix

- `versionCode`: 193
- `versionName`: `3.0.0-alpha153.6.1-print-buildfix`
- Database schema: 39 (بدون Migration)

## اصلاح

- خطای Kotlin در `ReportPrinter.kt` رفع شد: setter مربوط به `WebViewClient` در Android API مورد استفاده non-null است و دیگر مقدار `null` دریافت نمی‌کند.
- پس از پایان بارگذاری، callback client با یک `WebViewClient` خنثی جایگزین می‌شود تا رویداد تکراری موجب چاپ دوباره نشود.

## شواهد

- خطای CI: `Null cannot be a value of a non-null type WebViewClient` در خط ۶۲.
- Foundation/static verification پس از اصلاح موفق است.
- Build مجدد در محیط محلی به‌دلیل عدم دسترسی Wrapper به Gradle قابل اجرا نیست و باید در CI تأیید شود.
